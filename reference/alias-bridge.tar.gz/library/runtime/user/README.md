# runtime/user

컴파일러가 대상에 맞게 직접 싣는 런타임 내부 파일만 둔다. 앱이나 라이브러리는
이 디렉터리의 파일을 가져오지 않는다(가져오면 컴파일 오류).

- `app_start.hmje`: 인자 없는 `앱시작`의 진입 글루
- `app_start_args.hmje`: `앱시작(인자들)`의 진입 글루. 인자 저장소는 표준이 소유한다.

`runtime/platform/aarch64/bare_console.hmje`는 aarch64 직접 부팅 대상의 PL011 콘솔
프렐류드다. `runtime/platform/*/file_*.hmje`는 지금 설치된 stage0 씨앗을 위한 빈
자리표시자이며 세 stage0 슬롯을 갱신한 뒤 지운다.

앱이 쓰는 운영체제 기능은 모듈로 가져온다.

| 기능 | 가져오기 |
| --- | --- |
| 파일·소켓·프로세스·명령줄 인자·환경·시간·종료 | 표준(자동) |
| 창·입력·클립보드·프레임버퍼·GPU·객체 저장소·IPC·부트 모듈·진단 | `운영체제를 가져온다.` |
| TLS 1.3 클라이언트, 동시 제한 | `기반을 가져온다.` |
| 그래픽 명령·장치 계약 | hmje-ui의 `HmjeGraphics를 가져온다.` |
| 오디오 입력 | hmje-audio의 `HmjeAudio를 가져온다.` |
| semtleOS 객체·그래프·부트 모듈 SDK | hmje-semtleos-sdk의 `SemtleOSSDK를 가져온다.` |
