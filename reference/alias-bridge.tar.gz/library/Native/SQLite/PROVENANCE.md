# SQLite runtime provenance

HMJE typed plans were migrated from the user's `hmje-db` repository at
`127ba5a9718f5ea1bd5bad217a5d74b4d32487e5` (2026-08-06 archive), and the
SQLite HMJE adapter and checked native bridge from `hmje-sqlite` at
`58b38e97df87b68da60a67862fdb8103ca7c8894`.

The migration preserves the implementation and comments, replaces the retired
`위험 구역` spelling, declares public module APIs, and uses the current named
module project contract. Native handle validation, binding, execution and
transaction code is shared between POSIX and Windows. The POSIX backup/restore
implementation retains its descriptor and snapshot checks; the Windows
implementation uses Win32 file locks, a separate verified database, and atomic
publication.

`vendor/sqlite3.c` and `vendor/sqlite3.h` are unmodified SQLite 3.53.4
amalgamation files, downloaded from
https://www.sqlite.org/2026/sqlite-amalgamation-3530400.zip on 2026-09-07.
The archive SHA3-256 was verified against the official download page:
`628a44cfe82c66aed1ccbbe85a562d2e33ebe64b3288981ed76285612227934e`.

SQLite is public domain: https://www.sqlite.org/copyright.html . Its original
public-domain dedication remains in the vendored files. No build-time download
or system SQLite installation is required.

Windows 파일 교체 API 근거:
- https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_rename_info
- https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle
