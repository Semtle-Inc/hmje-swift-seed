# SQLite native 실행 검증 (2026-09-07)

공유 stage0를 설치하거나 Python 참조 컴파일러를 사용하지 않고 검증했다.
`tests/selfhost_server_dsl/sqlite_native.c`는 동일한 ABI로 다음을 실제 SQLite에
실행하고 결과를 검사한다: 메모리 DB 열기, 트랜잭션 확정, UNIQUE 오류 후
롤백, 바인드된 SQL 삽입 공격 문자열을 데이터로 저장, 결과 읽기, 해제한
statement/database 핸들 거부, 온라인 백업, 새 파일 복원, 기존 파일 복원.

| 환경 | 실제 실행 결과 |
| --- | --- |
| macOS arm64, Apple clang | 전체 통과 |
| Android aarch64, NDK 28.2 / semtleui-test emulator | 전체 통과 |
| Windows 11 arm64, Parallels / LLVM 22 | 전체 통과 |

Android에서는 `adb shell mkdir` 기본 권한 0777이 기존 POSIX 복원 계약에
따라 거부됨을 확인했다. 소유한 0700 디렉터리를 사용하면 전체 통과한다.
Windows 기존 파일 복원은 잠금 중인 대상에 MoveFileEx를 적용하면
ERROR_ACCESS_DENIED가 발생해 FileRenameInfoEx의 POSIX 교체 의미로 수정했다.
대상 읽기/쓰기 배제 잠금을 유지한 상태에서 파일을 원자 교체하고 flush한다.

SQLite 3.53.4 원본은 모든 hosted 플랫폼에서 같은 소스로 빌드한다.
semtleOS에는 아직 SQLite VFS가 없으므로 이 외부 구현은 빌드 시 명시적으로
오류를 낸다. 이 표는 C ABI 실행 증거이며 HMJE DB/라우트 DSL의 통합 결과는
`tests/selfhost_server_dsl/`의 별도 관문에서 확인한다.
