# kernel/api

커널과 유저 런타임이 공유하는 ABI 정의를 둔다. syscall 번호, fd 번호, 에러 코드, 공용 구조체가 이 계층에 속한다.
