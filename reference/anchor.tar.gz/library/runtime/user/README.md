# runtime/user

유저 앱에 링크되는 런타임 코드를 둔다. syscall wrapper와 앱 시작 코드를 제공한다.

객체 저장소 wrapper의 주 표면은 graph walk/graph edge 이름을 사용한다. `객체그래프열기`, `객체그래프연결`, `객체그래프연결해제`, `객체이름연결`, `객체이름연결해제`가 새 코드에서 쓰는 이름이다. 유저 런타임은 더 이상 path/경로 이름의 wrapper를 제공하지 않는다.
