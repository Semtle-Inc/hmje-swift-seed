# stdlib

훈민정음의 기본 런타임 라이브러리를 둔다.

`library/Project.hmjep`는 표준·기반·DB·SQLite·Backend를 실제 모듈로 내보낸다.
기존 파일 가져오기에서 사용하던 표준·기반 선언에는 `공개`를 명시하고,
외부에서 읽고 구성하는 값 레코드의 필드도 `공개`로 적는다. 모듈 소유가
정확히 기록된 프로젝트에서도 같은 라이브러리 API를 사용하기 위한 이식이다.
공유 파싱 보조인 `파싱공백인가`는 라이브러리 프로젝트 내부에서만 사용한다.
컴파일러의 사용자 모듈 접근 규칙이나 `소비하는` 계약은 바꾸지 않는다.

이 디렉터리는 문자열, 동적 배열, 메모리, 출력처럼 일반 앱에서 넓게 쓰는 기본 기능을 제공한다. 현재 freestanding semtleOS 앱을 우선 지원하므로 일부 함수는 `runtime/user/` wrapper를 통해 커널 ABI를 사용한다.

semtleOS 객체 저장소나 그래프 순회처럼 특정 OS 정책에 묶인 API는 `../oslib/`에 둔다.

멀티스레드 값 전송의 저수준 기반은 `channel_runtime.hmje`와
`arc_transfer_runtime.hmje`에 둔다. 전자는 송신·수신 endpoint 수명과
reserve/commit/cancel을 가진 bounded MPMC 바이트 슬롯을 제공하고,
후자는 owner graph 안의 내부 별칭 수와 실제 ARC 참조 수를 비교하기 위한 방문표를
제공한다. 둘 다 컴파일러가 생성할 타입 채널 어댑터의 내부 구현이며, 앱이 owner
값을 주소로 우회해 직접 보내도 안전하다는 뜻은 아니다. 타입 채널과
move-or-copy 생성이 연결되기 전에는 POD 회귀 검사에만 사용한다.
