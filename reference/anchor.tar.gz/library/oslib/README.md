# oslib

semtleOS 전용 사용자 라이브러리를 둔다.

이 디렉터리는 훈민정음 언어 자체의 표준 기능이 아니라, semtleOS 커널 ABI와 객체 저장소 정책 위에서만 의미가 있는 API를 제공한다.

- `object.hmje`: 커널 object handle FD를 `객체` 구조체로 감싸는 얇은 API
- `relation.hmje`: OS relation registry에 등록되는 `객체관계`와 edge 연결 속성 helper
- `edge.hmje`: `SYS_OBJECT_QUERY_EDGES`의 TLV request와 record offset을 숨기는 edge query API
- `object_graph.hmje`: `object_stat`, `object_list_edges`, `object_query_edges` 레코드 배치를 숨기는 그래프 순회용 고수준 API
- `boot_module.hmje`: semtleOS boot module을 조회하고 읽는 앱 API
- `zip_extract.hmje`: boot module ZIP을 객체 그래프로 물리화하는 helper

SemtleUI, HMJE Graphics, 폰트·텍스트 렌더링은 `hmje-ui`가 소유하므로 이 디렉터리에 포함하지 않는다. 이미지 표시 모듈도 `hmje-ui`가 소유하며 이 SDK의 객체 그래프와 PNG 코덱을 가져온다.

객체 생성과 열기 계열 API는 실패할 수 있으므로 `객체?`를 반환한다. 성공한 값은 기존 Optional 문법으로 확인하고 unwrap한 뒤 read/write/stat/close 같은 작업 함수에 넘긴다.

`객체이름(대상)`과 `객체형식(대상)`은 node metadata를 `문자열?`로 반환한다. 이름/형식이 없거나 권한/주소 문제가 있으면 `없음`이다. `{객체}의 이름`, `{객체}의 형식` 자연어 표현도 이 함수로 낮아진다. `객체문자열읽기`는 handle streaming offset에 의존하지 않고 `READ_AT(0)` 기반으로 전체 blob을 읽는다.

객체 그래프 API의 사용자 분기는 권한, 현재 저장 상태, edge query 결과를 기준으로 한다. `OBJECT_FEATURE_HAS_BLOB`, `OBJECT_FEATURE_HAS_LINKED_EDGES` 같은 feature flag는 blob 보유, 연결 edge 보유 같은 저수준 저장 상태이며 의미 계약으로 쓰지 않는다. OS 라이브러리는 특정 관계를 `포함`처럼 특별취급하지 않고, 앱은 필요하면 relation registry에 자기 관계를 등록해 query 결과를 직접 해석한다.

`객체에서 "이름"를 연다`는 이미 열린 객체를 시작점으로 삼아, 현재 객체에서 나가는 directed edge 또는 incident undirected edge 중 도착 객체의 이름과 optional format filter가 일치하는 대상을 여는 상대 graph walk다. `"a/b/c.txt"`처럼 여러 segment가 있으면 열린 객체에서 시작해 각 `/`를 같은 edge-follow 연산으로 해석한다. `/hello.txt`처럼 맨 앞이 `/`인 표기는 부팅 후 잡히는 `system` 객체에서 시작하는 graph walk 표기이고, 임의 객체 handle을 시작점으로 삼으면 같은 규칙으로 어디서든 탐색을 시작할 수 있다. `system`은 첫 segment가 아니라 absolute graph walk의 시작 객체이므로 기본 진입점 아래의 `tmp`는 `/tmp`로 쓰고 `/system/tmp`로 쓰지 않는다.

`객체의 연결 대상 수`, `객체의 N번째 연결 대상 이름`, `객체연결대상ID` 계열은 raw outgoing edge 목록이 아니라 graph walk로 이동 가능한 대상 view다. directed edge는 나가는 방향만 보고, undirected edge는 양쪽 endpoint에서 상대 객체를 대상으로 본다. 같은 시작 객체에서 같은 대상 객체로 향하는 edge가 여러 개 있으면 대상 view에서는 하나로 접고, relation별 raw edge 배열이 필요하면 `객체나가는엣지들`, `객체들어오는엣지들`, `객체연결엣지들`을 쓴다.

`객체를기준객체에이름으로연결(대상, 기준, "name")`와 `객체를기준객체에서이름으로연결해제(대상, 기준, "name")`는 absolute graph walk 문자열 없이 이미 열린 기준 객체에서 대상 객체로 가는 default name-link directed edge를 만들거나 지운다. 이 edge의 `relation id 0`은 `포함` 같은 OS 내장 의미가 아니라, 이름 기반 도달성을 위한 예약 relation id다. `"name"`은 edge 이름이 아니라 target object name과 format metadata로 검증 또는 최초 설정된다. `"a/b/name.txt"`처럼 여러 segment가 있으면 기준 객체에서 `"a/b"`를 먼저 graph walk로 연 뒤 그 결과 객체에서 대상 객체를 `"name.txt"`로 연결하거나 해제한다. 맨 앞이 `/`면 기준 객체 대신 `system` 객체에서 시작한다. `/`와 `객체에서 "이름"를 연다`는 default name-link edge뿐 아니라 앱이 등록한 일반 relation edge도 같은 graph walk 후보로 본다. runtime의 `객체이름연결(base_fd, target_fd, "name")`와 `객체이름연결해제(base_fd, target_fd, "name")`는 이 API가 내려가는 저수준 wrapper다.

일반 관계는 먼저 `객체관계등록(이름, 설명)`으로 OS relation registry에 등록하고, 필요할 때 `객체관계찾기(이름)`로 조회한다. 등록과 조회를 한 번에 할 때는 `객체관계등록값(이름, 설명)`을 쓴다. registry는 객체 그래프 node가 아니라 커널/OS 메타데이터 테이블이다. 커널은 비어 있는 relation id를 할당하고, edge에는 relation 정의 전체가 아니라 relation id만 저장한다. `객체관계찾기`는 등록된 관계를 `객체관계?`로 반환하며, 없으면 `없음`을 반환한다. `객체관계`는 `{식별자, 이름, 설명}`을 담고, edge별 방향/강도/플래그는 `객체엣지연결정보`가 담는다. `객체관계연결(출발, 도착, 연결정보)`와 `객체관계연결해제(출발, 도착, 연결정보)`는 성공 시 `0`, 실패 시 음수 오류 코드를 반환한다. 일반 relation edge 삭제는 source/target/relation/direction/strength/flags가 모두 맞는 edge만 제거하고, 이름 기반 default name-link edge는 별도 graph walk unlink API로만 지운다.

관계 query는 edge 배열과 object 배열을 모두 제공한다. `객체나가는엣지들/객체들어오는엣지들/객체연결엣지들`은 raw edge record를 앱에 올리고, `객체나가는객체들/객체들어오는객체들/객체연결객체들`은 각 edge의 반대편 object handle 배열을 반환한다.

관계 값은 객체가 아니므로 `작성자관계값의 이름`, `작성자관계값의 설명`, `작성자관계값의 식별자`는 object metadata 조회가 아니라 `객체관계` 구조체 필드 접근으로 낮아진다.

관계 조회는 앱이 직접 TLV request를 만들지 않도록 `객체나가는엣지들`, `객체들어오는엣지들`, `객체연결엣지들`을 제공한다. 세 함수는 모두 `객체관계` 값의 식별자로 필터링한 결과를 `객체엣지의 배열`로 반환한다. `객체엣지`는 relation id와 함께 edge 인스턴스의 방향/강도/플래그를 노출한다. `채우기` 계열 함수는 syscall record buffer를 직접 다루는 내부 보조 API다.

일반 문자열, 배열, 출력, 메모리 helper는 `../stdlib/`에 둔다.
