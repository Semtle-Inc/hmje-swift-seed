/*
 * posix_host_text_input.m — posix-host(macOS) 문자 입력 파이프라인.
 *
 * posix_host_window.m의 키 이벤트 모니터가 받은 NSEvent를 전부 이 유닛으로 넘긴다.
 * 여기서 두 종류의 입력 이벤트(library/kernel/api/syscall.hmje 계약)로 변환해
 * hmje_posix_input_push_event(윈도우 유닛의 입력 링)로 큐잉한다:
 *
 *   - INPUT_EVENT_KIND_KEY (상위 8비트 = 0): 물리 키 down/up. 하위 8비트 = macOS 가상
 *     keyCode, 비트 8 = 눌림, 비트 16~19 = 수정자(shift/ctrl/alt/cmd). 화살표·엔터·
 *     백스페이스·단축키·게임 키 상태표는 전부 이 스트림.
 *   - INPUT_EVENT_KIND_TEXT (상위 8비트 = 4): 확정(committed) 유니코드 코드포인트
 *     (비트 0~20). NSTextInputClient를 채택한 숨은 뷰가 first responder가 되어
 *     macOS IME가 한글 조합을 대신 해주고, insertText:로 확정된 문자열만 코드포인트
 *     단위로 큐잉한다. 조합 중(preedit/marked text)은 v1에서는 이벤트를 만들지 않고
 *     보관만 한다(조합 표시 이벤트는 후속).
 *
 * 이벤트 순서: keyDown 하나가 텍스트를 확정하면 KIND_TEXT를 먼저, 그 keyDown의
 * KIND_KEY down을 나중에 큐잉한다. (엔터로 한글 조합을 확정하는 경우 앱이
 * "확정 문자 → 엔터" 순서로 보게 하기 위함.)
 *
 * cmd/ctrl이 눌린 keyDown은 IME로 보내지 않는다(단축키는 텍스트가 아니다).
 *
 * 검증용 이스케이프 해치(HMJE_POSIX_DUMP_FRAME과 같은 정신): HMJE_POSIX_SYNTH_TEXT
 * 환경변수가 설정되어 있으면 창 attach 직후 그 UTF-8 문자열을 insertText: 경로로
 * 흘려 KIND_TEXT 이벤트를 만든다 — CGEvent 합성(TCC 권한 필요) 없이 IME 확정 경로
 * (insertText: → 코드포인트 분해 → 큐잉 → SYS_INPUT_POLL)를 그대로 검증한다.
 */

#import <Cocoa/Cocoa.h>
#include <stdlib.h>
#include <string.h>

typedef long long i64;
typedef unsigned long long u64;

/* posix_host_window.m가 노출하는 입력 링 push. */
extern void hmje_posix_input_push_event(u64 event);

/* library/kernel/api/syscall.hmje 계약과 값이 같아야 하는 로컬 상수(별도 번역 단위). */
#define HMJE_INPUT_KIND_SHIFT 56
#define HMJE_INPUT_KIND_KEY 0ULL
#define HMJE_INPUT_KIND_TEXT 4ULL
#define HMJE_INPUT_KIND_EDIT_COMMAND 7ULL
#define HMJE_INPUT_PRESSED_FLAG 256ULL
#define HMJE_INPUT_MOD_SHIFT 65536ULL
#define HMJE_INPUT_MOD_CTRL 131072ULL
#define HMJE_INPUT_MOD_ALT 262144ULL
#define HMJE_INPUT_MOD_SUPER 524288ULL
#define HMJE_INPUT_TEXT_CODEPOINT_MASK 2097151ULL
#define HMJE_EDIT_SELECT_ALL 1ULL
#define HMJE_EDIT_COPY 2ULL
#define HMJE_EDIT_CUT 3ULL
#define HMJE_EDIT_PASTE 4ULL
#define HMJE_EDIT_UNDO 5ULL
#define HMJE_EDIT_REDO 6ULL

static void push_edit_command(u64 command) {
    hmje_posix_input_push_event((HMJE_INPUT_KIND_EDIT_COMMAND << HMJE_INPUT_KIND_SHIFT)
                                | (command & 255ULL));
}

static u64 modifier_bits(NSEventModifierFlags flags) {
    u64 bits = 0;
    if (flags & NSEventModifierFlagShift) {
        bits |= HMJE_INPUT_MOD_SHIFT;
    }
    if (flags & NSEventModifierFlagControl) {
        bits |= HMJE_INPUT_MOD_CTRL;
    }
    if (flags & NSEventModifierFlagOption) {
        bits |= HMJE_INPUT_MOD_ALT;
    }
    if (flags & NSEventModifierFlagCommand) {
        bits |= HMJE_INPUT_MOD_SUPER;
    }
    return bits;
}

static void push_key_event(unsigned short keyCode, BOOL pressed, NSEventModifierFlags flags) {
    /* macOS 조작 키 keyCode는 set-1의 printable 키와 충돌한다. 공통 UI 계층이
     * B/J/N 입력을 포커스 조작으로 오인하지 않도록 hosted 값만 예약 영역으로
     * 정규화한다. 게스트/QEMU의 set-1 값은 그대로 쓴다. */
    if (keyCode == 48) {
        keyCode = 250; /* Tab */
    } else if (keyCode == 36) {
        keyCode = 251; /* Return */
    } else if (keyCode == 49) {
        keyCode = 252; /* Space */
    }
    u64 event = (u64)(keyCode & 0xFF);
    if (pressed) {
        event |= HMJE_INPUT_PRESSED_FLAG;
    }
    event |= modifier_bits(flags);
    /* KIND_KEY == 0이라 상위 8비트는 이미 0이지만 계약 형태를 명시해둔다. */
    event |= (HMJE_INPUT_KIND_KEY << HMJE_INPUT_KIND_SHIFT);
    hmje_posix_input_push_event(event);
}

static void push_text_string(NSString *string) {
    if (string == nil || [string length] == 0) {
        return;
    }
    /* UTF-32LE로 변환해 코드포인트 단위로 순회한다(서러게이트 쌍 처리 포함). */
    NSData *utf32 = [string dataUsingEncoding:NSUTF32LittleEndianStringEncoding];
    if (utf32 == nil) {
        return;
    }
    const unsigned char *bytes = (const unsigned char *)[utf32 bytes];
    NSUInteger count = [utf32 length] / 4;
    for (NSUInteger i = 0; i < count; i++) {
        u64 codepoint = (u64)bytes[i * 4]
                      | ((u64)bytes[i * 4 + 1] << 8)
                      | ((u64)bytes[i * 4 + 2] << 16)
                      | ((u64)bytes[i * 4 + 3] << 24);
        if (codepoint == 0) {
            continue; /* BOM 없는 UTF-32LE라 0은 나올 일 없지만 방어 */
        }
        u64 event = (HMJE_INPUT_KIND_TEXT << HMJE_INPUT_KIND_SHIFT)
                  | (codepoint & HMJE_INPUT_TEXT_CODEPOINT_MASK);
        hmje_posix_input_push_event(event);
    }
}

/* ---- NSTextInputClient 뷰: IME(한글 조합 등)의 클라이언트 ------------------- */

@interface HmjeTextInputView : NSView <NSTextInputClient>
@property(nonatomic, strong) NSMutableAttributedString *markedText;
@end

@implementation HmjeTextInputView

- (BOOL)acceptsFirstResponder {
    return YES;
}

/* -- 입력(커밋/조합) -------------------------------------------------------- */

- (void)insertText:(id)string replacementRange:(NSRange)replacementRange {
    (void)replacementRange;
    NSString *plain = nil;
    if ([string isKindOfClass:[NSAttributedString class]]) {
        plain = [(NSAttributedString *)string string];
    } else if ([string isKindOfClass:[NSString class]]) {
        plain = (NSString *)string;
    }
    self.markedText = nil; /* 커밋되면 조합 상태는 끝 */
    push_text_string(plain);
}

- (void)setMarkedText:(id)string selectedRange:(NSRange)selectedRange replacementRange:(NSRange)replacementRange {
    (void)selectedRange;
    (void)replacementRange;
    /* v1: 조합 중 문자열은 보관만 하고 이벤트는 만들지 않는다(조합 표시는 후속). */
    if ([string isKindOfClass:[NSAttributedString class]]) {
        self.markedText = [[NSMutableAttributedString alloc] initWithAttributedString:(NSAttributedString *)string];
    } else if ([string isKindOfClass:[NSString class]]) {
        self.markedText = [[NSMutableAttributedString alloc] initWithString:(NSString *)string];
    } else {
        self.markedText = nil;
    }
    if (self.markedText != nil && [self.markedText length] == 0) {
        self.markedText = nil;
    }
}

- (void)unmarkText {
    /* IME가 조합을 그냥 확정시키라는 뜻 — 남아 있는 조합분을 커밋으로 취급한다. */
    NSString *pending = self.markedText ? [self.markedText string] : nil;
    self.markedText = nil;
    push_text_string(pending);
}

- (void)doCommandBySelector:(SEL)selector {
    /* 엔터/백스페이스/화살표 등은 KIND_KEY 스트림이 이미 전달한다 — 여기서는 무시.
     * (super로 넘기면 시스템 beep가 난다.) */
    (void)selector;
}

/* Menu clicks and keyboard equivalents converge on the same semantic input
 * events. HMJE, not this zero-sized proxy, owns the document and selection. */
- (void)selectAll:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_SELECT_ALL); }
- (void)copy:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_COPY); }
- (void)cut:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_CUT); }
- (void)paste:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_PASTE); }
- (void)undo:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_UNDO); }
- (void)redo:(id)sender { (void)sender; push_edit_command(HMJE_EDIT_REDO); }

/* -- 조합 상태 조회 --------------------------------------------------------- */

- (BOOL)hasMarkedText {
    return self.markedText != nil;
}

- (NSRange)markedRange {
    if (self.markedText == nil) {
        return NSMakeRange(NSNotFound, 0);
    }
    return NSMakeRange(0, [self.markedText length]);
}

- (NSRange)selectedRange {
    /* 문서 모델이 없으므로 항상 "끝에 삽입 중" 커서를 보고한다. */
    NSUInteger marked = self.markedText ? [self.markedText length] : 0;
    return NSMakeRange(marked, 0);
}

- (NSAttributedString *)attributedSubstringForProposedRange:(NSRange)range actualRange:(NSRangePointer)actualRange {
    (void)range;
    if (actualRange != NULL) {
        *actualRange = NSMakeRange(NSNotFound, 0);
    }
    return nil;
}

- (NSArray<NSAttributedStringKey> *)validAttributesForMarkedText {
    return @[];
}

- (NSRect)firstRectForCharacterRange:(NSRange)range actualRange:(NSRangePointer)actualRange {
    (void)range;
    if (actualRange != NULL) {
        *actualRange = NSMakeRange(NSNotFound, 0);
    }
    /* IME 후보창 위치용 — 창 좌하단 근처의 화면 좌표를 돌려준다. */
    NSWindow *window = [self window];
    if (window == nil) {
        return NSZeroRect;
    }
    NSRect rect = NSMakeRect(0, 0, 1, 16);
    rect = [self convertRect:rect toView:nil];
    return [window convertRectToScreen:rect];
}

- (NSUInteger)characterIndexForPoint:(NSPoint)point {
    (void)point;
    return 0;
}

@end

/* ---- posix_host_window.m가 부르는 2개 함수 --------------------------------- */

static HmjeTextInputView *g_text_view = nil;
static BOOL g_synth_text_delivered = NO;
static u64 g_synth_text_poll_count = 0;

static void synth_text_debug(void) {
    if (g_synth_text_delivered) {
        return;
    }
    const char *synth = getenv("HMJE_POSIX_SYNTH_TEXT");
    if (synth == NULL || synth[0] == '\0' || g_text_view == nil) {
        return;
    }
    NSString *text = [NSString stringWithUTF8String:synth];
    if (text != nil) {
        /* IME가 조합 확정 시 부르는 것과 정확히 같은 진입점을 쓴다. */
        [g_text_view insertText:text replacementRange:NSMakeRange(NSNotFound, 0)];
        g_synth_text_delivered = YES;
    }
}

/* 포인터 셀프테스트가 텍스트입력을 먼저 포커스한 뒤 확정 문자를 넣을 수 있게
 * 입력 poll 횟수로 지연한다. 환경변수가 없으면 기존처럼 attach 즉시 넣는다. */
void hmje_posix_text_input_selftest_tick(void) {
    const char *at = getenv("HMJE_POSIX_SYNTH_TEXT_AT");
    if (at == NULL || at[0] == '\0' || g_synth_text_delivered) {
        return;
    }
    g_synth_text_poll_count++;
    if (g_synth_text_poll_count >= strtoull(at, NULL, 10)) {
        synth_text_debug();
    }
}

void hmje_posix_text_input_attach(NSWindow *window) {
    if (window == nil || g_text_view != nil) {
        return;
    }
    @autoreleasepool {
        /* 화면에 아무것도 안 그리는 0x0 뷰 — first responder + NSTextInputClient 역할만. */
        HmjeTextInputView *view = [[HmjeTextInputView alloc] initWithFrame:NSZeroRect];
        [[window contentView] addSubview:view];
        [window makeFirstResponder:view];
        g_text_view = view;
        if (getenv("HMJE_POSIX_SYNTH_TEXT_AT") == NULL) {
            synth_text_debug();
        }
    }
}

/* 키 모니터 진입점. 이벤트를 소비하려면 nil을 반환한다(기존 동작 유지). */
NSEvent *hmje_posix_text_input_handle_event(NSEvent *event) {
    if (event == nil) {
        return nil;
    }
    NSEventType type = [event type];
    if (type == NSEventTypeFlagsChanged) {
        /* 수정자 키 자체의 down/up. 해당 keyCode의 플래그가 서 있으면 down. */
        NSEventModifierFlags flags = [event modifierFlags];
        unsigned short keyCode = [event keyCode];
        NSEventModifierFlags probe = 0;
        switch (keyCode) {
            case 56: case 60: probe = NSEventModifierFlagShift; break;   /* shift */
            case 59: case 62: probe = NSEventModifierFlagControl; break; /* control */
            case 58: case 61: probe = NSEventModifierFlagOption; break;  /* option */
            case 55: case 54: probe = NSEventModifierFlagCommand; break; /* command */
            case 57: probe = NSEventModifierFlagCapsLock; break;         /* caps lock */
            default: probe = 0; break;
        }
        BOOL pressed = probe != 0 && (flags & probe) != 0;
        push_key_event(keyCode, pressed, flags);
        return nil;
    }
    if (type == NSEventTypeKeyUp) {
        if (([event modifierFlags] & NSEventModifierFlagCommand) != 0) {
            NSString *characters = [[event charactersIgnoringModifiers] lowercaseString];
            if ([characters isEqualToString:@"a"] || [characters isEqualToString:@"c"] ||
                [characters isEqualToString:@"x"] || [characters isEqualToString:@"v"] ||
                [characters isEqualToString:@"z"] || [characters isEqualToString:@"q"] ||
                [characters isEqualToString:@"w"] || [characters isEqualToString:@"m"] ||
                [characters isEqualToString:@"h"]) return nil;
        }
        push_key_event([event keyCode], NO, [event modifierFlags]);
        return nil;
    }
    if (type != NSEventTypeKeyDown) {
        return event; /* 관심 없는 이벤트는 그대로 통과 */
    }

    NSEventModifierFlags flags = [event modifierFlags];
    if ((flags & NSEventModifierFlagCommand) != 0) {
        NSString *characters = [[event charactersIgnoringModifiers] lowercaseString];
        u64 command = 0;
        if ([characters isEqualToString:@"a"]) command = HMJE_EDIT_SELECT_ALL;
        else if ([characters isEqualToString:@"c"]) command = HMJE_EDIT_COPY;
        else if ([characters isEqualToString:@"x"]) command = HMJE_EDIT_CUT;
        else if ([characters isEqualToString:@"v"]) command = HMJE_EDIT_PASTE;
        else if ([characters isEqualToString:@"z"])
            command = (flags & NSEventModifierFlagShift) ? HMJE_EDIT_REDO : HMJE_EDIT_UNDO;
        if (command != 0) {
            push_edit_command(command);
            return nil;
        }
        /* App/window lifecycle belongs to the standard AppKit menus. Do not
         * also expose it as an application key hook. */
        if ([characters isEqualToString:@"q"] || [characters isEqualToString:@"w"] ||
            [characters isEqualToString:@"m"] || [characters isEqualToString:@"h"])
            return event;
    }
    BOOL shortcut = (flags & (NSEventModifierFlagCommand | NSEventModifierFlagControl)) != 0;
    if (!shortcut && g_text_view != nil) {
        /* IME(현재 입력 소스)로 라우팅 — 한글이면 조합, 확정 시 insertText:가 불려
         * KIND_TEXT가 이 keyDown의 KIND_KEY보다 먼저 큐잉된다. */
        NSTextInputContext *context = [g_text_view inputContext];
        if (context != nil) {
            [context handleEvent:event];
        }
    }
    push_key_event([event keyCode], YES, flags);
    return nil;
}
