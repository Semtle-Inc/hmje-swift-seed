/*
 * windows_window.c — SYS_FRAMEBUFFER_* / SYS_INPUT_POLL을 실제 Win32 창 + D3D11 스왑체인으로
 * 구현한다. windows_shim.c(순수 C, syscall 디스패치)가 extern으로 호출하는 4개 함수만
 * 외부에 노출한다(posix_host_shim.c ↔ posix_host_window.m과 같은 분리 원칙).
 *
 * 계약(library/docs/syscall.md, runtime/user/graphics.hmje)은 다른 hosted 백엔드와
 * 동일해야 한다:
 *   - blit(오프스크린 백버퍼 기록)과 present(commit)는 분리 — blit만으로는 화면에 안 보임.
 *   - 픽셀은 항상 canonical 0x00RRGGBB(리틀엔디안 자연수32 1픽셀, 메모리상 B,G,R,X).
 *
 * ── 표면 (GPU 렌더러 마일스톤 5, docs/gpu_renderer.md "표면" 단계) ────────────────────────
 * 표면은 D3D11 스왑체인(DXGI_FORMAT_B8G8R8A8_UNORM = canonical과 바이트 배치가 정확히
 * 같다 — Metal의 BGRA8Unorm과 동일한 이유로 스위즐 불필요, Android RGBX8888과 다른 점).
 * 기본 경로는 windows_d3d11_command_renderer.inc의 명령 버퍼/셰이더 실행이다.
 * GPU 작업 텍스처의 END만 retained staging과 스왑체인에 복사한다. CPU fallback은
 * 백버퍼를 STAGING 텍스처에 Map/memcpy한 뒤 표시하는 기존 계약을 유지한다.
 * WM_SIZE는 다음 메시지 펌프 끝에서 표면을 재생성하고, 입력보다 먼저
 * 공통 resize 이벤트를 전달한다. 최소화 중에는 마지막 유효 표면을 유지한다.
 *
 * ── API 스파이크 결과: D3D11 채택 (windows_shim.c 상단 주석 참고) ──────────────────────────
 * 이 VM(Parallels, arm64 Windows 11, "Parallels Display Adapter (WDDM)")에서 Vulkan은
 * ICD 미등록으로 vkCreateInstance가 VK_ERROR_INCOMPATIBLE_DRIVER를 반환해 기각됐다.
 * D3D11CreateDeviceAndSwapChain은 D3D_DRIVER_TYPE_HARDWARE만 허용한다. WARP는 D3D
 * API를 쓰지만 최종 픽셀을 CPU가 만드는 software rasterizer라 production GPU
 * backend로 간주하지 않는다.
 *
 * hmje 쪽 그리기 루프는 자체 imperative 루프를 돌리므로 Win32 메시지 루프를 블로킹으로
 * 소유하지 않는다 — 창을 lazily 만들고, present/input poll 때마다 PeekMessage로
 * non-blocking 드레인만 한다(posix_host_window.m의 "[NSApp run]을 안 부른다" 원칙과 동일).
 */

#define _WIN32_WINNT 0x0602
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS /* d3d11.h C 스타일 호출 매크로(ID3D11Device_CreateTexture2D 등)를 켠다 —
                      순수 C 컴파일에선 기본으로 안 켜져 있다(실측: 없으면 "undeclared
                      function"으로 링크 전에 컴파일 단계에서 실패). */
#include <windows.h>
#include <imm.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pointer_input.h"
#include "legacy_input.h"

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "imm32.lib")

typedef long long i64;
typedef unsigned long long u64;

#define HMJE_WINDOWS_ENOSYS_LOCAL (-38LL)

#define DEFAULT_WIDTH 1180
#define DEFAULT_HEIGHT 860
#define MIN_CLIENT_WIDTH 320
#define MIN_CLIENT_HEIGHT 240

static HWND g_hwnd = NULL;

i64 hmje_windows_ui_window_config(i64 title_address, i64 title_length, i64 flags) {
    if (g_hwnd == NULL || title_length < 0 || title_length > INT_MAX || (title_length > 0 && title_address == 0)) return -38;
    if (title_length > 0) {
        const char *utf8 = (const char *)(uintptr_t)(u64)title_address;
        int wide_length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, utf8, (int)title_length, NULL, 0);
        if (wide_length <= 0) return -22;
        wchar_t *wide = (wchar_t *)calloc((size_t)wide_length + 1u, sizeof(wchar_t));
        if (wide == NULL) return -12;
        if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, utf8, (int)title_length, wide, wide_length) <= 0) {
            free(wide);
            return -22;
        }
        SetWindowTextW(g_hwnd, wide);
        free(wide);
    }
    LONG_PTR style = GetWindowLongPtrW(g_hwnd, GWL_STYLE);
    if (((u64)flags & 1u) != 0) style &= ~WS_CAPTION;
    else style |= WS_CAPTION;
    SetWindowLongPtrW(g_hwnd, GWL_STYLE, style);
    SetWindowPos(g_hwnd, NULL, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    return 0;
}
static BOOL g_ready = FALSE;
static BOOL g_closed = FALSE;
static BOOL g_resize_pending = FALSE;
/* Like the macOS surface, geometry is acknowledged by INPUT_POLL, not by a
 * bounded event queue. A pointer storm cannot discard the only resize notice. */
static u64 g_acked_width = 0, g_acked_height = 0;

static u64 g_width = 0;
static u64 g_height = 0;
static u64 g_pitch = 0;
static unsigned char *g_backbuffer = NULL; /* canonical 0x00RRGGBB, LE u32/px, malloc */

static void hmje_d3d_resize_invalidate(void);

static ID3D11Device *g_device = NULL;
static ID3D11DeviceContext *g_context = NULL;
static IDXGISwapChain *g_swapchain = NULL;
static ID3D11Texture2D *g_backbuffer_tex = NULL;   /* 스왑체인 소유, DEFAULT usage */
static ID3D11Texture2D *g_staging_tex = NULL;       /* CPU 쓰기용, STAGING usage */
/* The staging texture retains the last committed frame; g_backbuffer may
 * already contain newer blits that must remain invisible until present. */
static BOOL g_has_presented_frame = FALSE;
static BOOL g_repaint_pending = FALSE;
static i64 present_staging_frame(void);

#define HMJE_INPUT_KIND_SHIFT HMJE_LEGACY_INPUT_KIND_SHIFT
#define HMJE_INPUT_KIND_POINTER_MOVE HMJE_LEGACY_INPUT_KIND_POINTER_MOVE
#define HMJE_INPUT_KIND_POINTER_BUTTON HMJE_LEGACY_INPUT_KIND_POINTER_BUTTON
#define HMJE_INPUT_KIND_POINTER_SCROLL 3ull
#define HMJE_INPUT_KIND_APP_CLOSE 6ull
#define HMJE_INPUT_POINTER_COORD_MASK 16777215ull
#define HMJE_INPUT_POINTER_Y_SHIFT 24
#define HMJE_INPUT_POINTER_BUTTON_SHIFT 48
#define HMJE_INPUT_POINTER_PRESSED_FLAG (1ull << 55)
#define HMJE_INPUT_SCROLL_DOWN_FLAG (1ull << 55)

static hmje_pointer_ring g_pointer_samples;
static hmje_legacy_input_ring g_legacy_input;
/* 현재 HWND 생성/메시지 펌프/SYS_INPUT_POLL은 같은 HMJE thread에서 돌지만,
 * SendMessage 계열이나 향후 전용 UI thread로 소유권이 바뀌어도 동적 성장 중
 * push/pop이 경쟁하지 않도록 큐 자체의 동시성 계약을 명시적으로 지킨다. */
static SRWLOCK g_legacy_lock = SRWLOCK_INIT;

static void legacy_input_push(u64 value) {
    AcquireSRWLockExclusive(&g_legacy_lock);
    hmje_legacy_input_ring_push(&g_legacy_input, value);
    ReleaseSRWLockExclusive(&g_legacy_lock);
}

static i64 legacy_input_pop(void) {
    AcquireSRWLockExclusive(&g_legacy_lock);
    i64 value = hmje_legacy_input_ring_pop(&g_legacy_input);
    ReleaseSRWLockExclusive(&g_legacy_lock);
    return value;
}

static WCHAR g_pending_high_surrogate;
static u64 g_text_input_request;

#define HMJE_INPUT_KIND_EDIT_COMMAND 7ULL
#define HMJE_EDIT_SELECT_ALL 1ULL
#define HMJE_EDIT_COPY 2ULL
#define HMJE_EDIT_CUT 3ULL
#define HMJE_EDIT_PASTE 4ULL
#define HMJE_EDIT_UNDO 5ULL
#define HMJE_EDIT_REDO 6ULL

static void edit_command_push(u64 command) {
    legacy_input_push((HMJE_INPUT_KIND_EDIT_COMMAND << HMJE_INPUT_KIND_SHIFT)
                      | (command & 255ULL));
}

static BOOL handle_windows_shortcut(HWND hwnd, UINT msg, WPARAM key, LPARAM detail) {
    BOOL down = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
    if (!(GetKeyState(VK_CONTROL) & 0x8000)) return FALSE;
    if (key == 'Q' || key == 'W') {
        if (down && !(detail & (1LL << 30))) DestroyWindow(hwnd);
        return TRUE;
    }
    u64 command = 0;
    if (key == 'A') command = HMJE_EDIT_SELECT_ALL;
    else if (key == 'C') command = HMJE_EDIT_COPY;
    else if (key == 'X') command = HMJE_EDIT_CUT;
    else if (key == 'V') command = HMJE_EDIT_PASTE;
    else if (key == 'Y') command = HMJE_EDIT_REDO;
    else if (key == 'Z') command = (GetKeyState(VK_SHIFT) & 0x8000) ? HMJE_EDIT_REDO : HMJE_EDIT_UNDO;
    if (command == 0) return FALSE;
    if (down && !(detail & (1LL << 30))) edit_command_push(command);
    return TRUE;
}

static void committed_scalar_push(u64 scalar) {
    /* Editing controls are delivered only as physical keys. WM_CHAR can also
     * carry Ctrl+A/backspace/return; inserting these would duplicate edits. */
    if (scalar < 32 || scalar == 127 || scalar > 0x10ffff ||
        (scalar >= 0xd800 && scalar <= 0xdfff)) return;
    legacy_input_push((4ull << HMJE_INPUT_KIND_SHIFT) | scalar);
}

static void committed_utf16_push(WCHAR unit) {
    if (unit >= 0xd800 && unit <= 0xdbff) {
        if (g_pending_high_surrogate) committed_scalar_push(0xfffd);
        g_pending_high_surrogate = unit;
        return;
    }
    if (unit >= 0xdc00 && unit <= 0xdfff) {
        if (g_pending_high_surrogate) {
            committed_scalar_push(0x10000 + ((u64)(g_pending_high_surrogate - 0xd800) << 10)
                                  + (unit - 0xdc00));
            g_pending_high_surrogate = 0;
        } else committed_scalar_push(0xfffd);
        return;
    }
    if (g_pending_high_surrogate) committed_scalar_push(0xfffd);
    g_pending_high_surrogate = 0;
    committed_scalar_push(unit);
}

static u64 windows_key_event(WPARAM key, LPARAM detail, BOOL down) {
    u64 scan = ((u64)detail >> 16) & 255;
    if (scan == 0) scan = MapVirtualKeyW((UINT)key, MAPVK_VK_TO_VSC) & 255;
    /* Hosted control aliases avoid collisions in the UI's shared macOS/set-1
     * editor. In particular set-1 comma is macOS backspace; hosted Caps Lock
     * must not enable the QEMU-only Korean keyboard composer. */
    if (key == VK_TAB) scan = 250;
    else if (key == VK_RETURN) scan = 251;
    else if (key == VK_SPACE) scan = 252;
    else if (key == VK_OEM_COMMA) scan = 253;
    else if (key == VK_CAPITAL) scan = 254;
    u64 value = scan | (down ? 256ull : 0);
    if (GetKeyState(VK_SHIFT) & 0x8000) value |= 1ull << 16;
    if (GetKeyState(VK_CONTROL) & 0x8000) value |= 1ull << 17;
    if (GetKeyState(VK_MENU) & 0x8000) value |= 1ull << 18;
    if ((GetKeyState(VK_LWIN) | GetKeyState(VK_RWIN)) & 0x8000) value |= 1ull << 19;
    return value;
}

i64 hmje_windows_text_input_control(i64 request) {
    u64 next = (u64)request;
    /* The safe-area bit is irrelevant for a desktop window and must not
     * cancel an in-progress composition on the same text client. */
    if (((next ^ g_text_input_request) & ~2ull) != 0) {
        g_pending_high_surrogate = 0;
        if (g_hwnd) {
            HIMC context = ImmGetContext(g_hwnd);
            if (context) {
                ImmNotifyIME(context, NI_COMPOSITIONSTR, CPS_CANCEL, 0);
                ImmReleaseContext(g_hwnd, context);
            }
            ImmAssociateContextEx(g_hwnd, NULL, (next & 1) ? IACE_DEFAULT : 0);
        }
    }
    g_text_input_request = next;
    return 1;
}

static u64 legacy_pointer_event(u64 kind, u64 x, u64 y, u64 button, BOOL down) {
    u64 value = (kind << HMJE_INPUT_KIND_SHIFT)
              | (x & HMJE_INPUT_POINTER_COORD_MASK)
              | ((y & HMJE_INPUT_POINTER_COORD_MASK) << HMJE_INPUT_POINTER_Y_SHIFT)
              | ((button & 0x7full) << HMJE_INPUT_POINTER_BUTTON_SHIFT);
    if (down) value |= HMJE_INPUT_POINTER_PRESSED_FLAG;
    return value;
}

static void windows_pointer_push(
    u64 phase, u64 pointer_id, i64 x, i64 y, u64 buttons, u64 changed_button,
    u64 pressure, u64 altitude, u64 azimuth, i64 scroll_x, i64 scroll_y,
    u64 tool, u64 flags
) {
    hmje_pointer_record record;
    memset(&record, 0, sizeof(record));
    record.phase = phase;
    record.pointer_id = pointer_id;
    record.x = x;
    record.y = y;
    record.time_us = (u64)GetTickCount64() * 1000u;
    record.buttons = buttons;
    record.changed_button = changed_button;
    record.pressure = pressure;
    record.altitude = altitude;
    record.azimuth = azimuth;
    record.scroll_x = scroll_x;
    record.scroll_y = scroll_y;
    record.tool = tool;
    record.flags = flags;
    hmje_pointer_ring_push(&g_pointer_samples, record);
}

static u64 win_buttons(WPARAM wparam) {
    u64 buttons = 0;
    if (wparam & MK_LBUTTON) buttons |= 1u;
    if (wparam & MK_RBUTTON) buttons |= 2u;
    if (wparam & MK_MBUTTON) buttons |= 4u;
    return buttons;
}

static int is_promoted_pointer_message(void) {
    return ((u64)GetMessageExtraInfo() & 0xffffff00ull) == 0xff515700ull;
}

static void handle_mouse_pointer(UINT msg, WPARAM wparam, LPARAM lparam) {
    if (is_promoted_pointer_message()) return;
    POINT point = {(LONG)(short)LOWORD(lparam), (LONG)(short)HIWORD(lparam)};
    if (msg == WM_MOUSEWHEEL || msg == WM_MOUSEHWHEEL) {
        ScreenToClient(g_hwnd, &point);
    }
    i64 x = point.x < 0 ? 0 : point.x;
    i64 y = point.y < 0 ? 0 : point.y;
    u64 buttons = win_buttons(wparam);
    if (msg == WM_MOUSEMOVE) {
        u64 phase = buttons == 0 ? HMJE_POINTER_PHASE_HOVER : HMJE_POINTER_PHASE_MOVE;
        windows_pointer_push(phase, 1u, x, y, buttons, 0u, 0u, 0u, 0u, 0, 0,
                             HMJE_POINTER_TOOL_MOUSE, HMJE_POINTER_CAP_BUTTONS);
        legacy_input_push(legacy_pointer_event(HMJE_INPUT_KIND_POINTER_MOVE, (u64)x, (u64)y, 0u, FALSE));
        return;
    }
    if (msg == WM_MOUSEWHEEL || msg == WM_MOUSEHWHEEL) {
        i64 delta = (i64)GET_WHEEL_DELTA_WPARAM(wparam) / WHEEL_DELTA;
        i64 sx = msg == WM_MOUSEHWHEEL ? delta : 0;
        i64 sy = msg == WM_MOUSEWHEEL ? delta : 0;
        windows_pointer_push(HMJE_POINTER_PHASE_SCROLL, 1u, x, y, buttons, 0u,
                             0u, 0u, 0u, sx, sy, HMJE_POINTER_TOOL_MOUSE,
                             HMJE_POINTER_CAP_BUTTONS | HMJE_POINTER_CAP_SCROLL);
        u64 amount = (u64)(delta < 0 ? -delta : delta);
        u64 packed = (HMJE_INPUT_KIND_POINTER_SCROLL << HMJE_INPUT_KIND_SHIFT)
                   | (amount & HMJE_INPUT_POINTER_COORD_MASK);
        if (delta < 0) packed |= HMJE_INPUT_SCROLL_DOWN_FLAG;
        legacy_input_push(packed);
        return;
    }
    BOOL down = msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN || msg == WM_MBUTTONDOWN;
    if (down) { SetFocus(g_hwnd); SetCapture(g_hwnd); }
    else if (buttons == 0 && GetCapture() == g_hwnd) ReleaseCapture();
    u64 button = (msg == WM_RBUTTONDOWN || msg == WM_RBUTTONUP) ? 1u
               : (msg == WM_MBUTTONDOWN || msg == WM_MBUTTONUP) ? 2u : 0u;
    windows_pointer_push(down ? HMJE_POINTER_PHASE_DOWN : HMJE_POINTER_PHASE_UP,
                         1u, x, y, buttons, button, 0u, 0u, 0u, 0, 0,
                         HMJE_POINTER_TOOL_MOUSE, HMJE_POINTER_CAP_BUTTONS);
    legacy_input_push(legacy_pointer_event(HMJE_INPUT_KIND_POINTER_MOVE, (u64)x, (u64)y, 0u, FALSE));
    legacy_input_push(legacy_pointer_event(HMJE_INPUT_KIND_POINTER_BUTTON, (u64)x, (u64)y, button, down));
}

static void handle_native_pointer(UINT msg, WPARAM wparam) {
    UINT32 pointer_id = GET_POINTERID_WPARAM(wparam);
    POINTER_INFO info;
    if (!GetPointerInfo(pointer_id, &info)) return;
    POINT point = info.ptPixelLocation;
    ScreenToClient(g_hwnd, &point);
    u64 phase = msg == WM_POINTERDOWN ? HMJE_POINTER_PHASE_DOWN
              : msg == WM_POINTERUP ? HMJE_POINTER_PHASE_UP
              : (info.pointerFlags & POINTER_FLAG_INCONTACT) ? HMJE_POINTER_PHASE_MOVE
              : HMJE_POINTER_PHASE_HOVER;
    u64 buttons = (info.pointerFlags & POINTER_FLAG_FIRSTBUTTON) ? 1u : 0u;
    u64 tool = HMJE_POINTER_TOOL_UNKNOWN;
    u64 pressure = 0, altitude = 0, azimuth = 0;
    u64 flags = HMJE_POINTER_CAP_BUTTONS;
    if (info.pointerType == PT_PEN) {
        POINTER_PEN_INFO pen;
        tool = HMJE_POINTER_TOOL_PEN;
        if (GetPointerPenInfo(pointer_id, &pen)) {
            if (pen.penFlags & PEN_FLAG_ERASER) tool = HMJE_POINTER_TOOL_ERASER;
            pressure = ((u64)pen.pressure * 65535u) / 1024u;
            altitude = ((u64)(90 - min(90, abs(pen.tiltY))) * 65535u) / 90u;
            azimuth = ((u64)((pen.rotation % 360 + 360) % 360) * 65535u) / 360u;
            flags |= HMJE_POINTER_CAP_PRESSURE | HMJE_POINTER_CAP_ALTITUDE | HMJE_POINTER_CAP_AZIMUTH;
        }
    } else if (info.pointerType == PT_TOUCH) {
        tool = HMJE_POINTER_TOOL_TOUCH;
    } else if (info.pointerType == PT_MOUSE) {
        tool = HMJE_POINTER_TOOL_MOUSE;
    }
    windows_pointer_push(phase, pointer_id, point.x, point.y, buttons, 0u,
                         pressure, altitude, azimuth, 0, 0, tool, flags);
    u64 x = point.x < 0 ? 0u : (u64)point.x;
    u64 y = point.y < 0 ? 0u : (u64)point.y;
    legacy_input_push(legacy_pointer_event(HMJE_INPUT_KIND_POINTER_MOVE, x, y, 0u, FALSE));
    if (phase == HMJE_POINTER_PHASE_DOWN || phase == HMJE_POINTER_PHASE_UP) {
        legacy_input_push(legacy_pointer_event(HMJE_INPUT_KIND_POINTER_BUTTON, x, y, 0u,
                                               phase == HMJE_POINTER_PHASE_DOWN));
    }
}

static LRESULT CALLBACK window_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    switch (msg) {
    case WM_GETMINMAXINFO: {
        RECT minimum = {0, 0, MIN_CLIENT_WIDTH, MIN_CLIENT_HEIGHT};
        AdjustWindowRect(&minimum, WS_OVERLAPPEDWINDOW, FALSE);
        MINMAXINFO *limits = (MINMAXINFO *)lparam;
        limits->ptMinTrackSize.x = minimum.right - minimum.left;
        limits->ptMinTrackSize.y = minimum.bottom - minimum.top;
        return 0;
    }
    case WM_SIZE:
        /* D3D can itself dispatch messages. Coalesce here; recreate resources
         * outside window_proc after the message queue has drained. A restored
         * window can have exactly the old size but still needs a repaint. */
        if (wparam != SIZE_MINIMIZED) {
            g_resize_pending = TRUE;
            if (g_has_presented_frame) g_repaint_pending = TRUE;
        }
        return 0;
    case WM_ERASEBKGND:
        if (g_has_presented_frame) return 1;
        return DefWindowProcW(hwnd, msg, wparam, lparam);
    case WM_PAINT: {
        PAINTSTRUCT paint;
        BeginPaint(hwnd, &paint);
        EndPaint(hwnd, &paint);
        if (g_has_presented_frame) g_repaint_pending = TRUE;
        return 0;
    }
    case WM_KEYDOWN: case WM_KEYUP:
    case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        if (handle_windows_shortcut(hwnd, msg, wparam, lparam)) return 0;
        legacy_input_push(windows_key_event(wparam, lparam,
                          msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN));
        /* Preserve Windows system shortcuts such as Alt+F4. */
        if (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP)
            return DefWindowProcW(hwnd, msg, wparam, lparam);
        return 0;
    case WM_CHAR:
        committed_utf16_push((WCHAR)wparam);
        return 0;
    case WM_UNICHAR:
        if (wparam == UNICODE_NOCHAR) return TRUE;
        g_pending_high_surrogate = 0;
        committed_scalar_push((u64)wparam);
        return 0;
    case WM_KILLFOCUS:
        g_pending_high_surrogate = 0;
        return DefWindowProcW(hwnd, msg, wparam, lparam);
    case WM_MOUSEMOVE:
    case WM_LBUTTONDOWN: case WM_LBUTTONUP:
    case WM_RBUTTONDOWN: case WM_RBUTTONUP:
    case WM_MBUTTONDOWN: case WM_MBUTTONUP:
    case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        handle_mouse_pointer(msg, wparam, lparam);
        return 0;
    case WM_POINTERDOWN: case WM_POINTERUPDATE: case WM_POINTERUP:
        handle_native_pointer(msg, wparam);
        return 0;
    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        g_closed = TRUE;
        legacy_input_push(HMJE_INPUT_KIND_APP_CLOSE << HMJE_INPUT_KIND_SHIFT);
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wparam, lparam);
    }
}

static BOOL init_d3d11(void) {
    DXGI_SWAP_CHAIN_DESC desc;
    memset(&desc, 0, sizeof(desc));
    desc.BufferCount = 1;
    desc.BufferDesc.Width = (UINT)g_width;
    desc.BufferDesc.Height = (UINT)g_height;
    desc.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.BufferDesc.RefreshRate.Numerator = 60;
    desc.BufferDesc.RefreshRate.Denominator = 1;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.OutputWindow = g_hwnd;
    desc.SampleDesc.Count = 1;
    desc.SampleDesc.Quality = 0;
    desc.Windowed = TRUE;
    /* This presenter is event-driven, including idle restore paints. Retain
     * the committed backbuffer across presentation instead of DISCARD's
     * undefined contents when DWM re-exposes the restored window. */
    desc.SwapEffect = DXGI_SWAP_EFFECT_SEQUENTIAL;

    D3D_FEATURE_LEVEL feature_levels[] = {
        D3D_FEATURE_LEVEL_11_0,
        D3D_FEATURE_LEVEL_10_1,
        D3D_FEATURE_LEVEL_10_0,
    };
    D3D_FEATURE_LEVEL obtained_level;

    /* The existing presenter requires a hardware swapchain. CPU display-list
     * interpretation is separately and explicitly advertised by QUERY. */
    D3D_DRIVER_TYPE driver_types[] = {D3D_DRIVER_TYPE_HARDWARE};
    HRESULT hr = E_FAIL;
    for (int i = 0; i < 1; i++) {
        hr = D3D11CreateDeviceAndSwapChain(
            NULL, driver_types[i], NULL, 0,
            feature_levels, ARRAYSIZE(feature_levels), D3D11_SDK_VERSION,
            &desc, &g_swapchain, &g_device, &obtained_level, &g_context);
        if (SUCCEEDED(hr)) {
            fprintf(stderr, "windows-surface: D3D11 device created (driver_type=%d, feature_level=0x%x)\n",
                    (int)driver_types[i], (unsigned)obtained_level);
            break;
        }
    }
    if (FAILED(hr)) {
        fprintf(stderr, "windows-surface: D3D11CreateDeviceAndSwapChain failed, hr=0x%08lx\n", (unsigned long)hr);
        return FALSE;
    }

    hr = IDXGISwapChain_GetBuffer(g_swapchain, 0, &IID_ID3D11Texture2D, (void **)&g_backbuffer_tex);
    if (FAILED(hr)) {
        fprintf(stderr, "windows-surface: GetBuffer failed, hr=0x%08lx\n", (unsigned long)hr);
        return FALSE;
    }

    D3D11_TEXTURE2D_DESC staging_desc;
    memset(&staging_desc, 0, sizeof(staging_desc));
    staging_desc.Width = (UINT)g_width;
    staging_desc.Height = (UINT)g_height;
    staging_desc.MipLevels = 1;
    staging_desc.ArraySize = 1;
    staging_desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    staging_desc.SampleDesc.Count = 1;
    staging_desc.Usage = D3D11_USAGE_STAGING;
    staging_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    hr = ID3D11Device_CreateTexture2D(g_device, &staging_desc, NULL, &g_staging_tex);
    if (FAILED(hr)) {
        fprintf(stderr, "windows-surface: CreateTexture2D(staging) failed, hr=0x%08lx\n", (unsigned long)hr);
        return FALSE;
    }

    return TRUE;
}

/* Prepare replacement storage before touching the live surface. Copy committed
 * staging pixels separately from pending CPU blits, so resize/restore never
 * commits unfinished drawing. New space starts black, overlap keeps its pixels. */
static BOOL resize_surface(void) {
    if (!g_resize_pending || !g_ready || g_closed || IsIconic(g_hwnd)) return TRUE;
    RECT client;
    if (!GetClientRect(g_hwnd, &client)) return FALSE;
    LONG width = client.right - client.left, height = client.bottom - client.top;
    if (width <= 0 || height <= 0) return TRUE;
    if ((u64)width == g_width && (u64)height == g_height && g_backbuffer_tex) {
        g_resize_pending = FALSE;
        return TRUE;
    }
    if (!g_device || !g_context || !g_swapchain || !g_staging_tex ||
        (u64)width > SIZE_MAX / 4 || (u64)height > SIZE_MAX / ((u64)width * 4)) return FALSE;
    hmje_d3d_resize_invalidate();
    u64 pitch = (u64)width * 4;
    unsigned char *pixels = (unsigned char *)calloc((size_t)height, (size_t)pitch);
    if (!pixels) return FALSE;
    ID3D11Texture2D *staging = NULL;
    D3D11_TEXTURE2D_DESC description;
    ID3D11Texture2D_GetDesc(g_staging_tex, &description);
    description.Width = (UINT)width;
    description.Height = (UINT)height;
    D3D11_SUBRESOURCE_DATA initial = {pixels, (UINT)pitch, 0};
    HRESULT hr = ID3D11Device_CreateTexture2D(g_device, &description, &initial, &staging);
    if (FAILED(hr)) goto failed;
    u64 copy_width = min(g_width, (u64)width), copy_height = min(g_height, (u64)height);
    for (u64 row = 0; row < copy_height; ++row)
        memcpy(pixels + row * pitch, g_backbuffer + row * g_pitch, (size_t)copy_width * 4);
    if (g_has_presented_frame) {
        D3D11_BOX overlap = {0, 0, 0, (UINT)copy_width, (UINT)copy_height, 1};
        ID3D11DeviceContext_CopySubresourceRegion(g_context, (ID3D11Resource *)staging,
            0, 0, 0, 0, (ID3D11Resource *)g_staging_tex, 0, &overlap);
    }
    /* ResizeBuffers requires all old swapchain-buffer references/bindings to
     * be released. STAGING textures are independent resources. */
    ID3D11DeviceContext_ClearState(g_context);
    if (g_backbuffer_tex) ID3D11Texture2D_Release(g_backbuffer_tex);
    g_backbuffer_tex = NULL;
    hr = IDXGISwapChain_ResizeBuffers(g_swapchain, 0, (UINT)width, (UINT)height,
                                     DXGI_FORMAT_UNKNOWN, 0);
    if (FAILED(hr)) {
        (void)IDXGISwapChain_GetBuffer(g_swapchain, 0, &IID_ID3D11Texture2D,
                                       (void **)&g_backbuffer_tex);
        goto failed;
    }
    hr = IDXGISwapChain_GetBuffer(g_swapchain, 0, &IID_ID3D11Texture2D,
                                  (void **)&g_backbuffer_tex);
    if (FAILED(hr)) goto failed;
    ID3D11Texture2D_Release(g_staging_tex);
    free(g_backbuffer);
    g_staging_tex = staging;
    g_backbuffer = pixels;
    g_width = (u64)width;
    g_height = (u64)height;
    g_pitch = pitch;
    g_resize_pending = FALSE;
    if (g_has_presented_frame) g_repaint_pending = TRUE;
    return TRUE;
failed:
    fprintf(stderr, "windows-surface: resize %ldx%ld failed, hr=0x%08lx\n",
            width, height, (unsigned long)hr);
    if (staging) ID3D11Texture2D_Release(staging);
    free(pixels);
    /* Preserve published geometry and retry on the next pump. If GetBuffer
     * failed after ResizeBuffers, no mismatched texture can be presented. */
    return FALSE;
}

static i64 surface_resize_event_if_needed(void) {
    if (!g_ready || g_closed || g_resize_pending || g_width == 0 || g_height == 0 ||
        (g_width == g_acked_width && g_height == g_acked_height)) return 0;
    g_acked_width = g_width;
    g_acked_height = g_height;
    return (i64)((5ull << HMJE_INPUT_KIND_SHIFT) | (1ull << 48) |
                 ((g_height & HMJE_INPUT_POINTER_COORD_MASK) << 24) |
                 (g_width & HMJE_INPUT_POINTER_COORD_MASK));
}

static void ensure_window(void) {
    if (g_ready) {
        return;
    }

    WNDCLASSEXW wc;
    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = window_proc;
    wc.hInstance = GetModuleHandleW(NULL);
    wc.hCursor = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"HmjeWindowsHostWindowClass";
    RegisterClassExW(&wc);

    RECT rect = {0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT};
    DWORD style = WS_OVERLAPPEDWINDOW;
    AdjustWindowRect(&rect, style, FALSE);

    g_hwnd = CreateWindowExW(0, wc.lpszClassName, L"semtleOS windows-host (D3D11)",
                              style, CW_USEDEFAULT, CW_USEDEFAULT,
                              rect.right - rect.left, rect.bottom - rect.top,
                              NULL, NULL, wc.hInstance, NULL);

    if (!g_hwnd) return;
    RECT client;
    GetClientRect(g_hwnd, &client);
    g_width = (u64)(client.right - client.left);
    g_height = (u64)(client.bottom - client.top);
    g_pitch = g_width * 4;
    g_backbuffer = (unsigned char *)calloc(1, (size_t)(g_pitch * g_height));

    fprintf(stderr, "windows-surface: window created %llux%llu\n",
            (unsigned long long)g_width, (unsigned long long)g_height);

    if (!g_backbuffer || !init_d3d11()) {
        fprintf(stderr, "windows-surface: D3D11 init failed — framebuffer syscalls will report ENOSYS\n");
    }

    ShowWindow(g_hwnd, SW_SHOW);
    UpdateWindow(g_hwnd);
    g_ready = TRUE;
    g_acked_width = g_width;
    g_acked_height = g_height;
    g_resize_pending = FALSE;
}

static void pump_messages(void) {
    MSG msg;
    while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    (void)resize_surface();
    /* Present outside window_proc to avoid re-entering the D3D presenter while
     * it dispatches Win32 messages. A restored idle app needs no new HMJE draw. */
    if (g_repaint_pending && g_has_presented_frame && !g_closed && !IsIconic(g_hwnd)) {
        g_repaint_pending = FALSE;
        /* Restore can report S_OK from Present before DWM has re-exposed its
         * surface. Wait for that compositor transition, then publish the
         * retained frame once; no periodic redraw or pending-blit upload. */
        HRESULT flush_result = DwmFlush();
        if (FAILED(flush_result))
            fprintf(stderr, "windows-surface: DwmFlush failed, hr=0x%08lx\n",
                    (unsigned long)flush_result);
        (void)present_staging_frame();
    }
}

/* ---- windows_shim.c 가 부르는 4개 함수 ------------------------------------------------ */

i64 hmje_windows_framebuffer_info(i64 out_address, i64 out_length) {
    if (out_address == 0 || out_length < 48) {
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    ensure_window();
    if (g_hwnd == NULL || g_backbuffer == NULL || g_device == NULL) {
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    u64 *out = (u64 *)(uintptr_t)(u64)out_address;
    out[0] = g_width;
    out[1] = g_height;
    out[2] = g_pitch;
    out[3] = 4; /* pixel_bytes */
    out[4] = 1; /* FRAMEBUFFER_FORMAT_XRGB8888 (canonical) */
    out[5] = 1; /* FRAMEBUFFER_FLAG_PRESENT */
    if (out_length >= 56) {
        out[6] = 1; /* v2 확장: scale — DPI 인식은 이 마일스톤 범위 밖, 항상 1
                       (semtleOS 자체도 배율=1로 후일 구현하는 것과 같은 원칙, docs/gpu_renderer.md) */
        return 56;
    }
    return 48;
}

i64 hmje_windows_framebuffer_blit(i64 buffer_address, i64 width, i64 height, i64 pitch, i64 x, i64 y) {
    ensure_window();
    if (g_backbuffer == NULL || buffer_address == 0 || width <= 0 || height <= 0 || pitch <= 0) {
        return 0;
    }
    u64 uw = (u64)width, uh = (u64)height, upitch = (u64)pitch;
    if (uw > SIZE_MAX / 4 || upitch < uw * 4 || uh > SIZE_MAX / upitch) {
        return 0;
    }
    u64 ux = (u64)x, uy = (u64)y;
    if (ux >= g_width || uy >= g_height) {
        return 0;
    }
    u64 copy_w = uw;
    if (ux + copy_w > g_width) {
        copy_w = g_width - ux;
    }
    u64 copy_h = uh;
    if (uy + copy_h > g_height) {
        copy_h = g_height - uy;
    }
    if (copy_w == 0 || copy_h == 0) {
        return 0;
    }
    const unsigned char *src_base = (const unsigned char *)(uintptr_t)(u64)buffer_address;
    i64 total = 0;
    for (u64 row = 0; row < copy_h; row++) {
        const unsigned char *src_row = src_base + row * upitch;
        unsigned char *dst_row = g_backbuffer + (uy + row) * g_pitch + ux * 4;
        size_t bytes = (size_t)(copy_w * 4);
        memcpy(dst_row, src_row, bytes);
        total += (i64)bytes;
    }
    return total;
}

/* D3D11 present: CPU 백버퍼(malloc) → STAGING 텍스처(Map/memcpy) → CopyResource →
 * 스왑체인 백버퍼(DEFAULT) → Present(vsync). Metal의 "shared buffer → blit encoder →
 * drawable" 자리(파일 상단 주석 참고), 셰이더 없는 순수 업로드/블릿 단계. */
static i64 present_staging_frame(void) {
    if (g_device == NULL || g_staging_tex == NULL || g_backbuffer_tex == NULL) {
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    ID3D11DeviceContext_CopyResource(g_context, (ID3D11Resource *)g_backbuffer_tex,
                                      (ID3D11Resource *)g_staging_tex);
    HRESULT hr = IDXGISwapChain_Present(g_swapchain, 1, 0);
    if (hr == DXGI_STATUS_OCCLUDED) g_repaint_pending = TRUE;
    if (FAILED(hr)) {
        fprintf(stderr, "windows-surface: Present failed, hr=0x%08lx\n", (unsigned long)hr);
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    return 1;
}

static i64 present_d3d11(void) {
    if (g_device == NULL || g_staging_tex == NULL || g_backbuffer_tex == NULL) {
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    D3D11_MAPPED_SUBRESOURCE mapped;
    HRESULT hr = ID3D11DeviceContext_Map(g_context, (ID3D11Resource *)g_staging_tex, 0,
                                          D3D11_MAP_WRITE, 0, &mapped);
    if (FAILED(hr)) {
        return HMJE_WINDOWS_ENOSYS_LOCAL;
    }
    unsigned char *dst_base = (unsigned char *)mapped.pData;
    size_t row_bytes = (size_t)(g_width * 4);
    for (u64 row = 0; row < g_height; row++) {
        memcpy(dst_base + row * mapped.RowPitch, g_backbuffer + row * g_pitch, row_bytes);
    }
    ID3D11DeviceContext_Unmap(g_context, (ID3D11Resource *)g_staging_tex, 0);

    g_repaint_pending = FALSE;
    i64 result = present_staging_frame();
    if (result > 0) {
        g_has_presented_frame = TRUE;
    }
    return result;
}

i64 hmje_windows_framebuffer_present(i64 rects_address, i64 count) {
    ensure_window();
    (void)rects_address;
    if (count <= 0 || g_closed) {
        return 0;
    }
    i64 result = present_d3d11();
    pump_messages();
    return result;
}

i64 hmje_windows_input_poll(void) {
    ensure_window();
    pump_messages();
    i64 resize = surface_resize_event_if_needed();
    return resize != 0 ? resize : legacy_input_pop();
}

i64 hmje_windows_input_poll2(i64 out_address, i64 out_length) {
    ensure_window();
    pump_messages();
    return hmje_pointer_ring_pop(&g_pointer_samples, out_address, out_length);
}

#include "windows_d3d11_command_renderer.inc"

/* AppsUseLightTheme follows Windows Settings; dynamically load the registry API
 * so ordinary/headless target link recipes need no new DLL import library. */
i64 hmje_windows_system_theme(void) {
    typedef LSTATUS (WINAPI *GetValue)(HKEY, LPCWSTR, LPCWSTR, DWORD, LPDWORD, PVOID, LPDWORD);
    HMODULE module = LoadLibraryW(L"advapi32.dll");
    if (module == NULL) return 0;
    GetValue query = (GetValue)(void *)GetProcAddress(module, "RegGetValueW");
    DWORD light = 1, bytes = sizeof(light);
    LSTATUS status = query == NULL ? ERROR_PROC_NOT_FOUND : query(HKEY_CURRENT_USER,
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
        L"AppsUseLightTheme", RRF_RT_REG_DWORD, NULL, &light, &bytes);
    FreeLibrary(module);
    return status == ERROR_SUCCESS ? (light ? 1 : 2) : 0;
}
