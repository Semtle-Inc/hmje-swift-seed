/*
 * posix_host_window.m — SYS_FRAMEBUFFER_* / SYS_INPUT_POLL을 실제 Cocoa 창으로 구현한다.
 * posix_host_shim.c(순수 C)에서 extern으로 호출하는 4개 함수만 외부에 노출한다.
 *
 * 계약(library/docs/syscall.md, runtime/user/graphics.hmje)은 이미 존재하는 x86 linear-fb /
 * aarch64 virtio-gpu 백엔드와 동일해야 한다:
 *   - blit(오프스크린 백버퍼 기록)과 present(commit)는 분리 — blit만으로는 화면에 안 보임.
 *   - 픽셀은 항상 canonical 0x00RRGGBB(리틀엔디안 자연수32 1픽셀).
 *
 * ── 표면 (GPU 렌더러 마일스톤 1: docs/gpu_renderer.md) ─────────────────────────────
 * 표면은 CAMetalLayer다. CPU 백버퍼는 MTLBuffer(storageModeShared)의 contents를
 * 그대로 쓰고(blit syscall이 곧 GPU staging 버퍼에 기록 — 복사 0회), present마다
 * blit encoder로 drawable 텍스처(MTLPixelFormatBGRA8Unorm = canonical 바이트 배치
 * B,G,R,X와 정확히 일치, 스위즐 불필요)에 복사해 vsync(displaySync) 표시한다.
 * 마일스톤 2+에서 이 위에 명령 버퍼/셰이더 경로가 얹힌다.
 *
 * 창은 리사이즈 가능하고 표면 크기는 "실제 창 크기 × 레티나 배율"의 픽셀 단위다.
 *   - SYS_FRAMEBUFFER_INFO는 v2 56바이트 레코드(오프셋 48 = 배율)를 반환한다.
 *   - 크기/배율이 바뀌면 백버퍼·drawable을 재구성하고 INPUT_EVENT_KIND_SURFACE_RESIZE
 *     (kind=5, 비트 0-23 너비, 24-47 높이, 48-55 배율)를 입력 링에 밀어넣는다.
 *     앱은 그 이벤트를 신호로 SYS_FRAMEBUFFER_INFO를 다시 읽고 전체를 다시 그린다.
 *   - Metal 디바이스가 없는 호스트(이례적)에서는 예전 CGImage drawRect 경로로
 *     폴백한다 — 계약 시맨틱은 동일하고 vsync 보장만 없다.
 *
 * hmje 쪽 그리기 루프는 자체 imperative 루프(60Hz/잔여 sleep)를 돌리므로 [NSApp run]을
 * 절대 부르면 안 된다 — 그 대신 창을 lazily 만들고, present/input poll 때마다 Cocoa
 * run loop를 non-blocking으로 몇 차례 드레인해서 창이 "not responding"으로 안 보이게 하고
 * 이벤트를 흡수한다.
 *
 * 검증용 디버그 이스케이프 해치:
 *   - HMJE_POSIX_DUMP_FRAME=경로: 매 present마다 백버퍼(=drawable에 복사되는 것과 동일한
 *     픽셀)를 그 경로에 PNG로 덮어쓴다. 화면 캡처(TCC 권한)가 없는 세션에서 "창이 실제로
 *     뭘 그렸는지"를 검증한다. 정상 배포 시엔 미설정 → 오버헤드 없음.
 *   - HMJE_POSIX_SELFTEST_RESIZE=너비x높이[@프레임]: 지정한 present 횟수(기본 90) 뒤에
 *     창 콘텐츠 크기를 프로그램적으로 바꾼다 — 사람이 창 모서리를 끌지 않고도
 *     리사이즈 이벤트 → 앱 재배치 → 새 크기 PNG 덤프까지 자동 검증하기 위한 것.
 *     진행 로그는 stderr로만 낸다(stdout은 앱 출력 계약이라 오염 금지).
 */

#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <os/lock.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "pointer_input.h"

typedef long long i64;
typedef unsigned long long u64;

/* 초기 창 크기(포인트). 이후에는 사용자가 자유롭게 리사이즈한다. */
#define DEFAULT_WIDTH 1180
#define DEFAULT_HEIGHT 860
#define MIN_CONTENT_WIDTH 320
#define MIN_CONTENT_HEIGHT 240

#define KEY_RING_CAPACITY 256

/* posix_host_shim.c의 HMJE_POSIX_ENOSYS와 값만 맞추면 되는 로컬 상수(별도 번역 단위). */
#define HMJE_POSIX_ENOSYS_LOCAL (-38LL)

/* library/kernel/api/syscall.hmje 계약과 값이 같아야 하는 로컬 상수(별도 번역 단위).
 * INPUT_EVENT_KIND_SURFACE_RESIZE: 비트 0-23 너비(픽셀), 24-47 높이(픽셀), 48-55 배율. */
#define HMJE_INPUT_KIND_SHIFT 56
#define HMJE_INPUT_KIND_SURFACE_RESIZE 5ULL
#define HMJE_INPUT_KIND_APP_CLOSE 6ULL
#define HMJE_INPUT_SURFACE_SIZE_MASK 16777215ULL
#define HMJE_INPUT_SURFACE_HEIGHT_SHIFT 24
#define HMJE_INPUT_SURFACE_SCALE_SHIFT 48
#define HMJE_INPUT_SURFACE_SCALE_MASK 255ULL

/* 포인터 이벤트. 커널(PS/2·virtio-input) 백엔드와 **같은 인코딩**이라 앱은 자기가
 * 호스트에 사는지 베어메탈에 사는지 모른다. 비트 0-23 x, 24-47 y, 48-54 버튼,
 * 55 눌림(버튼)/아래로(스크롤).
 *
 * 여기까지가 §25.3의 최소 네이티브 경계다 — Cocoa는 **이벤트 소스**일 뿐이고,
 * NSEvent에서 좌표와 버튼만 꺼내 우리 링에 넣는다. 히트테스트·클릭 판정·끌기
 * 임계는 전부 SemtleUI가 한다. 제스처도 같은 선을 긋는다: 원시 접점만 받고
 * 인식은 우리가 한다(핀치가 무엇인지가 플랫폼마다 갈리면 안 된다).
 */
#define HMJE_INPUT_KIND_POINTER_MOVE 1ULL
#define HMJE_INPUT_KIND_POINTER_BUTTON 2ULL
#define HMJE_INPUT_KIND_POINTER_SCROLL 3ULL
#define HMJE_INPUT_POINTER_COORD_MASK 16777215ULL
#define HMJE_INPUT_POINTER_Y_SHIFT 24
#define HMJE_INPUT_POINTER_BUTTON_SHIFT 48
#define HMJE_INPUT_POINTER_PRESSED_FLAG (1ULL << 55)
#define HMJE_INPUT_SCROLL_AMOUNT_MASK 16777215ULL
#define HMJE_INPUT_SCROLL_DOWN_FLAG (1ULL << 55)
/* 정밀 스크롤(트랙패드·매직마우스 표면)은 픽셀로 오므로 한 눈금 분량을 정해
 * 누적한다. 휠 마우스는 이미 눈금 단위라 그대로 쓴다. */
#define HMJE_PRECISE_SCROLL_STEP 10.0

static NSWindow *g_window = nil;
static NSView *g_view = nil;
static id g_application_delegate = nil;
static id g_key_monitor = nil;
static id g_pointer_monitor = nil;
static hmje_pointer_ring g_pointer_samples;

/* 표면 기하 — 전부 픽셀 단위(g_scale이 이미 곱해진 값). */
static u64 g_width = 0;
static u64 g_height = 0;
static u64 g_pitch = 0;
static u64 g_scale = 1;
static BOOL g_ready = NO;
static BOOL g_close_requested = NO;
static BOOL g_close_delivered = NO;
static BOOL g_runtime_polling = NO;

i64 hmje_posix_ui_window_config(i64 title_address, i64 title_length, i64 flags) {
    if (g_window == nil || title_length < 0 || (title_length > 0 && title_address == 0)) return HMJE_POSIX_ENOSYS_LOCAL;
    if (title_length > 0) {
        NSString *title = [[NSString alloc] initWithBytes:(const void *)(uintptr_t)(u64)title_address
                                                   length:(NSUInteger)title_length
                                                 encoding:NSUTF8StringEncoding];
        if (title == nil) return -22;
        [g_window setTitle:title];
    }
    BOOL hidden = (((u64)flags & 1ULL) != 0);
    [g_window setTitleVisibility:hidden ? NSWindowTitleHidden : NSWindowTitleVisible];
    [g_window setTitlebarAppearsTransparent:hidden];
    NSUInteger style = [g_window styleMask];
    if (hidden) style |= NSWindowStyleMaskFullSizeContentView;
    else style &= ~NSWindowStyleMaskFullSizeContentView;
    [g_window setStyleMask:style];
    return 0;
}

/* Metal 경로: 백버퍼는 shared MTLBuffer의 contents 그 자체(g_backbuffer가 가리킨다). */
static id<MTLDevice> g_device = nil;
static id<MTLCommandQueue> g_queue = nil;
static CAMetalLayer *g_layer = nil;
static id<MTLBuffer> g_staging = nil;
/* 실제 앱의 명령 버퍼를 직접 그리는 hosted GPU 경로. 명령 해석은 hmje-ui의
 * gpu_command_renderer.hmje가 맡고, 이 상태는 정규화된 draw/blit 호출만 받는다.
 *
 * 대상(target) 두 개를 독립적으로 유지한다 — semtle_ui.hmje의 캔버스값(화면,
 * target=0, 매 프레임 실제 drawable에 present)과 배경(target=1, 앱이 직접
 * present하지 않는 persistent 콘텐츠 저장소, 캔버스값의 이미지 합성 소스)은
 * 서로 다른 텍스처가 필요하다 — 하나만 있으면 배경을 그 위에 그리는 순간
 * 캔버스값이 이미 present한 이전 프레임 내용을 덮어써 버린다.
 * BEGIN 요청의 세 번째 필드(target)가 어느 슬롯을 쓸지 고르고, 그 뒤 CLIP/
 * DRAW/UPLOAD_GLYPH/IMAGE_BLIT/SCROLL_SHIFT/END_PRESENT는 g_gpu_current_target로
 * 선택된 슬롯만 건드린다(hmje_gpu_active_target 참고). */
static id<MTLTexture> g_gpu_target = nil;       /* target 0: 화면(캔버스값) */
static id<MTLTexture> g_gpu_target_bg = nil;    /* target 1: 배경 */
static int g_gpu_current_target = 0;
/* 세로 스크롤 shift·배경 합성 전용 임시 스크래치 텍스처 — 같은 텍스처 내
 * 겹치는 영역을 안전하게 옮기려고 경유한다(Metal에서 source/destination이
 * 같은 텍스처인 blit은 정의되지 않음). target 0/1 트랜잭션이 동시에 열리지
 * 않으므로(앱 프레임 루프가 배경을 완전히 끝내고서야 캔버스값을 시작한다)
 * 하나로 공유해도 안전하다. 필요한 크기가 커질 때만 다시 만들고 줄어들면 재사용한다. */
static id<MTLTexture> g_gpu_scroll_scratch = nil;
static id<MTLTexture> g_gpu_glyph = nil;
/* 그라데이션(GPU_COMMAND_GRADIENT_FILL) 단일 패스 파이프라인 — 블러처럼 지연
 * 생성해 기존 GPU 경로를 건드리지 않는다(스크래치 텍스처 불필요). */
static id<MTLRenderPipelineState> g_gpu_gradient_pipeline = nil;
static id<MTLRenderPipelineState> g_gpu_shape_pipeline = nil;
static id<MTLRenderPipelineState> g_gpu_glyph_pipeline = nil;
/* 이미지 스케일 블릿(GPU_COMMAND_IMAGE_SCALE_BLIT) 전용 텍스처-샘플 파이프라인.
 * 기존 g_gpu_shape_pipeline/g_gpu_glyph_pipeline과 같은 위치에서 지연 생성한다
 * (hmje_gpu_prepare_pipelines). 이미지 업로드는 명령별 불변 텍스처로 보존한다. */
static id<MTLRenderPipelineState> g_gpu_image_pipeline = nil;
/* 층(그룹 불투명도, HMJE_GPU_LAYER_BEGIN/END) — 이미지 파이프라인과 같은
 * 텍스처 쿼드지만 프래그먼트가 상수 알파를 실어 src-over로 얹는다. */
static id<MTLRenderPipelineState> g_gpu_layer_pipeline = nil;
/* 층 스택. 텍스처는 grow-only로 재사용한다 —
 * 한 프레임에 반투명 뷰가 수십 개여도 배열은 중첩 깊이까지만 자란다. */
#define HMJE_GPU_LAYER_MAX 8
static id<MTLTexture> g_gpu_layer_texture[HMJE_GPU_LAYER_MAX] = {nil};
static id<MTLTexture> g_gpu_layer_saved_target[HMJE_GPU_LAYER_MAX] = {nil};
static MTLScissorRect g_gpu_layer_saved_clip[HMJE_GPU_LAYER_MAX];
static u64 g_gpu_layer_x[HMJE_GPU_LAYER_MAX];
static u64 g_gpu_layer_y[HMJE_GPU_LAYER_MAX];
static u64 g_gpu_layer_w[HMJE_GPU_LAYER_MAX];
static u64 g_gpu_layer_h[HMJE_GPU_LAYER_MAX];
static u64 g_gpu_layer_alpha[HMJE_GPU_LAYER_MAX];
static int g_gpu_layer_depth = 0;
static id<MTLCommandBuffer> g_gpu_command_buffer = nil;
static id<MTLRenderCommandEncoder> g_gpu_render_encoder = nil;
static MTLScissorRect g_gpu_clip = {0, 0, 1, 1};
static BOOL g_gpu_target_needs_clear = YES;
static BOOL g_gpu_target_bg_needs_clear = YES;

/* 현재 트랜잭션(BEGIN..END_PRESENT/ABORT)이 그리는 대상 텍스처. */
static id<MTLTexture> hmje_gpu_active_target(void) {
    if (g_gpu_layer_depth > 0) return g_gpu_layer_texture[g_gpu_layer_depth - 1];
    return g_gpu_current_target == 1 ? g_gpu_target_bg : g_gpu_target;
}
static BOOL *hmje_gpu_active_needs_clear_flag(void) {
    return g_gpu_current_target == 1 ? &g_gpu_target_bg_needs_clear : &g_gpu_target_needs_clear;
}
/* canonical 0x00RRGGBB, LE u32 per pixel. Metal 경로면 g_staging.contents,
 * 폴백(CGImage) 경로면 calloc 블록. */
static unsigned char *g_backbuffer = NULL;

static u64 g_key_ring[KEY_RING_CAPACITY];
static int g_key_ring_head = 0; /* next slot to write */
static int g_key_ring_tail = 0; /* next slot to read */

static void key_ring_push(u64 event) {
    int next = (g_key_ring_head + 1) % KEY_RING_CAPACITY;
    if (next == g_key_ring_tail) {
        return; /* full — drop oldest-arriving event rather than overwrite unread ones */
    }
    g_key_ring[g_key_ring_head] = event;
    g_key_ring_head = next;
}

/* posix_host_text_input.m(키보드/IME 처리 유닛)가 쓰는 입력 링 push. */
void hmje_posix_input_push_event(u64 event) {
    key_ring_push(event);
}

/* posix_host_text_input.m가 구현한다 — 창 유닛은 이벤트를 넘기기만 한다. */
extern void hmje_posix_text_input_attach(NSWindow *window);
extern NSEvent *hmje_posix_text_input_handle_event(NSEvent *event);
extern void hmje_posix_text_input_selftest_tick(void);

/* ---- 포인터 ------------------------------------------------------------- */
/* **HmjeContentView는 isFlipped = YES다.** 그래서 convertPoint:fromView:nil이
 * 이미 왼쪽 **위**가 원점인 포인트를 준다 — 여기서 또 뒤집으면 안 된다.
 * (처음에 AppKit 기본값인 좌하단 원점을 가정하고 한 번 더 뒤집었다가 위를 누르면
 * 아래가 눌리는 버그를 만들었다. 셀프테스트는 같은 뒤집기를 역으로 해서 통과했다 —
 * 합성 입력이 자기 변환의 역함수를 쓰면 좌표계 오류를 못 잡는다.)
 *
 * 남은 일은 배율을 곱해 표면 픽셀로 만드는 것뿐이다. 창 밖(음수·초과)은
 * 가장자리로 물린다: 끌기 중에 포인터가 창을 벗어나도 좌표가 튀지 않아야 한다. */
static BOOL pointer_pixel_location(NSEvent *event, u64 *out_x, u64 *out_y) {
    if (g_view == nil || g_width == 0 || g_height == 0) {
        return NO;
    }
    NSPoint in_view = [g_view convertPoint:[event locationInWindow] fromView:nil];
    CGFloat scale_f = (CGFloat)g_scale;
    CGFloat px = in_view.x * scale_f;
    CGFloat py = in_view.y * scale_f;
    if (px < 0) {
        px = 0;
    }
    if (py < 0) {
        py = 0;
    }
    u64 x = (u64)llround(px);
    u64 y = (u64)llround(py);
    if (x >= g_width) {
        x = g_width - 1;
    }
    if (y >= g_height) {
        y = g_height - 1;
    }
    *out_x = x;
    *out_y = y;
    return YES;
}

static u64 pointer_event_base(u64 kind, u64 x, u64 y) {
    return (kind << HMJE_INPUT_KIND_SHIFT)
         | (x & HMJE_INPUT_POINTER_COORD_MASK)
         | ((y & HMJE_INPUT_POINTER_COORD_MASK) << HMJE_INPUT_POINTER_Y_SHIFT);
}

static u64 pointer_time_us(NSEvent *event) {
    return (u64)(event.timestamp * 1000000.0);
}

static u64 pointer_buttons(NSEvent *event) {
    (void)event;
    return (u64)[NSEvent pressedMouseButtons];
}

/* NSEventSubtypeTabletPoint의 값(1)은 ScrollWheel의 continuous subtype 값과
 * 겹친다. 따라서 subtype만 보고 태블릿 접근자(pointingDeviceID/pressure/tilt)를
 * 호출하면 트랙패드 스크롤에서 AppKit이 NSInternalInconsistencyException을 던진다.
 * 태블릿 payload를 가질 수 있는 이벤트 종류를 먼저 제한한 뒤 subtype을 읽는다. */
static BOOL pointer_event_type_supports_tablet(NSEventType type) {
    switch (type) {
        case NSEventTypeMouseMoved:
        case NSEventTypeLeftMouseDown:
        case NSEventTypeLeftMouseUp:
        case NSEventTypeRightMouseDown:
        case NSEventTypeRightMouseUp:
        case NSEventTypeOtherMouseDown:
        case NSEventTypeOtherMouseUp:
        case NSEventTypeLeftMouseDragged:
        case NSEventTypeRightMouseDragged:
        case NSEventTypeOtherMouseDragged:
        case NSEventTypeTabletPoint:
            return YES;
        default:
            return NO;
    }
}

static BOOL pointer_event_is_tablet(NSEvent *event) {
    return pointer_event_type_supports_tablet([event type])
        && [event subtype] == NSEventSubtypeTabletPoint;
}

static void pointer_push_sample(
    NSEvent *event, u64 phase, u64 changed_button, i64 scroll_x, i64 scroll_y
) {
    u64 x = 0, y = 0;
    if (!pointer_pixel_location(event, &x, &y)) {
        return;
    }
    hmje_pointer_record record;
    memset(&record, 0, sizeof(record));
    record.phase = phase;
    record.pointer_id = 1u;
    record.x = (i64)x;
    record.y = (i64)y;
    record.time_us = pointer_time_us(event);
    record.buttons = pointer_buttons(event);
    record.changed_button = changed_button;
    record.scroll_x = scroll_x;
    record.scroll_y = scroll_y;
    record.tool = HMJE_POINTER_TOOL_MOUSE;
    record.flags = HMJE_POINTER_CAP_BUTTONS;

    if (pointer_event_is_tablet(event)) {
        record.pointer_id = (u64)event.pointingDeviceID;
        record.tool = event.pointingDeviceType == NSPointingDeviceTypeEraser
            ? HMJE_POINTER_TOOL_ERASER : HMJE_POINTER_TOOL_PEN;
        double pressure = event.pressure;
        if (pressure < 0.0) pressure = 0.0;
        if (pressure > 1.0) pressure = 1.0;
        record.pressure = (u64)llround(pressure * 65535.0);
        record.flags |= HMJE_POINTER_CAP_PRESSURE;

        NSPoint tilt = event.tilt;
        double magnitude = hypot(tilt.x, tilt.y);
        if (magnitude > 1.0) magnitude = 1.0;
        record.altitude = (u64)llround((1.0 - magnitude) * 65535.0);
        double azimuth = atan2(tilt.y, tilt.x);
        if (azimuth < 0.0) azimuth += 2.0 * M_PI;
        record.azimuth = (u64)llround((azimuth / (2.0 * M_PI)) * 65535.0);
        record.flags |= HMJE_POINTER_CAP_ALTITUDE | HMJE_POINTER_CAP_AZIMUTH;
    }
    if (phase == HMJE_POINTER_PHASE_SCROLL) {
        record.flags |= HMJE_POINTER_CAP_SCROLL;
    }
    hmje_pointer_ring_push(&g_pointer_samples, record);
}

static void pointer_push_move(NSEvent *event) {
    u64 x = 0, y = 0;
    if (!pointer_pixel_location(event, &x, &y)) {
        return;
    }
    key_ring_push(pointer_event_base(HMJE_INPUT_KIND_POINTER_MOVE, x, y));
    u64 phase = event.type == NSEventTypeMouseMoved
        ? HMJE_POINTER_PHASE_HOVER : HMJE_POINTER_PHASE_MOVE;
    pointer_push_sample(event, phase, 0u, 0, 0);
}

/* 버튼 번호는 커널과 같다: 0 왼쪽, 1 오른쪽, 2 가운데. NSEvent.buttonNumber가
 * 마침 같은 순서라 변환이 없다. 그 위 버튼(4번째 이상)은 아직 계약에 없어 버린다. */
static void pointer_push_button(NSEvent *event, BOOL down) {
    u64 x = 0, y = 0;
    if (!pointer_pixel_location(event, &x, &y)) {
        return;
    }
    NSInteger button = [event buttonNumber];
    if (button < 0 || button > 2) {
        return;
    }
    /* 버튼 이벤트는 좌표도 실어 나르지만, 누른 자리로 포인터가 먼저 가 있어야
     * 히트테스트가 맞는다 — 이동을 한 번 앞세운다(커널 PS/2 경로도 패킷마다
     * 이동을 먼저 넣는다). */
    key_ring_push(pointer_event_base(HMJE_INPUT_KIND_POINTER_MOVE, x, y));
    u64 packed = pointer_event_base(HMJE_INPUT_KIND_POINTER_BUTTON, x, y)
               | (((u64)button) << HMJE_INPUT_POINTER_BUTTON_SHIFT);
    if (down) {
        packed |= HMJE_INPUT_POINTER_PRESSED_FLAG;
    }
    key_ring_push(packed);
    pointer_push_sample(
        event,
        down ? HMJE_POINTER_PHASE_DOWN : HMJE_POINTER_PHASE_UP,
        (u64)button,
        0,
        0
    );
}

static void pointer_push_scroll(NSEvent *event) {
    u64 x = 0, y = 0;
    if (!pointer_pixel_location(event, &x, &y)) {
        return;
    }
    /* Modern trackpads already provide pixel deltas (including AppKit's
     * momentum stream).  Publish every one through POLL2 instead of waiting
     * until an arbitrary notch threshold is crossed.  The legacy packed
     * wheel event remains only for discrete mouse wheels / old guests. */
    if ([event hasPreciseScrollingDeltas]) {
        static double precise_residual_x = 0.0;
        static double precise_residual_y = 0.0;
        precise_residual_x += [event scrollingDeltaX];
        precise_residual_y += [event scrollingDeltaY];
        i64 pixel_x = precise_residual_x >= 0.0
            ? (i64)floor(precise_residual_x) : (i64)ceil(precise_residual_x);
        i64 pixel_y = precise_residual_y >= 0.0
            ? (i64)floor(precise_residual_y) : (i64)ceil(precise_residual_y);
        precise_residual_x -= (double)pixel_x;
        precise_residual_y -= (double)pixel_y;
        if (pixel_x == 0 && pixel_y == 0) return;
        pointer_push_sample(
            event,
            HMJE_POINTER_PHASE_SCROLL,
            0u,
            pixel_x,
            pixel_y
        );
        return;
    }
    long long notches = 0;
    notches = (long long)llround([event scrollingDeltaY]);
    if (notches == 0) {
        return;
    }
    /* AppKit의 양수 deltaY는 "콘텐츠가 아래로" = 위로 스크롤이다. 계약의
     * DOWN 플래그는 그 반대쪽이므로 부호를 그대로 읽어 나눈다. */
    BOOL down = (notches < 0);
    u64 amount = (u64)(down ? -notches : notches);
    if (amount > HMJE_INPUT_SCROLL_AMOUNT_MASK) {
        amount = HMJE_INPUT_SCROLL_AMOUNT_MASK;
    }
    key_ring_push(pointer_event_base(HMJE_INPUT_KIND_POINTER_MOVE, x, y));
    u64 packed = (HMJE_INPUT_KIND_POINTER_SCROLL << HMJE_INPUT_KIND_SHIFT)
               | (amount & HMJE_INPUT_SCROLL_AMOUNT_MASK);
    if (down) {
        packed |= HMJE_INPUT_SCROLL_DOWN_FLAG;
    }
    key_ring_push(packed);
}

/* 모니터 하나로 전부 받는다. 이벤트를 **소비하지 않고 그대로 돌려준다** —
 * 창 이동·리사이즈 같은 AppKit 자체 동작을 막으면 안 된다. */
static NSEvent *pointer_handle_event(NSEvent *event) {
    switch ([event type]) {
        case NSEventTypeMouseMoved:
        case NSEventTypeLeftMouseDragged:
        case NSEventTypeRightMouseDragged:
        case NSEventTypeOtherMouseDragged:
            pointer_push_move(event);
            break;
        case NSEventTypeLeftMouseDown:
        case NSEventTypeRightMouseDown:
        case NSEventTypeOtherMouseDown:
            pointer_push_button(event, YES);
            break;
        case NSEventTypeLeftMouseUp:
        case NSEventTypeRightMouseUp:
        case NSEventTypeOtherMouseUp:
            pointer_push_button(event, NO);
            break;
        case NSEventTypeScrollWheel:
            pointer_push_scroll(event);
            break;
        default:
            break;
    }
    return event;
}

static i64 key_ring_pop(void) {
    if (g_key_ring_tail == g_key_ring_head) {
        return 0;
    }
    u64 value = g_key_ring[g_key_ring_tail];
    g_key_ring_tail = (g_key_ring_tail + 1) % KEY_RING_CAPACITY;
    return (i64)value;
}

static BOOL surface_debug_enabled(void) {
    return getenv("HMJE_POSIX_DEBUG_SURFACE") != NULL || getenv("HMJE_POSIX_SELFTEST_RESIZE") != NULL;
}

static void surface_debug_log(const char *tag) {
    if (!surface_debug_enabled()) {
        return;
    }
    fprintf(stderr, "posix-host-surface: %s %llux%llu scale=%llu\n", tag, g_width, g_height, g_scale);
}

/* ---- 표면(백버퍼 + drawable) 기하 갱신 ------------------------------------ */

/* 새 픽셀 크기로 백버퍼를 재할당한다. 이전 내용의 좌상단 교집합은 복사해
 * 리사이즈 순간의 깜빡임(검은 프레임)을 줄인다 — 앱이 곧 SURFACE_RESIZE 이벤트를
 * 받고 전체를 다시 그린다. */
static BOOL reallocate_backbuffer(u64 new_width, u64 new_height) {
    u64 new_pitch = new_width * 4;
    unsigned char *old_pixels = g_backbuffer;
    u64 old_width = g_width, old_height = g_height, old_pitch = g_pitch;
    /* 주의: 이전 백버퍼의 유일한 강한 참조가 g_staging이다. 보존 복사가 끝나기 전에
     * g_staging을 덮어쓰면 ARC가 이전 버퍼를 즉시 해제해 old_pixels가 dangling이 된다
     * (실제로 setContentSize 경로에서 memmove SIGSEGV로 재현). 복사가 끝날 때까지
     * 지역 참조로 살려둔다. 마지막 present는 waitUntilCompleted라 GPU 사용도 끝난 상태. */
    id<MTLBuffer> old_buffer = g_staging;
    id<MTLBuffer> new_buffer = nil;
    unsigned char *new_pixels = NULL;

    if (g_device != nil) {
        new_buffer = [g_device newBufferWithLength:(NSUInteger)(new_pitch * new_height)
                                           options:MTLResourceStorageModeShared];
        if (new_buffer == nil) {
            return NO;
        }
        new_pixels = (unsigned char *)[new_buffer contents];
        memset(new_pixels, 0, (size_t)(new_pitch * new_height));
    } else {
        new_pixels = calloc(1, (size_t)(new_pitch * new_height));
        if (new_pixels == NULL) {
            return NO;
        }
    }

    if (old_pixels != NULL) {
        u64 copy_w = old_width < new_width ? old_width : new_width;
        u64 copy_h = old_height < new_height ? old_height : new_height;
        for (u64 row = 0; row < copy_h; row++) {
            memcpy(new_pixels + row * new_pitch, old_pixels + row * old_pitch, (size_t)(copy_w * 4));
        }
        if (g_device == nil) {
            free(old_pixels);
        }
    }

    g_staging = new_buffer; /* 이제야 이전 버퍼 참조를 놓는다(old_buffer가 함수 끝까지 유지). */
    g_backbuffer = new_pixels;
    g_width = new_width;
    g_height = new_height;
    g_pitch = new_pitch;
    (void)old_buffer;
    return YES;
}

/* 뷰의 현재 포인트 크기 × 배율 → 픽셀 표면. 변화가 있을 때만 재구성하고
 * SURFACE_RESIZE 이벤트를 큐잉한다(초기 생성 시에는 push_event=NO). */
static void update_surface_geometry(BOOL push_event) {
    if (g_view == nil || g_window == nil) {
        return;
    }
    CGFloat scale_f = [g_window backingScaleFactor];
    if (scale_f < 1.0) {
        scale_f = 1.0;
    }
    /* HmjeContentView는 이 지점에서 아직 forward 선언뿐이라 NSView로 캐스팅해 보낸다. */
    NSSize bounds = [(NSView *)g_view bounds].size;
    u64 new_scale = (u64)llround(scale_f);
    if (new_scale < 1) {
        new_scale = 1;
    }
    u64 new_width = (u64)llround(bounds.width * scale_f);
    u64 new_height = (u64)llround(bounds.height * scale_f);
    if (new_width < 1) {
        new_width = 1;
    }
    if (new_height < 1) {
        new_height = 1;
    }
    if (surface_debug_enabled()) {
        fprintf(stderr, "posix-host-surface: probe %llux%llu -> %llux%llu scale=%llu\n",
                g_width, g_height, new_width, new_height, new_scale);
    }
    if (new_width == g_width && new_height == g_height && new_scale == g_scale) {
        return;
    }
    if (!reallocate_backbuffer(new_width, new_height)) {
        return; /* 할당 실패 — 이전 표면 유지 */
    }
    g_scale = new_scale;
    if (g_layer != nil) {
        g_layer.contentsScale = scale_f;
        g_layer.drawableSize = CGSizeMake((CGFloat)new_width, (CGFloat)new_height);
    }
    /* RESIZE 이벤트를 링에 직접 밀지 않는다. 전체화면 전환 같은 리사이즈
     * 폭풍에서는 링(256칸)이 이동 이벤트로 차 있을 수 있고, key_ring_push는
     * 가득 차면 **조용히 버린다** — 그 한 번이 유일한 통지라 앱은 옛 기하로
     * 영원히 그린다(안 그려진 드로어블 = 검은 띠, 어긋난 blit = 유령 프레임).
     * 대신 아래 poll이 "앱이 아는 기하 ≠ 실제 기하"를 매 프레임 검사해
     * 확인될 때까지 이벤트를 다시 만든다 — 유실이 구조적으로 불가능하다. */
    if (push_event) {
        surface_debug_log("resize");
    }
}

/* 앱이 마지막으로 통지받은(=poll이 돌려준) 표면 기하. 실제(g_*)와 다르면
 * poll이 RESIZE 이벤트를 합성한다. */
static u64 g_acked_width = 0;
static u64 g_acked_height = 0;
static u64 g_acked_scale = 0;

static i64 surface_resize_event_if_needed(void) {
    if (!g_ready || g_width == 0 || g_height == 0) {
        return 0;
    }
    if (g_width == g_acked_width && g_height == g_acked_height && g_scale == g_acked_scale) {
        return 0;
    }
    g_acked_width = g_width;
    g_acked_height = g_height;
    g_acked_scale = g_scale;
    u64 event = (HMJE_INPUT_KIND_SURFACE_RESIZE << HMJE_INPUT_KIND_SHIFT)
        | ((g_scale & HMJE_INPUT_SURFACE_SCALE_MASK) << HMJE_INPUT_SURFACE_SCALE_SHIFT)
        | ((g_height & HMJE_INPUT_SURFACE_SIZE_MASK) << HMJE_INPUT_SURFACE_HEIGHT_SHIFT)
        | (g_width & HMJE_INPUT_SURFACE_SIZE_MASK);
    return (i64)event;
}

/* ---- 커스텀 콘텐츠 뷰 ------------------------------------------------------ */
/* Metal 경로: 뷰는 CAMetalLayer를 backing layer로 쓰고 drawRect는 호출되지 않는다
 * (present가 직접 drawable에 blit). 폴백 경로: 예전과 같은 CGImage drawRect. */

@interface HmjeContentView : NSView
@end

@implementation HmjeContentView

- (BOOL)isFlipped {
    return YES; /* canonical 좌표계(원점 좌상단)와 맞춘다 */
}

- (BOOL)acceptsFirstResponder {
    return YES;
}

/* 창이 비활성일 때의 첫 클릭도 앱에 전달한다. 기본값(NO)이면 그 클릭은
 * 창을 앞으로 가져오는 데만 쓰이고 삼켜진다 — 다른 창을 보다 돌아와서
 * 카드를 누르면 한 번은 반응이 없는 것처럼 느껴진다. */
- (BOOL)acceptsFirstMouse:(NSEvent *)event {
    (void)event;
    return YES;
}

- (CALayer *)makeBackingLayer {
    if (g_device != nil) {
        CAMetalLayer *layer = [CAMetalLayer layer];
        layer.device = g_device;
        layer.pixelFormat = MTLPixelFormatBGRA8Unorm; /* 바이트 B,G,R,A = canonical 0x00RRGGBB */
        layer.framebufferOnly = NO; /* blit encoder 대상이 되려면 필요 */
        layer.opaque = YES;         /* canonical 상위 바이트(알파)=0 무시 */
        g_layer = layer;
        return layer;
    }
    return [super makeBackingLayer];
}

- (void)setFrameSize:(NSSize)newSize {
    [super setFrameSize:newSize];
    if (g_ready) {
        surface_debug_log("view-frame");
        update_surface_geometry(YES);
    }
}

- (void)viewDidChangeBackingProperties {
    [super viewDidChangeBackingProperties];
    if (g_ready) {
        update_surface_geometry(YES); /* 디스플레이 이동으로 레티나 배율이 바뀐 경우 */
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    /* Metal 경로에서는 호출되지 않는다(백킹 레이어가 CAMetalLayer). 폴백 전용. */
    if (g_backbuffer == NULL || g_width == 0 || g_height == 0) {
        [[NSColor blackColor] setFill];
        NSRectFill([self bounds]);
        return;
    }
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, g_backbuffer, (size_t)(g_pitch * g_height), NULL);
    /* AlphaNoneSkipFirst + Little => in-memory byte order B,G,R,X, 즉 LE u32로 읽으면
     * 0x00RRGGBB — runtime/user/graphics.hmje가 정의한 canonical 포맷과 정확히 일치. */
    CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst;
    CGImageRef image = CGImageCreate((size_t)g_width, (size_t)g_height, 8, 32, (size_t)g_pitch,
                                      colorSpace, bitmapInfo, provider, NULL, false, kCGRenderingIntentDefault);
    CGContextRef ctx = [[NSGraphicsContext currentContext] CGContext];
    CGContextSaveGState(ctx);
    CGContextTranslateCTM(ctx, 0, (CGFloat)[self bounds].size.height);
    CGContextScaleCTM(ctx, 1.0, -1.0);
    CGContextDrawImage(ctx, CGRectMake(0, 0, [self bounds].size.width, [self bounds].size.height), image);
    CGContextRestoreGState(ctx);
    CGImageRelease(image);
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpace);
}

@end

/* ---- macOS 접근성 ------------------------------------------------------- */
/* iOS 백엔드와 같은 syscall 109 wire ABI를 AppKit의 표준
 * NSAccessibilityElement로 바꾼다. 실제 포커스·편집·렌더링은 계속
 * HMJE가 소유하고, 여기서는 VoiceOver/Accessibility Inspector에 의미·위치·
 * 표준 액션만 노출한다. */
#define HMJE_AX_NODE_WORDS 18
#define HMJE_AX_MAX_NODES 8192
#define HMJE_AX_MAX_TEXT_BYTES (1024 * 1024)

typedef struct { u64 identifier, action; } HmjeAXAction;
@class HmjeAccessibilityElement;
static HmjeAXAction g_ax_actions[64];
static unsigned g_ax_read = 0;
static unsigned g_ax_write = 0;
static os_unfair_lock g_ax_lock = OS_UNFAIR_LOCK_INIT;
static NSMutableDictionary<NSNumber *, HmjeAccessibilityElement *> *g_ax_elements = nil;
static NSSet<NSNumber *> *g_ax_current = nil;

static BOOL hmje_ax_enqueue(u64 identifier, u64 action) {
    os_unfair_lock_lock(&g_ax_lock);
    if (![g_ax_current containsObject:@(identifier)]) {
        os_unfair_lock_unlock(&g_ax_lock);
        return NO;
    }
    unsigned next = (g_ax_write + 1) % 64;
    if (next == g_ax_read) {
        os_unfair_lock_unlock(&g_ax_lock);
        return NO;
    }
    g_ax_actions[g_ax_write] = (HmjeAXAction){identifier, action};
    g_ax_write = next;
    os_unfair_lock_unlock(&g_ax_lock);
    return YES;
}

@interface HmjeAccessibilityElement : NSAccessibilityElement
@property(nonatomic, assign) u64 semanticIdentifier;
@property(nonatomic, assign) u64 semanticActions;
@end

@implementation HmjeAccessibilityElement
- (BOOL)accessibilityPerformPress {
    if (self.semanticActions & 1) return hmje_ax_enqueue(self.semanticIdentifier, 1);
    if (self.semanticActions & 2) return hmje_ax_enqueue(self.semanticIdentifier, 2);
    return NO;
}
- (BOOL)accessibilityPerformIncrement {
    return (self.semanticActions & 4) && hmje_ax_enqueue(self.semanticIdentifier, 4);
}
- (BOOL)accessibilityPerformDecrement {
    return (self.semanticActions & 8) && hmje_ax_enqueue(self.semanticIdentifier, 8);
}
- (BOOL)isAccessibilitySelectorAllowed:(SEL)selector {
    if (selector == @selector(accessibilityPerformPress))
        return (self.semanticActions & 3) != 0;
    if (selector == @selector(accessibilityPerformIncrement))
        return (self.semanticActions & 4) != 0;
    if (selector == @selector(accessibilityPerformDecrement))
        return (self.semanticActions & 8) != 0;
    return [super isAccessibilitySelectorAllowed:selector];
}
@end

static NSString *hmje_ax_text(u64 address, u64 length) {
    if (length == 0) return @"";
    if (address == 0 || length > HMJE_AX_MAX_TEXT_BYTES) return nil;
    return [[NSString alloc] initWithBytes:(const void *)(uintptr_t)address
                                   length:(NSUInteger)length
                                 encoding:NSUTF8StringEncoding];
}

static NSAccessibilityRole hmje_ax_role(u64 role) {
    if (role == 1) return NSAccessibilityStaticTextRole;
    if (role == 2 || role == 4 || role == 5) return NSAccessibilityButtonRole;
    if (role == 3) return NSAccessibilityTextFieldRole;
    if (role == 6) return NSAccessibilitySliderRole;
    return NSAccessibilityGroupRole;
}

i64 hmje_posix_ui_accessibility(i64 operation, i64 address, i64 length) {
    if (operation == 0) return 1;
    if (operation == 2) {
        if (!address || length < (i64)sizeof(HmjeAXAction)) return -22;
        os_unfair_lock_lock(&g_ax_lock);
        if (g_ax_read == g_ax_write) {
            os_unfair_lock_unlock(&g_ax_lock);
            return 0;
        }
        HmjeAXAction action = g_ax_actions[g_ax_read];
        g_ax_read = (g_ax_read + 1) % 64;
        os_unfair_lock_unlock(&g_ax_lock);
        memcpy((void *)(uintptr_t)(u64)address, &action, sizeof(action));
        return (i64)sizeof(action);
    }
    if (operation != 1) return HMJE_POSIX_ENOSYS_LOCAL;

    const size_t stride = HMJE_AX_NODE_WORDS * sizeof(u64);
    if (length < 0 || (u64)length % stride != 0 || (u64)length / stride > HMJE_AX_MAX_NODES)
        return -22;
    if (length != 0 && address == 0) return -22;

    size_t count = (size_t)length / stride;
    const u64 *records = (const u64 *)(uintptr_t)(u64)address;
    @autoreleasepool {
        NSMutableArray<NSDictionary *> *snapshot = [NSMutableArray arrayWithCapacity:count];
        NSMutableSet<NSNumber *> *keys = [NSMutableSet setWithCapacity:count];
        for (size_t i = 0; i < count; ++i) {
            const u64 *r = records + i * HMJE_AX_NODE_WORDS;
            if (r[0] == 0 || r[2] < 1 || r[2] > 7 || r[8] > 1000000 || r[9] > 1000000
                || (i64)r[6] < -1000000 || (i64)r[7] < -1000000
                || (i64)r[6] > 1000000 || (i64)r[7] > 1000000
                || [keys containsObject:@(r[0])]) return -22;
            NSString *label = hmje_ax_text(r[10], r[11]);
            NSString *value = (r[3] & 32) ? @"" : hmje_ax_text(r[12], r[13]);
            if (label == nil || value == nil) return -22;
            [keys addObject:@(r[0])];
            [snapshot addObject:@{@"id": @(r[0]), @"role": @(r[2]), @"state": @(r[3]),
                @"actions": @(r[4]), @"label": label, @"value": value,
                @"frame": [NSValue valueWithRect:NSMakeRect((i64)r[6], (i64)r[7], r[8], r[9])]}];
        }

        void (^applySnapshot)(void) = ^{
            if (g_view == nil) return;
            if (g_ax_elements == nil) g_ax_elements = [NSMutableDictionary dictionary];
            BOOL topologyChanged = ![g_ax_current isEqualToSet:keys];
            NSMutableDictionary<NSNumber *, HmjeAccessibilityElement *> *next =
                [NSMutableDictionary dictionaryWithCapacity:count];
            NSMutableArray *ordered = [NSMutableArray arrayWithCapacity:count];
            CGFloat scale = g_scale == 0 ? 1.0 : (CGFloat)g_scale;

            for (NSDictionary *record in snapshot) {
                NSNumber *key = record[@"id"];
                u64 role = [record[@"role"] unsignedLongLongValue];
                u64 state = [record[@"state"] unsignedLongLongValue];
                u64 actions = (state & 1) ? 0 : [record[@"actions"] unsignedLongLongValue];
                NSRect pixelFrame = [record[@"frame"] rectValue];
                NSRect pointFrame = NSMakeRect(pixelFrame.origin.x / scale, pixelFrame.origin.y / scale,
                                                pixelFrame.size.width / scale, pixelFrame.size.height / scale);
                HmjeAccessibilityElement *element = g_ax_elements[key];
                if (element == nil) element = [[HmjeAccessibilityElement alloc] init];
                element.semanticIdentifier = key.unsignedLongLongValue;
                element.semanticActions = actions;
                element.accessibilityElement = YES;
                element.accessibilityParent = g_view;
                element.accessibilityRole = hmje_ax_role(role);
                element.accessibilityLabel = record[@"label"];
                element.accessibilityValue = record[@"value"];
                element.accessibilityIdentifier = [NSString stringWithFormat:@"hmje.%llu", element.semanticIdentifier];
                element.accessibilityFrameInParentSpace = pointFrame;
                element.accessibilityEnabled = (state & 1) == 0;
                element.accessibilitySelected = (state & 2) != 0;
                element.accessibilityFocused = (state & 16) != 0;
                if (role == 3)
                    element.accessibilityHelp = (state & 4) ? @"여러 줄 텍스트 편집" : @"텍스트 편집";
                next[key] = element;
                [ordered addObject:element];
            }

            g_ax_elements = next;
            os_unfair_lock_lock(&g_ax_lock);
            g_ax_current = [keys copy];
            os_unfair_lock_unlock(&g_ax_lock);
            g_view.accessibilityElement = NO;
            g_view.accessibilityChildren = ordered;
            g_view.accessibilityChildrenInNavigationOrder = ordered;
            if (topologyChanged)
                NSAccessibilityPostNotification(g_view, NSAccessibilityLayoutChangedNotification);
        };
        if ([NSThread isMainThread]) applySnapshot();
        else dispatch_sync(dispatch_get_main_queue(), applySnapshot);
        return (i64)count;
    }
}

/* ---- 표준 macOS 앱 생명주기 --------------------------------------------- */

@interface HmjeApplicationDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

@implementation HmjeApplicationDelegate

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender {
    (void)sender;
    /* Native embedding tools that never enter HMJE's input loop retain normal
     * AppKit termination. A running HMJE app receives one close event so its
     * language-level loop can unwind and release resources first. */
    if (!g_runtime_polling) return NSTerminateNow;
    /* Let HMJE unwind its app loop and release graphics/task resources before
     * process exit.  A second request after delivery is still cancelled: the
     * runtime exits itself once cleanup completes. */
    g_close_requested = YES;
    return NSTerminateCancel;
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    (void)sender;
    return YES;
}

- (void)windowWillClose:(NSNotification *)notification {
    if (notification.object == g_window) {
        /* NSApplication의 run을 쓰지 않는 HMJE 이벤트 펌프에서는
         * applicationShouldTerminateAfterLastWindowClosed:만으로 종료 요청이
         * 전달되지 않으므로 표준 terminate: 경로를 명시적으로 시작한다. */
        [NSApp terminate:nil];
    }
}

- (BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)hasVisibleWindows {
    (void)sender;
    if (!hasVisibleWindows && g_window != nil) {
        [g_window makeKeyAndOrderFront:nil];
    }
    return YES;
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    (void)notification;
    if (g_window != nil && ![g_window isVisible]) {
        [g_window makeKeyAndOrderFront:nil];
    }
}

@end

static void install_standard_application_menu(NSString *applicationName) {
    NSMenu *mainMenu = [[NSMenu alloc] initWithTitle:@""];
    NSMenuItem *applicationMenuItem = [[NSMenuItem alloc] initWithTitle:@""
                                                                 action:nil
                                                          keyEquivalent:@""];
    [mainMenu addItem:applicationMenuItem];

    NSMenu *applicationMenu = [[NSMenu alloc] initWithTitle:applicationName];
    NSString *hideTitle = [NSString stringWithFormat:@"%@ 숨기기", applicationName];
    NSMenuItem *hideItem = [[NSMenuItem alloc] initWithTitle:hideTitle
                                                    action:@selector(hide:)
                                             keyEquivalent:@"h"];
    [hideItem setKeyEquivalentModifierMask:NSEventModifierFlagCommand];
    [applicationMenu addItem:hideItem];
    [applicationMenu addItem:[NSMenuItem separatorItem]];
    NSString *quitTitle = [NSString stringWithFormat:@"%@ 종료", applicationName];
    NSMenuItem *quitItem = [[NSMenuItem alloc] initWithTitle:quitTitle
                                                     action:@selector(terminate:)
                                              keyEquivalent:@"q"];
    [quitItem setKeyEquivalentModifierMask:NSEventModifierFlagCommand];
    [applicationMenu addItem:quitItem];
    [applicationMenuItem setSubmenu:applicationMenu];

    NSMenuItem *editMenuItem = [[NSMenuItem alloc] initWithTitle:@"편집" action:nil keyEquivalent:@""];
    NSMenu *editMenu = [[NSMenu alloc] initWithTitle:@"편집"];
    NSArray<NSMenuItem *> *editItems = @[
        [[NSMenuItem alloc] initWithTitle:@"실행 취소" action:@selector(undo:) keyEquivalent:@"z"],
        [[NSMenuItem alloc] initWithTitle:@"다시 실행" action:@selector(redo:) keyEquivalent:@"Z"],
        [[NSMenuItem alloc] initWithTitle:@"잘라내기" action:@selector(cut:) keyEquivalent:@"x"],
        [[NSMenuItem alloc] initWithTitle:@"복사" action:@selector(copy:) keyEquivalent:@"c"],
        [[NSMenuItem alloc] initWithTitle:@"붙여넣기" action:@selector(paste:) keyEquivalent:@"v"],
        [[NSMenuItem alloc] initWithTitle:@"전체 선택" action:@selector(selectAll:) keyEquivalent:@"a"]
    ];
    for (NSMenuItem *item in editItems) [editMenu addItem:item];
    [editMenuItem setSubmenu:editMenu];
    [mainMenu addItem:editMenuItem];

    NSMenuItem *windowMenuItem = [[NSMenuItem alloc] initWithTitle:@"창" action:nil keyEquivalent:@""];
    NSMenu *windowMenu = [[NSMenu alloc] initWithTitle:@"창"];
    NSMenuItem *minimizeItem = [[NSMenuItem alloc] initWithTitle:@"최소화"
                                                         action:@selector(performMiniaturize:)
                                                  keyEquivalent:@"m"];
    NSMenuItem *closeItem = [[NSMenuItem alloc] initWithTitle:@"창 닫기"
                                                      action:@selector(performClose:)
                                               keyEquivalent:@"w"];
    [windowMenu addItem:minimizeItem];
    [windowMenu addItem:closeItem];
    [windowMenuItem setSubmenu:windowMenu];
    [mainMenu addItem:windowMenuItem];
    [NSApp setWindowsMenu:windowMenu];
    [NSApp setMainMenu:mainMenu];
}

i64 hmje_posix_ui_clipboard(i64 operation, i64 address, i64 length) {
    @autoreleasepool {
        NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
        if (operation == 0) {
            NSString *text = [pasteboard stringForType:NSPasteboardTypeString] ?: @"";
            NSData *utf8 = [text dataUsingEncoding:NSUTF8StringEncoding];
            NSUInteger count = utf8.length;
            if (address != 0 && length >= 0 && (u64)length >= (u64)count && count > 0)
                memcpy((void *)(uintptr_t)(u64)address, utf8.bytes, count);
            return (i64)count;
        }
        if (operation == 1) {
            if (length < 0 || (address == 0 && length != 0)) return -22;
            NSString *text = [[NSString alloc] initWithBytes:(const void *)(uintptr_t)(u64)address
                                                      length:(NSUInteger)length
                                                    encoding:NSUTF8StringEncoding];
            if (text == nil) return -22;
            [pasteboard clearContents];
            return [pasteboard setString:text forType:NSPasteboardTypeString] ? length : -5;
        }
        return -22;
    }
}

/* async_host_runtime.c의 weak hook. 완전 유휴 앱은 pthread condition만
 * 기다리면 AppKit 키/포인터/Dock 이벤트에 깨지 못한다. 메인 스레드에서
 * native queue를 기다리고, worker 완료는 application-defined 이벤트를 넣어
 * 같은 대기를 깨운다. 이벤트는 dequeue하지 않아 다음 입력 poll이 처리한다. */
int32_t hmje_async_host_wait_ms(uint64_t timeout_ms) {
    if (NSApp == nil || ![NSThread isMainThread]) return -1;
    NSTimeInterval seconds = (NSTimeInterval)timeout_ms / 1000.0;
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:seconds];
    NSEvent *event = [NSApp nextEventMatchingMask:NSEventMaskAny
                                         untilDate:deadline
                                            inMode:NSDefaultRunLoopMode
                                           dequeue:NO];
    return event == nil ? 0 : 4;
}

void hmje_async_host_wake(void) {
    NSApplication *application = NSApp;
    if (application == nil) return;
    NSEvent *event = [NSEvent otherEventWithType:NSEventTypeApplicationDefined
                                        location:NSZeroPoint
                                   modifierFlags:0
                                       timestamp:0
                                    windowNumber:0
                                         context:nil
                                         subtype:109
                                           data1:0
                                           data2:0];
    [application postEvent:event atStart:NO];
}

/* ---- 창 지연 생성 + 이벤트 펌프 ------------------------------------------- */

static void ensure_window(void) {
    if (g_ready) {
        return;
    }
    @autoreleasepool {
        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];

        HmjeApplicationDelegate *applicationDelegate = [[HmjeApplicationDelegate alloc] init];
        g_application_delegate = applicationDelegate; /* NSApplication.delegate는 weak다. */
        [NSApp setDelegate:applicationDelegate];

        /* Metal 디바이스를 창보다 먼저 준비한다 — makeBackingLayer가 참조한다. */
        g_device = MTLCreateSystemDefaultDevice();
        if (g_device != nil) {
            g_queue = [g_device newCommandQueue];
            if (g_queue == nil) {
                g_device = nil; /* 큐가 없으면 CGImage 폴백 */
            }
        }

        NSRect frame = NSMakeRect(120, 120, DEFAULT_WIDTH, DEFAULT_HEIGHT);
        NSUInteger style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable |
                           NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable;
        NSWindow *window = [[NSWindow alloc] initWithContentRect:frame
                                                         styleMask:style
                                                           backing:NSBackingStoreBuffered
                                                             defer:NO];
        NSString *windowTitle = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
        if ([windowTitle length] == 0) {
            windowTitle = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"];
        }
        if ([windowTitle length] == 0) {
            windowTitle = [[NSProcessInfo processInfo] processName];
        }
        install_standard_application_menu(windowTitle);
        [window setTitle:windowTitle];
        [window setReleasedWhenClosed:NO];
        [window setDelegate:applicationDelegate];
        /* AppKit이 번들 기본설정 도메인에 프레임을 저장한다. 첫 실행에만
         * 위 DEFAULT_*가 쓰이고, 다음 실행부터는 최근 크기·위치가 복원된다. */
        [window setFrameAutosaveName:@"HMJE.MainWindow"];
        [window setContentMinSize:NSMakeSize(MIN_CONTENT_WIDTH, MIN_CONTENT_HEIGHT)];

        HmjeContentView *view = [[HmjeContentView alloc] initWithFrame:NSMakeRect(0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT)];
        if (g_device != nil) {
            [view setWantsLayer:YES]; /* makeBackingLayer → CAMetalLayer */
        }
        [window setContentView:view];
        [window makeFirstResponder:view];

        g_window = window;
        g_view = view;
        update_surface_geometry(NO); /* 초기 표면: 실제 창 크기 × 레티나 배율 */
        g_acked_width = g_width;
        g_acked_height = g_height;
        g_acked_scale = g_scale;
        g_ready = YES;
        surface_debug_log("init");

        /* run은 HMJE 루프와 충돌하므로 부르지 않지만, finishLaunching은
         * Dock Quit/Apple event/Cmd-Q가 표준 NSApplication 종료 경로로 오게 한다. */
        [NSApp finishLaunching];

        /* 키보드/IME 처리는 posix_host_text_input.m에 있다. KIND_KEY(+수정자) 큐잉과
         * NSTextInputClient 경유 KIND_TEXT(확정 문자) 큐잉을 그쪽이 전담한다. */
        hmje_posix_text_input_attach(window);
        g_key_monitor = [NSEvent addLocalMonitorForEventsMatchingMask:(NSEventMaskKeyDown | NSEventMaskKeyUp | NSEventMaskFlagsChanged)
                                                                handler:^NSEvent *(NSEvent *event) {
            return hmje_posix_text_input_handle_event(event);
        }];

        /* 포인터. 버튼이 안 눌린 이동은 창이 명시적으로 요청해야 온다. */
        [window setAcceptsMouseMovedEvents:YES];
        g_pointer_monitor = [NSEvent addLocalMonitorForEventsMatchingMask:
                                 (NSEventMaskMouseMoved
                                  | NSEventMaskLeftMouseDown | NSEventMaskLeftMouseUp | NSEventMaskLeftMouseDragged
                                  | NSEventMaskRightMouseDown | NSEventMaskRightMouseUp | NSEventMaskRightMouseDragged
                                  | NSEventMaskOtherMouseDown | NSEventMaskOtherMouseUp | NSEventMaskOtherMouseDragged
                                  | NSEventMaskScrollWheel)
                                                                handler:^NSEvent *(NSEvent *event) {
            return pointer_handle_event(event);
        }];

        [window makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];

        /* [NSApp run]을 안 부르므로, 창이 실제로 화면·키 포커스를 받으려면 초기 이벤트를
         * 몇 차례 수동으로 드레인해줘야 한다(윈도우 서버 왕복). */
        for (int i = 0; i < 20; i++) {
            NSEvent *event = [NSApp nextEventMatchingMask:NSEventMaskAny
                                                  untilDate:[NSDate distantPast]
                                                     inMode:NSDefaultRunLoopMode
                                                    dequeue:YES];
            if (event == nil) {
                break;
            }
            [NSApp sendEvent:event];
        }
        if (g_device == nil) {
            [view setNeedsDisplay:YES];
            [view displayIfNeeded];
        }
    }
}

static void pump_events(void) {
    @autoreleasepool {
        for (int i = 0; i < 64; i++) {
            NSEvent *event = [NSApp nextEventMatchingMask:NSEventMaskAny
                                                  untilDate:[NSDate distantPast]
                                                     inMode:NSDefaultRunLoopMode
                                                    dequeue:YES];
            if (event == nil) {
                break;
            }
            [NSApp sendEvent:event];
        }
    }
}

/* ---- 셀프테스트: 창 크기를 프로그램적으로 바꿔 리사이즈 경로를 자동 검증 ---- */
/* 카운터는 "빈 입력 poll"(프레임당 정확히 1번 — 앱 드레인의 종료 poll)로 센다.
 * present는 리드로가 있는 프레임에만 오므로(idle 최적화) 카운터가 멈출 수 있다. */

static void maybe_selftest_resize(void) {
    static BOOL done = NO;
    static u64 frame_count = 0;
    if (done) {
        return;
    }
    const char *spec = getenv("HMJE_POSIX_SELFTEST_RESIZE");
    if (spec == NULL) {
        done = YES;
        return;
    }
    frame_count++;
    unsigned long long target_w = 0, target_h = 0, at_frame = 90;
    if (sscanf(spec, "%llux%llu@%llu", &target_w, &target_h, &at_frame) < 2) {
        if (sscanf(spec, "%llux%llu", &target_w, &target_h) < 2) {
            fprintf(stderr, "posix-host-surface: selftest spec parse failed: %s\n", spec);
            done = YES;
            return;
        }
        at_frame = 90;
    }
    if (frame_count < at_frame) {
        return;
    }
    done = YES;
    fprintf(stderr, "posix-host-surface: selftest resizing window content to %llux%llu points\n",
            target_w, target_h);
    [g_window setContentSize:NSMakeSize((CGFloat)target_w, (CGFloat)target_h)];
    /* setContentSize → contentView setFrameSize → update_surface_geometry가
     * SURFACE_RESIZE 이벤트를 큐잉한다. 혹시 AppKit이 뷰 리사이즈를 지연시켜도
     * 아래 직접 호출이 잡는다(기하가 같으면 no-op이라 이중 이벤트는 없다). */
    update_surface_geometry(YES);
}

/* ---- 셀프테스트: 포인터를 합성해 상호작용 경로를 자동 검증 ----------------
 * HMJE_POSIX_SELFTEST_POINTER="move:250,250;press:0;move:550,450;release:0;scroll:0,-120"
 *   좌표는 **표면 픽셀**(왼쪽 위 원점) — 계약과 같은 단위다. 레티나 창이면
 *   논리 좌표의 두 배라는 뜻이고, 앱이 보는 값은 앱 루프가 논리로 낮춘 값이다.
 *   `wait:N`은 그 동작 전에 N 프레임을 흘려 보낸다(앱이 재구축·표시할 틈).
 *   HMJE_POSIX_SELFTEST_POINTER_AT=프레임 으로 시작 시점을 늦출 수 있다(기본 60).
 *
 * NSEvent를 실제로 만들어 우리 핸들러에 태우므로 좌표 변환·인코딩·앱 반응까지
 * 다 지난다. **안 지나는 것 하나**: AppKit이 창에 이벤트를 배달하는 구간이다
 * (그건 사람이 마우스를 움직여야 나오고, CGEvent 합성은 TCC 권한을 요구한다).
 * 사람이 하는 확인을 대신하지는 못하고, 회귀를 잡는 게 목적이다. */

static NSEvent *synth_mouse_event(NSEventType type, u64 px, u64 py, NSInteger button) {
    if (g_view == nil || g_window == nil || g_scale == 0) {
        return nil;
    }
    /* 뷰가 flipped라 여기도 뒤집지 않는다 — 위 pointer_pixel_location의 역이다. */
    CGFloat scale_f = (CGFloat)g_scale;
    NSPoint in_view = NSMakePoint((CGFloat)px / scale_f, (CGFloat)py / scale_f);
    NSPoint in_window = [g_view convertPoint:in_view toView:nil];
    return [NSEvent mouseEventWithType:type
                              location:in_window
                         modifierFlags:0
                             timestamp:[[NSProcessInfo processInfo] systemUptime]
                          windowNumber:[g_window windowNumber]
                               context:nil
                           eventNumber:0
                            clickCount:1
                              pressure:(type == NSEventTypeLeftMouseDown ? 1.0 : 0.0)];
}

/* 프레임 덤프 번호 매기기(dump_frame_path 주석). 셀프테스트 포인터가 도는 동안은
 * present가 아니라 **포인터 동작**이 번호를 올린다 — 두 실행이 같은 번호에서 같은
 * 포인터 위치를 뜻하게 하려면 그 방법뿐이다. */
static u64 g_dump_present_index = 0;
static u64 g_selftest_step_index = 0;
static BOOL g_selftest_pointer_active = NO;

static void selftest_push_scroll(u64 x, u64 y, i64 delta_x, i64 delta_y) {
    hmje_pointer_record record;
    memset(&record, 0, sizeof(record));
    record.phase = HMJE_POINTER_PHASE_SCROLL;
    record.pointer_id = 1u;
    record.x = (i64)x;
    record.y = (i64)y;
    record.time_us = (u64)([[NSProcessInfo processInfo] systemUptime] * 1000000.0);
    record.scroll_x = delta_x;
    record.scroll_y = delta_y;
    record.tool = HMJE_POINTER_TOOL_MOUSE;
    record.flags = HMJE_POINTER_CAP_BUTTONS | HMJE_POINTER_CAP_SCROLL;
    hmje_pointer_ring_push(&g_pointer_samples, record);

    key_ring_push(pointer_event_base(HMJE_INPUT_KIND_POINTER_MOVE, x, y));
    i64 legacy_y = delta_y;
    if (legacy_y != 0) {
        BOOL down = legacy_y < 0;
        u64 amount = (u64)(down ? -legacy_y : legacy_y);
        if (amount > HMJE_INPUT_SCROLL_AMOUNT_MASK) amount = HMJE_INPUT_SCROLL_AMOUNT_MASK;
        u64 packed = (HMJE_INPUT_KIND_POINTER_SCROLL << HMJE_INPUT_KIND_SHIFT)
                   | (amount & HMJE_INPUT_SCROLL_AMOUNT_MASK);
        if (down) packed |= HMJE_INPUT_SCROLL_DOWN_FLAG;
        key_ring_push(packed);
    }
}

static void maybe_selftest_pointer(void) {
    static BOOL done = NO;
    static u64 frame_count = 0;
    static u64 cursor_x = 0, cursor_y = 0;
    static char *script = NULL;
    static char *step = NULL;
    static u64 wait_until = 0;
    if (done) {
        return;
    }
    const char *spec = getenv("HMJE_POSIX_SELFTEST_POINTER");
    if (spec == NULL) {
        done = YES;
        return;
    }
    frame_count++;
    g_selftest_pointer_active = YES;
    if (script == NULL) {
        const char *at = getenv("HMJE_POSIX_SELFTEST_POINTER_AT");
        wait_until = at != NULL ? strtoull(at, NULL, 10) : 60;
        script = strdup(spec);
        step = script;
    }
    if (frame_count < wait_until) {
        return;
    }
    /* 프레임당 한 동작. 한 프레임에 몰아 넣으면 앱이 중간 상태를 못 보고,
     * 끌기는 이동 이벤트 사이의 재구축이 있어야 실제 경로를 밟는다. */
    if (step == NULL || *step == '\0') {
        done = YES;
        g_selftest_pointer_active = NO;
        if (g_dump_present_index <= g_selftest_step_index) {
            g_dump_present_index = g_selftest_step_index + 1;
        }
        fprintf(stderr, "posix-host-pointer: selftest done\n");
        return;
    }
    char *end = strchr(step, ';');
    if (end != NULL) {
        *end = '\0';
    }
    char *action = step;
    step = (end != NULL) ? end + 1 : NULL;
    /* 동작 하나를 소비했다 = 덤프 번호 하나. 이 동작이 낳는 present가 몇 번이든
     * 같은 파일을 덮어써서 **정착된** 프레임이 남는다. */
    g_selftest_step_index++;

    unsigned long long a = 0, b = 0;
    long long signed_a = 0, signed_b = 0;
    if (sscanf(action, "move:%llu,%llu", &a, &b) == 2) {
        cursor_x = a;
        cursor_y = b;
        NSEvent *event = synth_mouse_event(NSEventTypeMouseMoved, cursor_x, cursor_y, 0);
        if (event != nil) {
            pointer_handle_event(event);
        }
    } else if (sscanf(action, "drag:%llu,%llu", &a, &b) == 2) {
        cursor_x = a;
        cursor_y = b;
        NSEvent *event = synth_mouse_event(NSEventTypeLeftMouseDragged, cursor_x, cursor_y, 0);
        if (event != nil) {
            pointer_handle_event(event);
        }
    } else if (sscanf(action, "press:%llu", &a) == 1) {
        NSEvent *event = synth_mouse_event(NSEventTypeLeftMouseDown, cursor_x, cursor_y, (NSInteger)a);
        if (event != nil) {
            pointer_handle_event(event);
        }
    } else if (sscanf(action, "release:%llu", &a) == 1) {
        NSEvent *event = synth_mouse_event(NSEventTypeLeftMouseUp, cursor_x, cursor_y, (NSInteger)a);
        if (event != nil) {
            pointer_handle_event(event);
        }
    } else if (sscanf(action, "scroll:%lld,%lld", &signed_a, &signed_b) == 2) {
        selftest_push_scroll(cursor_x, cursor_y, (i64)signed_a, (i64)signed_b);
    } else if (sscanf(action, "scroll:%lld", &signed_b) == 1) {
        selftest_push_scroll(cursor_x, cursor_y, 0, (i64)signed_b);
    } else if (sscanf(action, "wait:%llu", &a) == 1) {
        wait_until = frame_count + a;
    } else {
        fprintf(stderr, "posix-host-pointer: 모르는 동작 '%s'\n", action);
    }
    fprintf(stderr, "posix-host-pointer: %s (커서 %llu,%llu)\n", action, cursor_x, cursor_y);
}

/* ---- 훈민정음 GPU 해석기가 부르는 평평한 Metal ABI ----------------------- */

#define HMJE_GPU_BEGIN 1
#define HMJE_GPU_CLIP 2
#define HMJE_GPU_UPLOAD_GLYPH 3
#define HMJE_GPU_DRAW 4
#define HMJE_GPU_IMAGE_BLIT 5
#define HMJE_GPU_END_PRESENT 6
#define HMJE_GPU_ABORT 7
#define HMJE_GPU_SCROLL_SHIFT 8
#define HMJE_GPU_COMPOSITE_TARGET 9
#define HMJE_GPU_IMAGE_SCALE_BLIT 12
#define HMJE_GPU_LAYER_BEGIN 13
#define HMJE_GPU_LAYER_END 14

typedef struct {
    float origin[2];
    float size[2];
    float color[4];
    float viewport[2];
    float padding[2];
    float params[4];
    float shadow[4];
} HmjeGpuUniforms;

static const char *hmje_gpu_msl =
"#include <metal_stdlib>\n"
"using namespace metal;\n"
"struct U{float2 origin;float2 size;float4 color;float2 viewport;float2 padding;float4 params;float4 shadow;};\n"
"struct O{float4 position [[position]];};\n"
"float sd(float2 l,float2 s,float r){float2 h=s*.5;float2 q=abs(l-h)-h+r;return length(max(q,float2(0)))+min(max(q.x,q.y),0.)-r;}\n"
"uint cv(float2 l,float2 s,float r){return uint(clamp(.5-sd(l,s,r),0.,1.)*255.);}\n"
"float af(uint c,float a){uint x=uint(round(a*255.));return float((c*x)/255u)/255.;}\n"
"vertex O vs(uint i [[vertex_id]],constant U&u [[buffer(0)]]){float2 q=float2(float(i&1u),float((i>>1u)&1u));float2 p=u.origin+q*u.size;O o;o.position=float4(p.x/u.viewport.x*2.-1.,1.-p.y/u.viewport.y*2.,0.,1.);return o;}\n"
"fragment float4 ps(O i [[stage_in]],constant U&u [[buffer(0)]]){int k=int(u.params.x+.5);if(k==0)return u.color;float2 l=i.position.xy-u.origin;if(k==3){float2 a=u.shadow.xy,b=u.shadow.zw,v=b-a;float vv=dot(v,v);float t=vv>1e-6?clamp(dot(i.position.xy-a,v)/vv,0.,1.):0.;float d=length(i.position.xy-(a+t*v));float f=clamp(u.params.y+.5-d,0.,1.);return float4(u.color.rgb,af(uint(f*255.),u.color.a));}if(k==5){float b=u.params.z;float2 so=u.origin+float2(b);float2 ss=u.size-float2(2.*b);float d=sd(i.position.xy-so,ss,u.params.y);float f;if(b<=0.)f=clamp(.5-d,0.,1.);else{float t=clamp((d+b)/(2.*b),0.,1.);f=1.-t*t*(3.-2.*t);}float inner=clamp(.5-sd(i.position.xy-u.shadow.xy,u.shadow.zw,u.params.w),0.,1.);f*=1.-inner;return float4(u.color.rgb,af(uint(f*255.),u.color.a));}uint o=cv(l,u.size,u.params.y);uint c=o;if(k==2){float2 s=u.size-float2(u.params.w*2.);uint n=cv(l-float2(u.params.w),s,u.params.z);c=o>n?o-n:0u;}return float4(u.color.rgb,af(c,u.color.a));}\n"
"fragment float4 pg(O i [[stage_in]],constant U&u [[buffer(0)]],texture2d<float,access::read> g [[texture(0)]]){int2 c=int2(floor((i.position.xy-u.origin)/max(u.params.y,1.)));uint v=uint(round(g.read(uint2(c)).r*255.));return float4(u.color.rgb,af(v,u.color.a));}\n"
"struct OI{float4 position [[position]];float2 uv;};\n"
"vertex OI vi(uint i [[vertex_id]],constant U&u [[buffer(0)]]){float2 q=float2(float(i&1u),float((i>>1u)&1u));float2 p=u.origin+q*u.size;OI o;o.position=float4(p.x/u.viewport.x*2.-1.,1.-p.y/u.viewport.y*2.,0.,1.);o.uv=q;return o;}\n"
"fragment float4 pi(OI i [[stage_in]],constant U&u [[buffer(0)]],texture2d<float> src [[texture(0)]]){constexpr sampler samp(coord::normalized,address::clamp_to_edge,filter::nearest);float4 c=src.sample(samp,i.uv);uint cov=cv(i.position.xy-u.origin,u.size,u.params.y);float a=u.params.z>0.5?af(cov,c.a):float(cov)/255.;return float4(c.rgb,a);}\n"
/* 층 합성: 그룹 불투명도. 층 텍스처는 시작 시 대상 픽셀을 그대로 떠서
 * 만들었으므로(HMJE_GPU_LAYER_BEGIN) 알파 채널 없이도 결과가 정확하다 —
 * CPU 재생기(command_interpreter.hmje)와 같은 모델이다. */
"fragment float4 pl(OI i [[stage_in]],constant U&u [[buffer(0)]],texture2d<float> src [[texture(0)]]){constexpr sampler samp(coord::normalized,address::clamp_to_edge,filter::nearest);float4 c=src.sample(samp,i.uv);return float4(c.rgb,u.color.a);}\n";

static BOOL hmje_gpu_prepare_pipelines(void) {
    if (g_gpu_shape_pipeline != nil && g_gpu_glyph_pipeline != nil && g_gpu_image_pipeline != nil &&
        g_gpu_layer_pipeline != nil) return YES;
    NSError *error = nil;
    id<MTLLibrary> library = [g_device newLibraryWithSource:[NSString stringWithUTF8String:hmje_gpu_msl]
                                                    options:nil error:&error];
    if (library == nil) {
        fprintf(stderr, "posix-host-gpu: shader compile failed: %s\n", error.localizedDescription.UTF8String);
        return NO;
    }
    MTLRenderPipelineDescriptor *description = [MTLRenderPipelineDescriptor new];
    description.vertexFunction = [library newFunctionWithName:@"vs"];
    description.fragmentFunction = [library newFunctionWithName:@"ps"];
    description.colorAttachments[0].pixelFormat = MTLPixelFormatBGRA8Unorm;
    description.colorAttachments[0].blendingEnabled = YES;
    description.colorAttachments[0].rgbBlendOperation = MTLBlendOperationAdd;
    description.colorAttachments[0].sourceRGBBlendFactor = MTLBlendFactorSourceAlpha;
    description.colorAttachments[0].destinationRGBBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    description.colorAttachments[0].alphaBlendOperation = MTLBlendOperationAdd;
    description.colorAttachments[0].sourceAlphaBlendFactor = MTLBlendFactorZero;
    description.colorAttachments[0].destinationAlphaBlendFactor = MTLBlendFactorZero;
    g_gpu_shape_pipeline = [g_device newRenderPipelineStateWithDescriptor:description error:&error];
    if (g_gpu_shape_pipeline == nil) return NO;
    description.fragmentFunction = [library newFunctionWithName:@"pg"];
    g_gpu_glyph_pipeline = [g_device newRenderPipelineStateWithDescriptor:description error:&error];
    if (g_gpu_glyph_pipeline == nil) return NO;
    description.vertexFunction = [library newFunctionWithName:@"vi"];
    description.fragmentFunction = [library newFunctionWithName:@"pi"];
    g_gpu_image_pipeline = [g_device newRenderPipelineStateWithDescriptor:description error:&error];
    if (g_gpu_image_pipeline == nil) return NO;
    description.fragmentFunction = [library newFunctionWithName:@"pl"];
    g_gpu_layer_pipeline = [g_device newRenderPipelineStateWithDescriptor:description error:&error];
    return g_gpu_layer_pipeline != nil;
}

static void hmje_gpu_end_render_encoder(void) {
    if (g_gpu_render_encoder != nil) {
        [g_gpu_render_encoder endEncoding];
        g_gpu_render_encoder = nil;
    }
}

static id<MTLRenderCommandEncoder> hmje_gpu_encoder(void) {
    if (g_gpu_render_encoder != nil) return g_gpu_render_encoder;
    id<MTLTexture> target = hmje_gpu_active_target();
    BOOL *needsClear = hmje_gpu_active_needs_clear_flag();
    MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
    pass.colorAttachments[0].texture = target;
    pass.colorAttachments[0].loadAction = *needsClear ? MTLLoadActionClear : MTLLoadActionLoad;
    pass.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 0);
    pass.colorAttachments[0].storeAction = MTLStoreActionStore;
    g_gpu_render_encoder = [g_gpu_command_buffer renderCommandEncoderWithDescriptor:pass];
    *needsClear = NO;
    [g_gpu_render_encoder setScissorRect:g_gpu_clip];
    return g_gpu_render_encoder;
}

/* BEGIN 요청은 [너비, 높이] 16바이트(target=0 기본값, 과거 호환) 또는
 * [너비, 높이, target] 24바이트를 받는다. target 0=화면(캔버스값, 매 프레임
 * drawable에 present), target 1=배경(persistent, 앱이 직접 present하지 않고
 * 캔버스값 쪽 합성 소스로만 쓰인다 — GPU_COMMAND_COMPOSITE_TARGET 참고). */
static i64 hmje_gpu_begin(const u64 *request, u64 length) {
    if ((length != 16 && length != 24) || request == NULL) return HMJE_POSIX_ENOSYS_LOCAL;
    const char *enabled = getenv("HMJE_POSIX_GPU");
    if (enabled != NULL && strcmp(enabled, "0") == 0) return HMJE_POSIX_ENOSYS_LOCAL;
    ensure_window();
    u64 width = request[0], height = request[1];
    int target = (length == 24 && request[2] == 1) ? 1 : 0;
    if (g_device == nil || width == 0 || height == 0 || !hmje_gpu_prepare_pipelines())
        return HMJE_POSIX_ENOSYS_LOCAL;
    g_gpu_current_target = target;
    __strong id<MTLTexture> *slot = target == 1 ? &g_gpu_target_bg : &g_gpu_target;
    BOOL *needsClear = target == 1 ? &g_gpu_target_bg_needs_clear : &g_gpu_target_needs_clear;
    if (*slot == nil || (u64)(*slot).width != width || (u64)(*slot).height != height) {
        id<MTLTexture> previous = *slot;
        MTLTextureDescriptor *description = [MTLTextureDescriptor
            texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                                     width:(NSUInteger)width height:(NSUInteger)height mipmapped:NO];
        description.usage = MTLTextureUsageRenderTarget | MTLTextureUsageShaderRead;
        description.storageMode = MTLStorageModePrivate;
        *slot = [g_device newTextureWithDescriptor:description];
        *needsClear = YES;
        /* 리사이즈로 target을 다시 만들 때 이전 내용을 옮겨 심는다. 검정으로
         * 비우고 부분 프레임을 기다리면, 전체 리페인트가 도착하기 전까지(또는
         * 그 프레임을 놓치면 계속) 안 그려진 영역이 **검은 띠**로 남는다 —
         * 2026-08-04 실사용에서 창 리사이즈 후 상단이 검게 남던 그 증상이다.
         * 이전 내용은 한 프레임 스케일이 어긋난 그림이지만 검정보다 낫고,
         * 리사이즈 경로의 전체 리페인트가 곧바로 덮는다. */
        if (previous != nil && *slot != nil) {
            id<MTLCommandBuffer> copy_commands = [g_queue commandBuffer];
            id<MTLBlitCommandEncoder> blit = [copy_commands blitCommandEncoder];
            NSUInteger copy_w = MIN((NSUInteger)previous.width, (NSUInteger)width);
            NSUInteger copy_h = MIN((NSUInteger)previous.height, (NSUInteger)height);
            [blit copyFromTexture:previous sourceSlice:0 sourceLevel:0
                     sourceOrigin:MTLOriginMake(0, 0, 0)
                       sourceSize:MTLSizeMake(copy_w, copy_h, 1)
                        toTexture:*slot destinationSlice:0 destinationLevel:0
                destinationOrigin:MTLOriginMake(0, 0, 0)];
            [blit endEncoding];
            [copy_commands commit];
            /* 같은 큐라 뒤 렌더 패스와 순서가 보장된다 — 대기 불필요. 복사해
             * 넣었으니 load-clear로 지우면 안 된다. */
            *needsClear = NO;
        }
    }
    if (*slot == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    g_gpu_command_buffer = [g_queue commandBuffer];
    g_gpu_render_encoder = nil;
    g_gpu_clip = (MTLScissorRect){0, 0, (NSUInteger)width, (NSUInteger)height};
    return g_gpu_command_buffer != nil ? 1 : HMJE_POSIX_ENOSYS_LOCAL;
}

static i64 hmje_gpu_set_clip(const u64 *r, u64 length) {
    if (length != 32 || r == NULL || g_gpu_command_buffer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    id<MTLTexture> target = hmje_gpu_active_target();
    u64 left=r[0], top=r[1], right=r[2], bottom=r[3];
    if (left > (u64)target.width) left=(u64)target.width;
    if (top > (u64)target.height) top=(u64)target.height;
    if (right < left) right=left;
    if (bottom < top) bottom=top;
    if (right > (u64)target.width) right=(u64)target.width;
    if (bottom > (u64)target.height) bottom=(u64)target.height;
    g_gpu_clip = (MTLScissorRect){(NSUInteger)left,(NSUInteger)top,
        (NSUInteger)(right-left),(NSUInteger)(bottom-top)};
    if (g_gpu_render_encoder != nil && g_gpu_clip.width > 0 && g_gpu_clip.height > 0)
        [g_gpu_render_encoder setScissorRect:g_gpu_clip];
    return 1;
}

#include "metal_glyph_cache.inc"
static i64 hmje_gpu_upload_glyph(const u64 *r, u64 length) {
    if (length != 32 || r == NULL) return HMJE_POSIX_ENOSYS_LOCAL;
    g_gpu_glyph = hmje_metal_glyph_texture(g_device,
        (const unsigned char *)(uintptr_t)r[0], r[1], r[2], r[3]);
    return g_gpu_glyph != nil ? 1 : HMJE_POSIX_ENOSYS_LOCAL;
}

static i64 hmje_gpu_draw(const u64 *request, u64 length) {
    if (length != 104 || request == NULL || g_gpu_command_buffer == nil) {
        return HMJE_POSIX_ENOSYS_LOCAL;
    }
    int kind = (int)request[0];
    if (kind != 0 && kind != 1 && kind != 2 && kind != 3 && kind != 4 && kind != 5) {
        return HMJE_POSIX_ENOSYS_LOCAL;
    }
    if (g_gpu_clip.width == 0 || g_gpu_clip.height == 0) return 1;
    if (kind != 3 && (request[3] == 0 || request[4] == 0)) return 1;
    if (kind == 3 && request[7] == 0) return 1;
    if (kind == 4 && g_gpu_glyph == nil) return HMJE_POSIX_ENOSYS_LOCAL;

    id<MTLTexture> target = hmje_gpu_active_target();
    if (target == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    HmjeGpuUniforms uniforms = {0};
    if (kind == 3) {
        /* HMJE has already flattened the cubic.  Draw one conservative quad
         * around this round-cap segment; the fragment shader evaluates exact
         * capsule distance, including the zero-length (circle) case. */
        double ax = (double)(i64)request[1], ay = (double)(i64)request[2];
        double bx = (double)(i64)request[3], by = (double)(i64)request[4];
        if (request[7] > UINT64_C(16777216)) return HMJE_POSIX_ENOSYS_LOCAL;
        double radius = (double)request[7] * 0.5;
        double left = floor(fmin(ax, bx) - radius - 1.0);
        double top = floor(fmin(ay, by) - radius - 1.0);
        double right = ceil(fmax(ax, bx) + radius + 1.0);
        double bottom = ceil(fmax(ay, by) + radius + 1.0);
        double clip_left = (double)g_gpu_clip.x;
        double clip_top = (double)g_gpu_clip.y;
        double clip_right = clip_left + (double)g_gpu_clip.width;
        double clip_bottom = clip_top + (double)g_gpu_clip.height;
        left = fmax(left, clip_left);
        top = fmax(top, clip_top);
        right = fmin(right, clip_right);
        bottom = fmin(bottom, clip_bottom);
        if (right <= left || bottom <= top) return 1;
        uniforms.origin[0] = (float)left;
        uniforms.origin[1] = (float)top;
        uniforms.size[0] = (float)(right - left);
        uniforms.size[1] = (float)(bottom - top);
        uniforms.params[1] = (float)radius;
        uniforms.shadow[0] = (float)ax;
        uniforms.shadow[1] = (float)ay;
        uniforms.shadow[2] = (float)bx;
        uniforms.shadow[3] = (float)by;
    } else {
        uniforms.origin[0] = (float)(i64)request[1];
        uniforms.origin[1] = (float)(i64)request[2];
        uniforms.size[0] = (float)request[3];
        uniforms.size[1] = (float)request[4];
        uniforms.params[1] = (float)request[5];
        uniforms.shadow[0] = (float)(i64)request[9];
        uniforms.shadow[1] = (float)(i64)request[10];
        uniforms.shadow[2] = (float)request[11];
        uniforms.shadow[3] = (float)request[12];
    }
    uniforms.color[0] = (float)((request[8] >> 16) & 255) / 255.0f;
    uniforms.color[1] = (float)((request[8] >> 8) & 255) / 255.0f;
    uniforms.color[2] = (float)(request[8] & 255) / 255.0f;
    uniforms.color[3] = (float)((request[8] >> 24) & 255) / 255.0f;
    uniforms.viewport[0] = (float)target.width;
    uniforms.viewport[1] = (float)target.height;
    uniforms.params[0] = (float)kind;
    uniforms.params[2] = (float)request[6];
    uniforms.params[3] = (float)request[7];
    if (kind == 1 || kind == 2) {
        u64 outer = MIN(request[5], MIN(request[3] / 2, request[4] / 2));
        uniforms.params[1] = (float)outer;
        if (kind == 2) {
            u64 innerWidth = request[7] <= request[3] / 2 ? request[3] - 2 * request[7] : 0;
            u64 innerHeight = request[7] <= request[4] / 2 ? request[4] - 2 * request[7] : 0;
            uniforms.params[2] = (float)MIN(request[6], MIN(innerWidth / 2, innerHeight / 2));
        }
    }

    id<MTLRenderCommandEncoder> encoder = hmje_gpu_encoder();
    if (encoder == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    [encoder setRenderPipelineState:kind == 4
        ? g_gpu_glyph_pipeline : g_gpu_shape_pipeline];
    [encoder setVertexBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    [encoder setFragmentBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    if (kind == 4) [encoder setFragmentTexture:g_gpu_glyph atIndex:0];
    [encoder drawPrimitives:MTLPrimitiveTypeTriangleStrip vertexStart:0 vertexCount:4];
    return 1;
}

static u64 hmje_macos_gpu_negative_magnitude(i64 value) {
    return (u64)(-(value + 1)) + 1;
}

/* Crop a 1:1 copy against source bounds, signed destination bounds, and the
 * current clip while advancing the source origin by the same amount. */
static BOOL hmje_macos_gpu_crop_copy(u64 source_width, u64 source_height,
                                   u64 target_width, u64 target_height,
                                   MTLScissorRect clip,
                                   u64 *source_x, u64 *source_y,
                                   u64 *copy_width, u64 *copy_height,
                                   i64 *destination_x, i64 *destination_y) {
    if (*source_x >= source_width || *source_y >= source_height ||
        *copy_width == 0 || *copy_height == 0 || clip.width == 0 || clip.height == 0) {
        return NO;
    }
    if (*copy_width > source_width - *source_x) *copy_width = source_width - *source_x;
    if (*copy_height > source_height - *source_y) *copy_height = source_height - *source_y;

    if (*destination_x < 0) {
        u64 amount = hmje_macos_gpu_negative_magnitude(*destination_x);
        if (amount >= *copy_width) return NO;
        *source_x += amount;
        *copy_width -= amount;
        *destination_x = 0;
    }
    if (*destination_y < 0) {
        u64 amount = hmje_macos_gpu_negative_magnitude(*destination_y);
        if (amount >= *copy_height) return NO;
        *source_y += amount;
        *copy_height -= amount;
        *destination_y = 0;
    }

    u64 dx = (u64)*destination_x, dy = (u64)*destination_y;
    if (dx >= target_width || dy >= target_height) return NO;
    if (*copy_width > target_width - dx) *copy_width = target_width - dx;
    if (*copy_height > target_height - dy) *copy_height = target_height - dy;

    u64 clip_left = (u64)clip.x, clip_top = (u64)clip.y;
    u64 clip_right = clip_left + (u64)clip.width;
    u64 clip_bottom = clip_top + (u64)clip.height;
    if (dx < clip_left) {
        u64 amount = clip_left - dx;
        if (amount >= *copy_width) return NO;
        *source_x += amount;
        *copy_width -= amount;
        dx = clip_left;
        *destination_x = (i64)dx;
    }
    if (dy < clip_top) {
        u64 amount = clip_top - dy;
        if (amount >= *copy_height) return NO;
        *source_y += amount;
        *copy_height -= amount;
        dy = clip_top;
        *destination_y = (i64)dy;
    }
    if (dx >= clip_right || dy >= clip_bottom) return NO;
    if (*copy_width > clip_right - dx) *copy_width = clip_right - dx;
    if (*copy_height > clip_bottom - dy) *copy_height = clip_bottom - dy;
    return *copy_width > 0 && *copy_height > 0;
}

static i64 hmje_gpu_image_blit(const u64 *r, u64 length) {
    if (length != 80 || r == NULL || g_gpu_command_buffer == nil || r[0] == 0) return HMJE_POSIX_ENOSYS_LOCAL;
    id<MTLTexture> target = hmje_gpu_active_target();
    u64 sourceWidth=r[1], sourceHeight=r[2], sourcePitch=r[3];
    if (sourceWidth > UINT64_MAX / 4 || sourcePitch < sourceWidth * 4 ||
        (sourceHeight != 0 && sourcePitch > UINT64_MAX / sourceHeight))
        return HMJE_POSIX_ENOSYS_LOCAL;
    u64 sourceX=r[4], sourceY=r[5], copyWidth=r[6], copyHeight=r[7];
    i64 destinationX=(i64)r[8], destinationY=(i64)r[9];
    if (!hmje_macos_gpu_crop_copy(sourceWidth, sourceHeight, target.width, target.height,
        g_gpu_clip, &sourceX, &sourceY, &copyWidth, &copyHeight, &destinationX, &destinationY))
        return 1;
    if (copyWidth > NSUIntegerMax / 4 || copyHeight > NSUIntegerMax / (copyWidth * 4))
        return HMJE_POSIX_ENOSYS_LOCAL;
    NSUInteger rowBytes=(NSUInteger)(copyWidth*4), byteCount=rowBytes*(NSUInteger)copyHeight;
    id<MTLBuffer> upload=[g_device newBufferWithLength:byteCount options:MTLResourceStorageModeShared];
    if (upload == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    unsigned char *destination=(unsigned char *)upload.contents;
    const unsigned char *source=(const unsigned char *)(uintptr_t)r[0]+sourceY*sourcePitch+sourceX*4;
    for (u64 row=0; row<copyHeight; ++row)
        memcpy(destination+row*rowBytes, source+row*sourcePitch, rowBytes);
    hmje_gpu_end_render_encoder();
    id<MTLBlitCommandEncoder> encoder=[g_gpu_command_buffer blitCommandEncoder];
    [encoder copyFromBuffer:upload sourceOffset:0 sourceBytesPerRow:rowBytes sourceBytesPerImage:byteCount
                 sourceSize:MTLSizeMake((NSUInteger)copyWidth,(NSUInteger)copyHeight,1)
                  toTexture:target destinationSlice:0 destinationLevel:0
         destinationOrigin:MTLOriginMake((NSUInteger)destinationX,(NSUInteger)destinationY,0)];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

/* GPU_COMMAND_IMAGE_SCALE_BLIT: 이미지 위젯(늘리기/여백맞춤/채우기). 위
 * hmje_gpu_image_blit과 달리 대상 사각형이 원본 영역과 다른 크기일 수 있어
 * 단순 텍스처-투-텍스처/버퍼-투-텍스처 blit(크기 불변 전제)으로는 안 된다 —
 * 대신 원본 크롭을 소스 텍스처로 올리고, 텍스처 샘플러(nearest, hmje-ui
 * core.hmje 캔버스이미지스케일그리기의 CPU 최근접 이웃 기준과 같은 사양)로
 * 대상 사각형 쿼드를 그린다. 소스 텍스처는 replaceRegion의 bytesPerRow가
 * 이미지 피치를 그대로 받아들이므로, 기존 hmje_gpu_image_blit처럼 별도
 * 스테이징 버퍼로 행을 다시 다져 넣을 필요가 없다. */
static i64 hmje_gpu_image_scale_blit(const u64 *r, u64 length) {
    if ((length != 104 && length != 112) || r == NULL || (length == 112 && r[13] != 1) || g_gpu_command_buffer == nil || r[0] == 0) return HMJE_POSIX_ENOSYS_LOCAL;
    if (g_gpu_clip.width == 0 || g_gpu_clip.height == 0) return 1;
    u64 sourceWidth=r[1], sourceHeight=r[2], sourcePitch=r[3];
    u64 sourceX=r[4], sourceY=r[5], copyWidth=r[6], copyHeight=r[7];
    i64 destinationX=(i64)r[8], destinationY=(i64)r[9];
    u64 destinationWidth=r[10], destinationHeight=r[11];
    if (sourceWidth > UINT64_MAX / 4 || sourcePitch < sourceWidth * 4 ||
        (sourceHeight != 0 && sourcePitch > UINT64_MAX / sourceHeight))
        return HMJE_POSIX_ENOSYS_LOCAL;
    if (sourceX >= sourceWidth || sourceY >= sourceHeight || destinationWidth == 0 || destinationHeight == 0)
        return 1;
    if (copyWidth > sourceWidth-sourceX) copyWidth=sourceWidth-sourceX;
    if (copyHeight > sourceHeight-sourceY) copyHeight=sourceHeight-sourceY;
    if (copyWidth == 0 || copyHeight == 0) return 1;
    /* Command buffers execute later. A subsequent image of the same size must
     * not replace pixels referenced by an already encoded draw. Metal retains
     * this immutable per-command upload until the command buffer completes. */
    MTLTextureDescriptor *description = [MTLTextureDescriptor
        texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
        width:(NSUInteger)copyWidth height:(NSUInteger)copyHeight mipmapped:NO];
    description.usage = MTLTextureUsageShaderRead;
    description.storageMode = MTLStorageModeShared;
    id<MTLTexture> imageSource = [g_device newTextureWithDescriptor:description];
    if (imageSource == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    const unsigned char *source=(const unsigned char *)(uintptr_t)r[0]+sourceY*sourcePitch+sourceX*4;
    [imageSource replaceRegion:MTLRegionMake2D(0,0,(NSUInteger)copyWidth,(NSUInteger)copyHeight)
                                mipmapLevel:0 withBytes:source bytesPerRow:(NSUInteger)sourcePitch];
    HmjeGpuUniforms u = {0};
    u.origin[0]=(float)destinationX; u.origin[1]=(float)destinationY;
    u.size[0]=(float)destinationWidth; u.size[1]=(float)destinationHeight;
    u64 imageRadius=r[12];
    if (imageRadius > destinationWidth/2) imageRadius=destinationWidth/2;
    if (imageRadius > destinationHeight/2) imageRadius=destinationHeight/2;
    u.params[1]=(float)imageRadius;
    u.params[2]=length == 112 ? 1.f : 0.f; /* explicit straight RGBA; legacy XRGB stays opaque */
    id<MTLTexture> activeTarget = hmje_gpu_active_target();
    u.viewport[0]=(float)activeTarget.width; u.viewport[1]=(float)activeTarget.height;
    id<MTLRenderCommandEncoder> encoder = hmje_gpu_encoder();
    [encoder setRenderPipelineState:g_gpu_image_pipeline];
    [encoder setVertexBytes:&u length:sizeof(u) atIndex:0];
    [encoder setFragmentBytes:&u length:sizeof(u) atIndex:0];
    [encoder setFragmentTexture:imageSource atIndex:0];
    [encoder drawPrimitives:MTLPrimitiveTypeTriangleStrip vertexStart:0 vertexCount:4];
    return 1;
}

/* GPU_COMMAND_COMPOSITE_TARGET: 다른 persistent target(현재는 항상 배경,
 * source_target=1)의 GPU 텍스처를 현재 활성 target(현재는 항상 화면, target=0)
 * 으로 텍스처-투-텍스처 blit한다. gpu_command_renderer.hmje가 이번 프레임
 * 화면 명령버퍼의 이미지블릿이 실제로는 "배경 자신의 GPU 텍스처를 그대로
 * 복사하라"는 뜻임을 감지했을 때만 이 op을 낸다(주소가 배경 캔버스의 CPU
 * 버퍼 기준주소와 일치하고 배경 GPU 텍스처가 최신 상태일 때) — 그 밖의
 * 임의 CPU 픽셀(아이콘/글리프/진단 버퍼) 이미지블릿은 여전히 기존
 * hmje_gpu_image_blit(CPU 업로드) 경로를 쓴다.
 * 페이로드(56B): [source_target, srcX, srcY, copyW, copyH, dstX, dstY]. */
static i64 hmje_gpu_composite_target(const u64 *r, u64 length) {
    if (length != 56 || r == NULL || g_gpu_command_buffer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    id<MTLTexture> source = r[0] == 1 ? g_gpu_target_bg : g_gpu_target;
    id<MTLTexture> destination = hmje_gpu_active_target();
    if (source == nil || destination == nil || source == destination) return HMJE_POSIX_ENOSYS_LOCAL;
    u64 sourceX=r[1], sourceY=r[2], copyWidth=r[3], copyHeight=r[4], destinationX=r[5], destinationY=r[6];
    if (sourceX >= (u64)source.width || sourceY >= (u64)source.height ||
        destinationX >= (u64)destination.width || destinationY >= (u64)destination.height) return 1;
    if (copyWidth > (u64)source.width-sourceX) copyWidth=(u64)source.width-sourceX;
    if (copyHeight > (u64)source.height-sourceY) copyHeight=(u64)source.height-sourceY;
    if (copyWidth > (u64)destination.width-destinationX) copyWidth=(u64)destination.width-destinationX;
    if (copyHeight > (u64)destination.height-destinationY) copyHeight=(u64)destination.height-destinationY;
    if (copyWidth == 0 || copyHeight == 0) return 1;
    hmje_gpu_end_render_encoder();
    id<MTLBlitCommandEncoder> encoder=[g_gpu_command_buffer blitCommandEncoder];
    [encoder copyFromTexture:source sourceSlice:0 sourceLevel:0
                 sourceOrigin:MTLOriginMake((NSUInteger)sourceX,(NSUInteger)sourceY,0)
                   sourceSize:MTLSizeMake((NSUInteger)copyWidth,(NSUInteger)copyHeight,1)
                    toTexture:destination destinationSlice:0 destinationLevel:0
            destinationOrigin:MTLOriginMake((NSUInteger)destinationX,(NSUInteger)destinationY,0)];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

/* library/runtime/user/draw_commands.hmje의 명령태그_세로스크롤시프트 계약과
 * 동일한 CPU 시맨틱(hmje-ui/oslib/graphics/core.hmje 캔버스세로이동)을 GPU
 * 텍스처 안에서 재현한다: 영역(x,y,w,h) 안에서 이동량만큼 행을 위/아래로
 * 밀고, 드러난 스트립은 그대로 둔다(같은 명령 버퍼의 다음 명령들이 그 스트립을
 * 전부 덮어 그린다는 게 호출자 쪽 불변식 — command_interpreter.hmje의
 * CPU 재생과 동일).
 * 같은 텍스처 안에서 겹치는 영역을 copyFromTexture:toTexture:로 직접 옮기는
 * 것은 Metal에서 정의되지 않은 동작이라(source/destination이 aliasing),
 * 임시 스크래치 텍스처로 한 번 옮겼다가 다시 옮기는 2단계 blit을 쓴다. */
static i64 hmje_gpu_scroll_shift(const u64 *r, u64 length) {
    id<MTLTexture> activeTarget = hmje_gpu_active_target();
    if (length != 48 || r == NULL || g_gpu_command_buffer == nil || activeTarget == nil)
        return HMJE_POSIX_ENOSYS_LOCAL;
    i64 sx = (i64)r[0], sy = (i64)r[1];
    u64 w = r[2], h = r[3], shift = r[4];
    BOOL down = r[5] != 0;
    u64 targetWidth = (u64)activeTarget.width, targetHeight = (u64)activeTarget.height;
    if (sx < 0) {
        u64 clip = (u64)(-sx);
        if (clip >= w) return 1;
        w -= clip; sx = 0;
    }
    if (sy < 0) {
        u64 clip = (u64)(-sy);
        if (clip >= h) return 1;
        h -= clip; sy = 0;
    }
    u64 x = (u64)sx, y = (u64)sy;
    if (x >= targetWidth || y >= targetHeight || w == 0 || h == 0) return 1;
    if (w > targetWidth - x) w = targetWidth - x;
    if (h > targetHeight - y) h = targetHeight - y;
    if (shift == 0 || shift >= h) return 1; /* CPU 쪽과 동일: 겹치는 픽셀 없음 → no-op */
    u64 copyHeight = h - shift;
    u64 srcY = down ? y : y + shift;
    u64 dstY = down ? y + shift : y;

    u64 scratchWidth = w, scratchHeight = copyHeight;
    if (g_gpu_scroll_scratch != nil) {
        scratchWidth = MAX(scratchWidth, (u64)g_gpu_scroll_scratch.width);
        scratchHeight = MAX(scratchHeight, (u64)g_gpu_scroll_scratch.height);
    }
    if (g_gpu_scroll_scratch == nil || (u64)g_gpu_scroll_scratch.width < w ||
        (u64)g_gpu_scroll_scratch.height < copyHeight) {
        MTLTextureDescriptor *description = [MTLTextureDescriptor
            texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                                          width:(NSUInteger)scratchWidth
                                         height:(NSUInteger)scratchHeight
                                      mipmapped:NO];
        description.usage = MTLTextureUsageShaderRead;
        description.storageMode = MTLStorageModePrivate;
        g_gpu_scroll_scratch = [g_device newTextureWithDescriptor:description];
    }
    if (g_gpu_scroll_scratch == nil) return HMJE_POSIX_ENOSYS_LOCAL;

    hmje_gpu_end_render_encoder();
    id<MTLBlitCommandEncoder> encoder = [g_gpu_command_buffer blitCommandEncoder];
    [encoder copyFromTexture:activeTarget sourceSlice:0 sourceLevel:0
                 sourceOrigin:MTLOriginMake((NSUInteger)x, (NSUInteger)srcY, 0)
                   sourceSize:MTLSizeMake((NSUInteger)w, (NSUInteger)copyHeight, 1)
                    toTexture:g_gpu_scroll_scratch destinationSlice:0 destinationLevel:0
            destinationOrigin:MTLOriginMake(0, 0, 0)];
    [encoder copyFromTexture:g_gpu_scroll_scratch sourceSlice:0 sourceLevel:0
                 sourceOrigin:MTLOriginMake(0, 0, 0)
                   sourceSize:MTLSizeMake((NSUInteger)w, (NSUInteger)copyHeight, 1)
                    toTexture:activeTarget destinationSlice:0 destinationLevel:0
            destinationOrigin:MTLOriginMake((NSUInteger)x, (NSUInteger)dstY, 0)];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

/* GPU_COMMAND_PLANAR_SHIFT: SCROLL_SHIFT의 두 축 판(캔버스 팬). 같은 텍스처 안에서
 * 겹치는 blit이라 스크래치를 경유하는 것도, 스크래치를 grow-only로 재사용하는 것도
 * 8번과 같다. 페이로드(64B): [x, y, w, h, dx, dy, right, down] — dx/dy는 크기이고
 * 방향은 뒤 두 칸이다(CPU 쪽 명령_평면시프트와 같은 표현).
 *
 * 클램프는 CPU(캔버스평면이동)와 **같은 순서**여야 한다: 영역을 대상 안으로 자른 뒤
 * |델타|가 변 이상이면 겹치는 픽셀이 없어 no-op. 순서가 어긋나면 GPU와 CPU가 다른
 * 픽셀을 옮겨 parity가 깨진다. */
#define HMJE_GPU_PLANAR_SHIFT 15

static i64 hmje_gpu_planar_shift(const u64 *r, u64 length) {
    id<MTLTexture> activeTarget = hmje_gpu_active_target();
    if (length != 64 || r == NULL || g_gpu_command_buffer == nil || activeTarget == nil)
        return HMJE_POSIX_ENOSYS_LOCAL;
    i64 sx = (i64)r[0], sy = (i64)r[1];
    u64 w = r[2], h = r[3], dx = r[4], dy = r[5];
    BOOL right = r[6] != 0, down = r[7] != 0;
    u64 targetWidth = (u64)activeTarget.width, targetHeight = (u64)activeTarget.height;
    if (sx < 0) {
        u64 clip = (u64)(-sx);
        if (clip >= w) return 1;
        w -= clip; sx = 0;
    }
    if (sy < 0) {
        u64 clip = (u64)(-sy);
        if (clip >= h) return 1;
        h -= clip; sy = 0;
    }
    u64 x = (u64)sx, y = (u64)sy;
    if (x >= targetWidth || y >= targetHeight || w == 0 || h == 0) return 1;
    if (w > targetWidth - x) w = targetWidth - x;
    if (h > targetHeight - y) h = targetHeight - y;
    if ((dx == 0 && dy == 0) || dx >= w || dy >= h) return 1;
    u64 copyWidth = w - dx, copyHeight = h - dy;
    u64 srcX = right ? x : x + dx;
    u64 dstX = right ? x + dx : x;
    u64 srcY = down ? y : y + dy;
    u64 dstY = down ? y + dy : y;

    u64 scratchWidth = copyWidth, scratchHeight = copyHeight;
    if (g_gpu_scroll_scratch != nil) {
        scratchWidth = MAX(scratchWidth, (u64)g_gpu_scroll_scratch.width);
        scratchHeight = MAX(scratchHeight, (u64)g_gpu_scroll_scratch.height);
    }
    if (g_gpu_scroll_scratch == nil || (u64)g_gpu_scroll_scratch.width < copyWidth ||
        (u64)g_gpu_scroll_scratch.height < copyHeight) {
        MTLTextureDescriptor *description = [MTLTextureDescriptor
            texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                                          width:(NSUInteger)scratchWidth
                                         height:(NSUInteger)scratchHeight
                                      mipmapped:NO];
        description.usage = MTLTextureUsageShaderRead;
        description.storageMode = MTLStorageModePrivate;
        g_gpu_scroll_scratch = [g_device newTextureWithDescriptor:description];
    }
    if (g_gpu_scroll_scratch == nil) return HMJE_POSIX_ENOSYS_LOCAL;

    hmje_gpu_end_render_encoder();
    id<MTLBlitCommandEncoder> encoder = [g_gpu_command_buffer blitCommandEncoder];
    [encoder copyFromTexture:activeTarget sourceSlice:0 sourceLevel:0
                 sourceOrigin:MTLOriginMake((NSUInteger)srcX, (NSUInteger)srcY, 0)
                   sourceSize:MTLSizeMake((NSUInteger)copyWidth, (NSUInteger)copyHeight, 1)
                    toTexture:g_gpu_scroll_scratch destinationSlice:0 destinationLevel:0
            destinationOrigin:MTLOriginMake(0, 0, 0)];
    [encoder copyFromTexture:g_gpu_scroll_scratch sourceSlice:0 sourceLevel:0
                 sourceOrigin:MTLOriginMake(0, 0, 0)
                   sourceSize:MTLSizeMake((NSUInteger)copyWidth, (NSUInteger)copyHeight, 1)
                    toTexture:activeTarget destinationSlice:0 destinationLevel:0
            destinationOrigin:MTLOriginMake((NSUInteger)dstX, (NSUInteger)dstY, 0)];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

#define HMJE_METAL_BLUR_MARK_INITIALIZED() (*hmje_gpu_active_needs_clear_flag() = NO)
#include "metal_backdrop_blur.inc"
#undef HMJE_METAL_BLUR_MARK_INITIALIZED

#define HMJE_GPU_GRADIENT_FILL 11

/* GPU_COMMAND_GRADIENT_FILL: 균등 간격 정지점 선형 그라데이션 채우기.
 * CPU 기준(core.hmje 캔버스그라데이션채우기)의 사양을 프래그먼트 1개당 순수
 * 보간으로 재현하는 단일 패스다:
 *   축 위치 = 픽셀 정수 인덱스(논리 영역 원점 기준, floor(중심좌표) - 원점),
 *   t = p / 분모(세로 h-1 / 가로 w-1 / 대각 (w-1)+(h-1)),
 *   s = t·(색상수-1), 구간 = floor(s)(끝은 색상수-2), 조각 = s-구간,
 *   채널 = round(c0 + (c1-c0)·조각) — CPU가 실수64로 1회 반올림하는 것과
 *   대수적으로 같은 식(0..255 스케일에서 반올림 후 정규화),
 *   rounded-box SDF 하드 엣지 커버리지×보간 알파를 (cov·a)/255 정수 절삭으로
 *   합쳐 src 알파로 고정기능 블렌드(도형 파이프라인과 같은 합성 계약).
 * 페이로드(120B): [x, y, w, h, cornerRadius, direction, count, c1..c8]. */
static const char *hmje_gpu_gradient_msl =
"#include <metal_stdlib>\n"
"using namespace metal;\n"
"struct GU{float2 origin;float2 size;float2 viewport;float2 misc;float4 params;float4 colors[8];};\n"
"struct O{float4 position [[position]];};\n"
"float gsd(float2 l,float2 s,float r){float2 h=s*.5;float2 q=abs(l-h)-h+r;return length(max(q,float2(0)))+min(max(q.x,q.y),0.)-r;}\n"
"vertex O gvs(uint i [[vertex_id]],constant GU&u [[buffer(0)]]){float2 q=float2(float(i&1u),float((i>>1u)&1u));float2 p=u.origin+q*u.size;O o;o.position=float4(p.x/u.viewport.x*2.-1.,1.-p.y/u.viewport.y*2.,0.,1.);return o;}\n"
"fragment float4 gfs(O i [[stage_in]],constant GU&u [[buffer(0)]]){\n"
"float2 lc=i.position.xy-u.origin;\n"
"float px=floor(lc.x);float py=floor(lc.y);\n"
"int dir=int(u.misc.x+.5);int n=int(u.misc.y+.5);\n"
"float w=u.size.x;float h=u.size.y;\n"
"float p=dir==1?py:(dir==3?(px+py):px);\n"
"float denom=dir==1?(h-1.):(dir==3?((w-1.)+(h-1.)):(w-1.));\n"
"float t=denom>0.?clamp(p/denom,0.,1.):0.;\n"
"if(dir==4||dir==5){float2 rr=max((u.size-1.)*.5,float2(.5));if(dir==4)rr=float2(min(rr.x,rr.y));t=length((float2(px,py)-(u.size-1.)*.5)/rr);}\n"
"float s=t*float(n-1);\n"
"int seg=clamp(int(floor(s)),0,n-2);\n"
"float frac=s-float(seg);\n"
"float4 c0=u.colors[seg];float4 c1=u.colors[seg+1];\n"
"float4 c=round(c0+(c1-c0)*frac);\n"
"uint covb=uint(saturate(.5-gsd(lc,u.size,u.params.x))*255.);\n"
"uint fillA=uint(c.a);\n"
"uint combined=(covb*fillA)/255u;\n"
"return float4(c.rgb/255.,float(combined)/255.);}\n";

typedef struct {
    float origin[2];
    float size[2];
    float viewport[2];
    float misc[2];      /* x=방향(1/2/3), y=색상수 */
    float params[4];    /* x=모서리반경(클램프 후) */
    float colors[8][4]; /* 0..255 스케일 RGBA — 프래그먼트가 round 후 정규화 */
} HmjeGpuGradientUniforms;

static BOOL hmje_gpu_prepare_gradient_pipeline(void) {
    if (g_gpu_gradient_pipeline != nil) return YES;
    NSError *error = nil;
    id<MTLLibrary> library = [g_device newLibraryWithSource:[NSString stringWithUTF8String:hmje_gpu_gradient_msl]
                                                    options:nil error:&error];
    if (library == nil) {
        fprintf(stderr, "posix-host-gpu: gradient shader compile failed: %s\n",
                error.localizedDescription.UTF8String);
        return NO;
    }
    /* 도형 파이프라인과 같은 고정기능 블렌드(BGRA target). */
    MTLRenderPipelineDescriptor *description = [MTLRenderPipelineDescriptor new];
    description.vertexFunction = [library newFunctionWithName:@"gvs"];
    description.fragmentFunction = [library newFunctionWithName:@"gfs"];
    description.colorAttachments[0].pixelFormat = MTLPixelFormatBGRA8Unorm;
    description.colorAttachments[0].blendingEnabled = YES;
    description.colorAttachments[0].rgbBlendOperation = MTLBlendOperationAdd;
    description.colorAttachments[0].sourceRGBBlendFactor = MTLBlendFactorSourceAlpha;
    description.colorAttachments[0].destinationRGBBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    description.colorAttachments[0].alphaBlendOperation = MTLBlendOperationAdd;
    description.colorAttachments[0].sourceAlphaBlendFactor = MTLBlendFactorZero;
    description.colorAttachments[0].destinationAlphaBlendFactor = MTLBlendFactorZero;
    g_gpu_gradient_pipeline = [g_device newRenderPipelineStateWithDescriptor:description error:&error];
    return g_gpu_gradient_pipeline != nil;
}

static i64 hmje_gpu_gradient_fill(const u64 *r, u64 length) {
    id<MTLTexture> target = hmje_gpu_active_target();
    if (length != 120 || r == NULL || g_gpu_command_buffer == nil || target == nil)
        return HMJE_POSIX_ENOSYS_LOCAL;
    if (!hmje_gpu_prepare_gradient_pipeline()) return HMJE_POSIX_ENOSYS_LOCAL;
    i64 regionX = (i64)r[0], regionY = (i64)r[1];
    u64 regionWidth = r[2], regionHeight = r[3];
    u64 cornerRadius = r[4], direction = r[5], count = r[6];
    if (regionWidth == 0 || regionHeight == 0) return 1;
    if (count < 2) return 1; /* CPU와 동일: 정지점 부족은 조용한 no-op */
    if (count > 8) count = 8;
    /* 모서리 반경 클램프(CPU와 동일 규칙). */
    u64 radius = cornerRadius;
    if (radius > regionWidth / 2) radius = regionWidth / 2;
    if (radius > regionHeight / 2) radius = regionHeight / 2;

    HmjeGpuGradientUniforms u = {{0}};
    u.origin[0] = (float)regionX; u.origin[1] = (float)regionY;
    u.size[0] = (float)regionWidth; u.size[1] = (float)regionHeight;
    u.viewport[0] = (float)target.width; u.viewport[1] = (float)target.height;
    u.misc[0] = (float)direction; u.misc[1] = (float)count;
    u.params[0] = (float)radius;
    for (u64 i = 0; i < 8; ++i) {
        uint32_t argb = (uint32_t)r[7 + (i < count ? i : count - 1)];
        u.colors[i][0] = (float)((argb >> 16) & 255);
        u.colors[i][1] = (float)((argb >> 8) & 255);
        u.colors[i][2] = (float)(argb & 255);
        u.colors[i][3] = (float)((argb >> 24) & 255);
    }

    /* 도형과 같은 target에 그리지만 셰이더/유니폼이 달라 별도 패스로 그린다 —
     * 공유 lazy encoder를 닫고 LoadActionLoad로 전용 패스를 연다(블러 합성
     * 패스와 같은 구조, 현재 scissor 존중). */
    hmje_gpu_end_render_encoder();
    MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
    pass.colorAttachments[0].texture = target;
    pass.colorAttachments[0].loadAction = MTLLoadActionLoad;
    pass.colorAttachments[0].storeAction = MTLStoreActionStore;
    id<MTLRenderCommandEncoder> encoder =
        [g_gpu_command_buffer renderCommandEncoderWithDescriptor:pass];
    if (g_gpu_clip.width > 0 && g_gpu_clip.height > 0)
        [encoder setScissorRect:g_gpu_clip];
    [encoder setRenderPipelineState:g_gpu_gradient_pipeline];
    [encoder setVertexBytes:&u length:sizeof(u) atIndex:0];
    [encoder setFragmentBytes:&u length:sizeof(u) atIndex:0];
    [encoder drawPrimitives:MTLPrimitiveTypeTriangleStrip vertexStart:0 vertexCount:4];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

static void dump_gpu_target_debug(void);
static void dump_gpu_target_bg_debug(void);

/* target 0(화면)은 기존과 동일하게 drawable로 blit→present→commit한다.
 * target 1(배경)은 화면에 아무것도 보여주지 않는 persistent 저장소이므로
 * drawable을 취하지 않고 커맨드 버퍼만 commit해 GPU에 실제로 반영시킨다 —
 * 그래야 다음에 이 텍스처를 소스로 쓰는 COMPOSITE_TARGET/다음 프레임 배경
 * 갱신이 이번에 그린 내용을 실제로 본다. */
static i64 hmje_gpu_end_present(void) {
    if (g_gpu_command_buffer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    /* 층이 열린 채로 present가 오면 기록이 짝이 안 맞은 것이다. 남겨 두면
     * 다음 프레임이 엉뚱한 텍스처에 그리므로 깊이를 여기서 되돌린다. */
    g_gpu_layer_depth = 0;
    hmje_gpu_end_render_encoder();
    if (g_gpu_current_target == 1) {
        [g_gpu_command_buffer commit];
        [g_gpu_command_buffer waitUntilCompleted];
        BOOL bgOk = g_gpu_command_buffer.status != MTLCommandBufferStatusError;
        g_gpu_command_buffer = nil;
        if (bgOk) dump_gpu_target_bg_debug();
        return bgOk ? 1 : HMJE_POSIX_ENOSYS_LOCAL;
    }
    id<CAMetalDrawable> drawable=[g_layer nextDrawable];
    if (drawable == nil) { g_gpu_command_buffer=nil; return 1; }
    u64 width=(u64)MIN(g_gpu_target.width, drawable.texture.width);
    u64 height=(u64)MIN(g_gpu_target.height, drawable.texture.height);
    id<MTLBlitCommandEncoder> blit=[g_gpu_command_buffer blitCommandEncoder];
    [blit copyFromTexture:g_gpu_target sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0,0,0)
               sourceSize:MTLSizeMake((NSUInteger)width,(NSUInteger)height,1)
                toTexture:drawable.texture destinationSlice:0 destinationLevel:0
       destinationOrigin:MTLOriginMake(0,0,0)];
    [blit endEncoding];
    [g_gpu_command_buffer presentDrawable:drawable];
    [g_gpu_command_buffer commit];
    [g_gpu_command_buffer waitUntilCompleted];
    BOOL ok=g_gpu_command_buffer.status != MTLCommandBufferStatusError;
    g_gpu_command_buffer=nil;
    pump_events();
    static BOOL reported = NO;
    if (ok && !reported && getenv("HMJE_POSIX_DEBUG_GPU") != NULL) {
        fprintf(stderr, "posix-host-gpu: direct command rendering active (%llux%llu, scale=%llu)\n",
                g_width, g_height, g_scale);
        reported = YES;
    }
    if (ok) {
        /* HMJE_POSIX_DUMP_FRAME은 원래 CPU framebuffer 경로(dump_frame_debug)만
         * 덮었다 — GPU 직접 렌더 프레임은 g_backbuffer를 안 건드리므로 그쪽
         * 덤프가 비어있었다. 검증 편의를 위해 같은 이스케이프 해치로 GPU
         * persistent target(g_gpu_target)도 덤프한다(env var 미설정이면 무비용). */
        dump_gpu_target_debug();
    }
    return ok ? 1 : HMJE_POSIX_ENOSYS_LOCAL;
}

/* HMJE_GPU_LAYER_BEGIN: [x, y, 너비, 높이, 불투명도] 40바이트.
 *
 * 그룹 불투명도(SwiftUI `.opacity`)의 GPU 절반. 서브트리를 층 텍스처에 그린
 * 뒤 한 번에 얹어야 겹친 자식이 두 번 섞이지 않는다.
 *
 * 층을 투명하게 시작하지 않고 **현재 대상의 해당 영역을 그대로 떠서** 시작하는
 * 것이 핵심이다 — 그러면 알파 채널을 따로 관리하지 않아도 결과가 정확하고,
 * CPU 재생기(hmje-ui command_interpreter.hmje)와 정확히 같은 모델이 된다.
 *
 * 층 텍스처의 UV는 항상 0..1 전체 범위를 읽으므로 슬롯의 이전 텍스처가 더
 * 크면 현재 층으로 축소 샘플링되어 과거 픽셀이 섞인다. 따라서 크기가 정확히
 * 같을 때만 재사용한다. 한 프레임에 반투명 뷰가 수십 개 있어도 텍스처는
 * 중첩 깊이만큼만 존재한다. */
static i64 hmje_gpu_layer_begin(const u64 *r, u64 length) {
    if (length != 40 || r == NULL || g_gpu_command_buffer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    if (g_gpu_layer_depth >= HMJE_GPU_LAYER_MAX) return HMJE_POSIX_ENOSYS_LOCAL;
    id<MTLTexture> source = hmje_gpu_active_target();
    if (source == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    u64 x = r[0], y = r[1], width = r[2], height = r[3], alpha = r[4];
    if (x >= (u64)source.width || y >= (u64)source.height) return HMJE_POSIX_ENOSYS_LOCAL;
    if (width > (u64)source.width - x) width = (u64)source.width - x;
    if (height > (u64)source.height - y) height = (u64)source.height - y;
    if (width == 0 || height == 0) return HMJE_POSIX_ENOSYS_LOCAL;

    int slot = g_gpu_layer_depth;
    id<MTLTexture> layer = g_gpu_layer_texture[slot];
    if (layer == nil || (u64)layer.width != width || (u64)layer.height != height) {
        MTLTextureDescriptor *description = [MTLTextureDescriptor
            texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                                         width:(NSUInteger)width height:(NSUInteger)height mipmapped:NO];
        description.usage = MTLTextureUsageRenderTarget | MTLTextureUsageShaderRead;
        description.storageMode = MTLStorageModePrivate;
        layer = [g_device newTextureWithDescriptor:description];
        if (layer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
        g_gpu_layer_texture[slot] = layer;
    }

    hmje_gpu_end_render_encoder();
    id<MTLBlitCommandEncoder> encoder = [g_gpu_command_buffer blitCommandEncoder];
    [encoder copyFromTexture:source sourceSlice:0 sourceLevel:0
                sourceOrigin:MTLOriginMake((NSUInteger)x, (NSUInteger)y, 0)
                  sourceSize:MTLSizeMake((NSUInteger)width, (NSUInteger)height, 1)
                   toTexture:layer destinationSlice:0 destinationLevel:0
           destinationOrigin:MTLOriginMake(0, 0, 0)];
    [encoder endEncoding];

    g_gpu_layer_saved_target[slot] = source;
    g_gpu_layer_saved_clip[slot] = g_gpu_clip;
    g_gpu_layer_x[slot] = x;
    g_gpu_layer_y[slot] = y;
    g_gpu_layer_w[slot] = width;
    g_gpu_layer_h[slot] = height;
    g_gpu_layer_alpha[slot] = alpha > 255 ? 255 : alpha;
    g_gpu_layer_depth = slot + 1;
    /* 층 좌표계로 옮긴 클립. 층 밖은 애초에 존재하지 않으므로 전체로 연다. */
    g_gpu_clip = (MTLScissorRect){0, 0, (NSUInteger)width, (NSUInteger)height};
    return 1;
}

/* HMJE_GPU_LAYER_END: 페이로드 없음. 층을 불투명도로 얹고 대상을 되돌린다. */
static i64 hmje_gpu_layer_end(u64 length) {
    if (length != 0 || g_gpu_command_buffer == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    if (g_gpu_layer_depth <= 0) return 1;
    int slot = --g_gpu_layer_depth;
    id<MTLTexture> layer = g_gpu_layer_texture[slot];
    id<MTLTexture> target = g_gpu_layer_saved_target[slot];
    g_gpu_clip = g_gpu_layer_saved_clip[slot];
    g_gpu_layer_saved_target[slot] = nil;
    if (layer == nil || target == nil) return HMJE_POSIX_ENOSYS_LOCAL;

    hmje_gpu_end_render_encoder();
    MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
    pass.colorAttachments[0].texture = target;
    pass.colorAttachments[0].loadAction = MTLLoadActionLoad;
    pass.colorAttachments[0].storeAction = MTLStoreActionStore;
    id<MTLRenderCommandEncoder> encoder = [g_gpu_command_buffer renderCommandEncoderWithDescriptor:pass];
    if (encoder == nil) return HMJE_POSIX_ENOSYS_LOCAL;
    [encoder setScissorRect:g_gpu_clip];
    HmjeGpuUniforms uniforms;
    memset(&uniforms, 0, sizeof(uniforms));
    uniforms.origin[0] = (float)g_gpu_layer_x[slot];
    uniforms.origin[1] = (float)g_gpu_layer_y[slot];
    uniforms.size[0] = (float)g_gpu_layer_w[slot];
    uniforms.size[1] = (float)g_gpu_layer_h[slot];
    uniforms.viewport[0] = (float)target.width;
    uniforms.viewport[1] = (float)target.height;
    uniforms.color[3] = (float)g_gpu_layer_alpha[slot] / 255.0f;
    [encoder setRenderPipelineState:g_gpu_layer_pipeline];
    [encoder setVertexBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    [encoder setFragmentBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    [encoder setFragmentTexture:layer atIndex:0];
    [encoder drawPrimitives:MTLPrimitiveTypeTriangleStrip vertexStart:0 vertexCount:4];
    [encoder endEncoding];
    *hmje_gpu_active_needs_clear_flag() = NO;
    return 1;
}

static i64 hmje_gpu_abort(void) {
    g_gpu_layer_depth = 0;
    if (g_gpu_command_buffer == nil) return 1;
    hmje_gpu_end_render_encoder();
    g_gpu_command_buffer = nil;
    return 1;
}

i64 hmje_posix_gpu_command(i64 kind, i64 request_address, i64 request_length) {
    @autoreleasepool {
        const u64 *request=(const u64 *)(uintptr_t)(u64)request_address;
        u64 length=request_length < 0 ? 0 : (u64)request_length;
        if (kind == 0) {
            if (length != 32 || request == NULL) return HMJE_POSIX_ENOSYS_LOCAL;
            u64 *output=(u64 *)(uintptr_t)(u64)request_address;
            output[0]=2; output[1]=1; output[2]=UINT64_C(0x000000000000fffe); output[3]=0;
            return 32;
        }
        i64 result = HMJE_POSIX_ENOSYS_LOCAL;
        switch (kind) {
        case HMJE_GPU_BEGIN: result=hmje_gpu_begin(request,length); break;
        case HMJE_GPU_CLIP: result=hmje_gpu_set_clip(request,length); break;
        case HMJE_GPU_UPLOAD_GLYPH: result=hmje_gpu_upload_glyph(request,length); break;
        case HMJE_GPU_DRAW: result=hmje_gpu_draw(request,length); break;
        case HMJE_GPU_IMAGE_BLIT: result=hmje_gpu_image_blit(request,length); break;
        case HMJE_GPU_IMAGE_SCALE_BLIT: result=hmje_gpu_image_scale_blit(request,length); break;
        case HMJE_GPU_LAYER_BEGIN: result=hmje_gpu_layer_begin(request,length); break;
        case HMJE_GPU_LAYER_END: result=hmje_gpu_layer_end(length); break;
        case HMJE_GPU_END_PRESENT: result=hmje_gpu_end_present(); break;
        case HMJE_GPU_ABORT: result=hmje_gpu_abort(); break;
        case HMJE_GPU_SCROLL_SHIFT: result=hmje_gpu_scroll_shift(request,length); break;
        case HMJE_GPU_PLANAR_SHIFT: result=hmje_gpu_planar_shift(request,length); break;
        case HMJE_GPU_COMPOSITE_TARGET: result=hmje_gpu_composite_target(request,length); break;
        case HMJE_GPU_BACKDROP_BLUR: result=hmje_gpu_backdrop_blur(request,length); break;
        case HMJE_GPU_GRADIENT_FILL: result=hmje_gpu_gradient_fill(request,length); break;
        default: break;
        }
        return result;
    }
}

/* ---- posix_host_shim.c 가 부르는 기존 framebuffer/input 함수 ------------ */

i64 hmje_posix_framebuffer_info(i64 out_address, i64 out_length) {
    ensure_window();
    if (out_length < 48) {
        return HMJE_POSIX_ENOSYS_LOCAL;
    }
    u64 *out = (u64 *)(uintptr_t)(u64)out_address;
    out[0] = g_width;
    out[1] = g_height;
    out[2] = g_pitch;
    out[3] = 4;  /* pixel_bytes */
    out[4] = 1;  /* FRAMEBUFFER_FORMAT_XRGB8888 (canonical) */
    out[5] = 1;  /* FRAMEBUFFER_FLAG_PRESENT */
    if (out_length >= 56) {
        out[6] = g_scale; /* v2 확장: FRAMEBUFFER_INFO_SCALE_OFFSET(48) */
        return 56;
    }
    return 48;
}

i64 hmje_posix_framebuffer_blit(i64 buffer_address, i64 width, i64 height, i64 pitch, i64 x, i64 y) {
    ensure_window();
    if (width <= 0 || height <= 0 || pitch <= 0) {
        return 0;
    }
    u64 uw = (u64)width, uh = (u64)height, upitch = (u64)pitch;
    u64 ux = (u64)x, uy = (u64)y;
    if (ux >= g_width || uy >= g_height) {
        return 0;
    }
    u64 copy_w = uw;
    if (ux + copy_w > g_width) {
        copy_w = g_width - ux;
    }
    u64 copy_h = uh;
    if (uy + copy_h > g_height) {
        copy_h = g_height - uy;
    }
    if (copy_w == 0 || copy_h == 0) {
        return 0;
    }
    const unsigned char *src_base = (const unsigned char *)(uintptr_t)(u64)buffer_address;
    i64 total = 0;
    for (u64 row = 0; row < copy_h; row++) {
        const unsigned char *src_row = src_base + row * upitch;
        unsigned char *dst_row = g_backbuffer + (uy + row) * g_pitch + ux * 4;
        size_t bytes = (size_t)(copy_w * 4);
        memcpy(dst_row, src_row, bytes);
        total += (i64)bytes;
    }
    return total;
}

/* HMJE_POSIX_DUMP_FRAME은 한 파일을 매 프레임 덮어쓴다 — 마지막 프레임만 남는다.
 * 상호작용 중 **스쳐 가는** 프레임(호버 damage가 한두 프레임만 깨지는 것 같은)은
 * 그걸로 못 잡는다. HMJE_POSIX_DUMP_FRAME_DIR을 주면 프레임마다 번호를 붙여
 * <dir>/frame-000042.png로 남긴다 — 두 실행을 프레임 대 프레임으로 견주는
 * parity 검사의 재료다(semtleOS tools/ui_frame_parity_check.py). 디렉터리는
 * 부르는 쪽이 미리 만든다.
 *
 * 한 프레임에 덤프 함수가 둘 다 도는 일은 없다 — GPU 프레임은 present를
 * 건너뛰므로 GPU 덤프만, CPU 프레임은 CPU 덤프만 돈다. 그래서 카운터 하나면 된다.
 *
 * **셀프테스트 포인터가 돌 때는 번호를 present가 아니라 포인터 동작에 맞춘다.**
 * present 수로 세면 두 실행이 어긋난다 — 렌더가 느린 쪽이 같은 입력에 present를
 * 덜/더 하기 때문이다(실측: 증분은 15번째 프레임에 단추를, 전체는 카드를 호버하고
 * 있었다 — 렌더 버그가 아니라 번호가 밀린 것이었다). 동작 번호로 세면 한 동작에
 * 여러 번 present해도 같은 파일을 덮어써서 **그 동작의 정착된 프레임**이 남고,
 * 두 실행의 같은 번호가 같은 포인터 위치를 뜻한다. */
static const char *dump_frame_path(char *buffer, size_t size) {
    const char *directory = getenv("HMJE_POSIX_DUMP_FRAME_DIR");
    if (directory != NULL) {
        u64 index = g_selftest_pointer_active ? g_selftest_step_index : g_dump_present_index++;
        snprintf(buffer, size, "%s/frame-%06llu.png", directory, (unsigned long long)index);
        return buffer;
    }
    return getenv("HMJE_POSIX_DUMP_FRAME");
}

static void dump_frame_debug(void) {
    if (g_backbuffer == NULL) {
        return;
    }
    char path_buffer[1024];
    const char *path = dump_frame_path(path_buffer, sizeof path_buffer);
    if (path == NULL) {
        return;
    }
    @autoreleasepool {
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, g_backbuffer, (size_t)(g_pitch * g_height), NULL);
        CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst;
        CGImageRef image = CGImageCreate((size_t)g_width, (size_t)g_height, 8, 32, (size_t)g_pitch,
                                          colorSpace, bitmapInfo, provider, NULL, false, kCGRenderingIntentDefault);
        CFURLRef url = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)path, (CFIndex)strlen(path), false);
        CGImageDestinationRef dest = CGImageDestinationCreateWithURL(url, (CFStringRef)UTTypePNG.identifier, 1, NULL);
        if (dest != NULL) {
            CGImageDestinationAddImage(dest, image, NULL);
            CGImageDestinationFinalize(dest);
            CFRelease(dest);
        }
        CFRelease(url);
        CGImageRelease(image);
        CGDataProviderRelease(provider);
        CGColorSpaceRelease(colorSpace);
    }
}

/* dump_frame_debug와 같은 HMJE_POSIX_DUMP_FRAME 이스케이프 해치를 GPU 직접 렌더
 * persistent target(g_gpu_target, MTLStorageModePrivate)에도 적용한다 — CPU에서
 * 직접 못 읽으니 shared MTLBuffer로 한 번 blit-readback한 뒤 같은 PNG 인코딩을 쓴다.
 * g_gpu_target은 BGRA8Unorm이라 dump_frame_debug와 동일한 바이트 배치(B,G,R,X)이므로
 * 같은 kCGImageAlphaNoneSkipFirst 해석이 그대로 맞는다. */
static void dump_gpu_target_debug(void) {
    if (g_gpu_target == nil) {
        return;
    }
    char path_buffer[1024];
    const char *path = dump_frame_path(path_buffer, sizeof path_buffer);
    if (path == NULL) {
        return;
    }
    @autoreleasepool {
        NSUInteger width = g_gpu_target.width, height = g_gpu_target.height;
        NSUInteger rowBytes = width * 4;
        id<MTLBuffer> readback = [g_device newBufferWithLength:rowBytes * height
                                                         options:MTLResourceStorageModeShared];
        if (readback == nil) return;
        id<MTLCommandBuffer> commandBuffer = [g_queue commandBuffer];
        id<MTLBlitCommandEncoder> encoder = [commandBuffer blitCommandEncoder];
        [encoder copyFromTexture:g_gpu_target sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0, 0, 0)
                       sourceSize:MTLSizeMake(width, height, 1)
                         toBuffer:readback destinationOffset:0
              destinationBytesPerRow:rowBytes destinationBytesPerImage:rowBytes * height];
        [encoder endEncoding];
        [commandBuffer commit];
        [commandBuffer waitUntilCompleted];

        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, readback.contents, rowBytes * height, NULL);
        CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst;
        CGImageRef image = CGImageCreate(width, height, 8, 32, rowBytes,
                                          colorSpace, bitmapInfo, provider, NULL, false, kCGRenderingIntentDefault);
        CFURLRef url = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)path, (CFIndex)strlen(path), false);
        CGImageDestinationRef dest = CGImageDestinationCreateWithURL(url, (CFStringRef)UTTypePNG.identifier, 1, NULL);
        if (dest != NULL) {
            CGImageDestinationAddImage(dest, image, NULL);
            CGImageDestinationFinalize(dest);
            CFRelease(dest);
        }
        CFRelease(url);
        CGImageRelease(image);
        CGDataProviderRelease(provider);
        CGColorSpaceRelease(colorSpace);
    }
}

/* dump_gpu_target_debug의 배경(target 1) 버전 — 별도 env var로 구분한다.
 * 화면 target과 달리 배경은 매 프레임 present되지 않으므로(END_PRESENT가
 * drawable을 건드리지 않음) 기존 HMJE_POSIX_DUMP_FRAME 훅에 얹으면 "이번
 * 프레임에 배경이 실제로 GPU에 그렸는지" 구분이 안 된다 — 진단 앱이 두
 * target을 독립적으로 읽어 비교할 수 있도록 경로를 나눈다. */
static void dump_gpu_target_bg_debug(void) {
    const char *path = getenv("HMJE_POSIX_DUMP_GPU_BG_FRAME");
    if (path == NULL || g_gpu_target_bg == nil) {
        return;
    }
    @autoreleasepool {
        NSUInteger width = g_gpu_target_bg.width, height = g_gpu_target_bg.height;
        NSUInteger rowBytes = width * 4;
        id<MTLBuffer> readback = [g_device newBufferWithLength:rowBytes * height
                                                         options:MTLResourceStorageModeShared];
        if (readback == nil) return;
        id<MTLCommandBuffer> commandBuffer = [g_queue commandBuffer];
        id<MTLBlitCommandEncoder> encoder = [commandBuffer blitCommandEncoder];
        [encoder copyFromTexture:g_gpu_target_bg sourceSlice:0 sourceLevel:0 sourceOrigin:MTLOriginMake(0, 0, 0)
                       sourceSize:MTLSizeMake(width, height, 1)
                         toBuffer:readback destinationOffset:0
              destinationBytesPerRow:rowBytes destinationBytesPerImage:rowBytes * height];
        [encoder endEncoding];
        [commandBuffer commit];
        [commandBuffer waitUntilCompleted];

        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, readback.contents, rowBytes * height, NULL);
        CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst;
        CGImageRef image = CGImageCreate(width, height, 8, 32, rowBytes,
                                          colorSpace, bitmapInfo, provider, NULL, false, kCGRenderingIntentDefault);
        CFURLRef url = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)path, (CFIndex)strlen(path), false);
        CGImageDestinationRef dest = CGImageDestinationCreateWithURL(url, (CFStringRef)UTTypePNG.identifier, 1, NULL);
        if (dest != NULL) {
            CGImageDestinationAddImage(dest, image, NULL);
            CGImageDestinationFinalize(dest);
            CFRelease(dest);
        }
        CFRelease(url);
        CGImageRelease(image);
        CGDataProviderRelease(provider);
        CGColorSpaceRelease(colorSpace);
    }
}

/* Metal present: 백버퍼(staging MTLBuffer)를 drawable 텍스처로 blit → vsync 표시.
 * nextDrawable이 displaySync 페이싱을 겸한다(사용 가능한 drawable이 생길 때까지 최대
 * 1 vblank 대기). waitUntilCompleted는 마일스톤 1의 단순 동기화다 — 반환 직후 앱이
 * staging 버퍼를 다시 쓰기 시작하므로 GPU 복사가 끝나 있어야 한다(복사 자체는 수 밀리초
 * 미만, 명령 버퍼 경로가 생기는 마일스톤 3에서 더블 스테이징으로 바꾼다). */
static i64 present_metal(void) {
    @autoreleasepool {
        id<CAMetalDrawable> drawable = [g_layer nextDrawable];
        if (drawable == nil) {
            return 1; /* 일시적(창 최소화 등) — 프레임만 건너뛴다 */
        }
        id<MTLTexture> texture = [drawable texture];
        u64 copy_w = g_width, copy_h = g_height;
        if ((u64)[texture width] < copy_w) {
            copy_w = (u64)[texture width];
        }
        if ((u64)[texture height] < copy_h) {
            copy_h = (u64)[texture height];
        }
        if (copy_w == 0 || copy_h == 0) {
            return 1;
        }
        id<MTLCommandBuffer> command_buffer = [g_queue commandBuffer];
        id<MTLBlitCommandEncoder> encoder = [command_buffer blitCommandEncoder];
        [encoder copyFromBuffer:g_staging
                   sourceOffset:0
              sourceBytesPerRow:(NSUInteger)g_pitch
            sourceBytesPerImage:0
                     sourceSize:MTLSizeMake((NSUInteger)copy_w, (NSUInteger)copy_h, 1)
                      toTexture:texture
               destinationSlice:0
               destinationLevel:0
              destinationOrigin:MTLOriginMake(0, 0, 0)];
        [encoder endEncoding];
        [command_buffer presentDrawable:drawable];
        [command_buffer commit];
        [command_buffer waitUntilCompleted];
    }
    return 1;
}

i64 hmje_posix_framebuffer_present(i64 rects_address, i64 count) {
    ensure_window();
    (void)rects_address;
    if (count <= 0) {
        return 0;
    }
    if (g_device != nil) {
        present_metal();
    } else {
        @autoreleasepool {
            [g_view setNeedsDisplay:YES];
            [g_view displayIfNeeded];
        }
    }
    pump_events();
    dump_frame_debug();
    return 1;
}

i64 hmje_posix_input_poll(void) {
    ensure_window();
    g_runtime_polling = YES;
    pump_events();
    if (g_close_requested && !g_close_delivered) {
        g_close_delivered = YES;
        return (i64)(HMJE_INPUT_KIND_APP_CLOSE << HMJE_INPUT_KIND_SHIFT);
    }
    /* 기하 변경이 큐의 어떤 이벤트보다 먼저다 — 뒤 이벤트들의 좌표가 새
     * 표면 기준이기도 하고, 리사이즈 통지가 밀리면 그 프레임 전체가 옛
     * 크기로 그려진다. */
    i64 resize = surface_resize_event_if_needed();
    if (resize != 0) {
        return resize;
    }
    i64 event = key_ring_pop();
    if (event == 0) {
        maybe_selftest_resize();
        maybe_selftest_pointer();
        hmje_posix_text_input_selftest_tick();
        /* 합성 포인터가 이번 프레임에 이벤트를 넣었을 수 있다 — 앱이 다음
         * 프레임까지 기다리지 않게 바로 하나 꺼내 준다. */
        event = key_ring_pop();
    }
    return event;
}

i64 hmje_posix_input_poll2(i64 out_address, i64 out_length) {
    ensure_window();
    pump_events();
    return hmje_pointer_ring_pop(&g_pointer_samples, out_address, out_length);
}

/* Query the window environment without changing an explicit app/view override. */
i64 hmje_posix_system_theme(void) {
    @autoreleasepool {
        NSAppearance *appearance = g_window != nil ? g_window.effectiveAppearance : NSApp.effectiveAppearance;
        NSString *match = [appearance bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua, NSAppearanceNameDarkAqua]];
        return [match isEqualToString:NSAppearanceNameDarkAqua] ? 2 : 1;
    }
}
