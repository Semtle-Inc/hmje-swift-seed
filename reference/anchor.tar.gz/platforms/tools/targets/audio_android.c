/* Android AAudio microphone port for the HMJE audio-capture ABI.
 * The realtime callback only copies float32 PCM into a preallocated SPSC ring. */
#include <aaudio/AAudio.h>
#include <stdatomic.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

typedef long long i64;
typedef unsigned long long u64;

#define HMJE_AUDIO_ENOSYS (-38LL)
#define HMJE_AUDIO_EACCES (-13LL)
#define HMJE_AUDIO_EINVAL (-22LL)
#define HMJE_AUDIO_EBUSY (-16LL)
#define HMJE_AUDIO_HANDLE 1LL
#define HMJE_AUDIO_CONFIG_SIZE 64
#define HMJE_AUDIO_METADATA_SIZE 40
#define HMJE_AUDIO_FORMAT_F32_INTERLEAVED 1
#define HMJE_AUDIO_START 1
#define HMJE_AUDIO_STOP 2
#define HMJE_AUDIO_CLOSE 3
#define HMJE_AUDIO_PERMISSION_GRANTED 2
#define HMJE_AUDIO_RING_SLOTS 32
#define HMJE_AUDIO_MAX_FRAMES 4096
#define HMJE_AUDIO_MAX_CHANNELS 8

typedef struct {
    u64 timestamp_us;
    u64 sequence;
    u64 dropped;
    u64 frames;
    u64 channels;
    float samples[HMJE_AUDIO_MAX_FRAMES * HMJE_AUDIO_MAX_CHANNELS];
} hmje_android_audio_slot;

/* android_jni.c owns the Activity and runtime permission interaction. */
extern i64 hmje_android_audio_permission_bridge(i64 action);

static AAudioStream *g_audio_stream = NULL;
static hmje_android_audio_slot g_audio_ring[HMJE_AUDIO_RING_SLOTS];
static _Atomic u64 g_audio_read = 0;
static _Atomic u64 g_audio_write = 0;
static _Atomic u64 g_audio_sequence = 0;
static _Atomic u64 g_audio_dropped = 0;
static int32_t g_audio_channels = 0;
static int32_t g_audio_sample_rate = 0;

static u64 hmje_android_audio_now_us(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) return 0;
    return (u64)value.tv_sec * 1000000ULL + (u64)value.tv_nsec / 1000ULL;
}

static aaudio_data_callback_result_t hmje_android_audio_callback(
    AAudioStream *stream, void *context, void *audio_data, int32_t num_frames
) {
    (void)stream; (void)context;
    if (audio_data == NULL || num_frames <= 0 || g_audio_channels <= 0) return AAUDIO_CALLBACK_RESULT_CONTINUE;
    u64 frames = (u64)num_frames;
    if (frames > HMJE_AUDIO_MAX_FRAMES) {
        atomic_fetch_add_explicit(&g_audio_dropped, frames - HMJE_AUDIO_MAX_FRAMES, memory_order_relaxed);
        frames = HMJE_AUDIO_MAX_FRAMES;
    }
    u64 read = atomic_load_explicit(&g_audio_read, memory_order_acquire);
    u64 write = atomic_load_explicit(&g_audio_write, memory_order_relaxed);
    if (write - read >= HMJE_AUDIO_RING_SLOTS) {
        atomic_fetch_add_explicit(&g_audio_dropped, frames, memory_order_relaxed);
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }
    hmje_android_audio_slot *slot = &g_audio_ring[write % HMJE_AUDIO_RING_SLOTS];
    slot->timestamp_us = hmje_android_audio_now_us();
    slot->sequence = atomic_fetch_add_explicit(&g_audio_sequence, 1, memory_order_relaxed);
    slot->dropped = atomic_load_explicit(&g_audio_dropped, memory_order_relaxed);
    slot->frames = frames;
    slot->channels = (u64)g_audio_channels;
    memcpy(slot->samples, audio_data, (size_t)(frames * (u64)g_audio_channels * sizeof(float)));
    atomic_store_explicit(&g_audio_write, write + 1, memory_order_release);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

i64 hmje_android_audio_capture_permission(i64 action) {
    return hmje_android_audio_permission_bridge(action);
}

i64 hmje_android_audio_capture_open(i64 config_address, i64 config_length) {
    if (config_address == 0 || config_length < HMJE_AUDIO_CONFIG_SIZE) return HMJE_AUDIO_EINVAL;
    if (hmje_android_audio_permission_bridge(0) != HMJE_AUDIO_PERMISSION_GRANTED) return HMJE_AUDIO_EACCES;
    if (g_audio_stream != NULL) return HMJE_AUDIO_EBUSY;
    u64 *config = (u64 *)(uintptr_t)(u64)config_address;
    if (config[0] != 1 || (config[3] != 0 && config[3] != HMJE_AUDIO_FORMAT_F32_INTERLEAVED)) {
        return HMJE_AUDIO_EINVAL;
    }
    AAudioStreamBuilder *builder = NULL;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK || builder == NULL) return HMJE_AUDIO_ENOSYS;
    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_INPUT);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    if (config[1] > 0) AAudioStreamBuilder_setSampleRate(builder, (int32_t)config[1]);
    if (config[2] > 0) AAudioStreamBuilder_setChannelCount(builder, (int32_t)config[2]);
    AAudioStreamBuilder_setDataCallback(builder, hmje_android_audio_callback, NULL);
    aaudio_result_t opened = AAudioStreamBuilder_openStream(builder, &g_audio_stream);
    AAudioStreamBuilder_delete(builder);
    if (opened != AAUDIO_OK || g_audio_stream == NULL) {
        g_audio_stream = NULL;
        return HMJE_AUDIO_ENOSYS;
    }
    g_audio_sample_rate = AAudioStream_getSampleRate(g_audio_stream);
    g_audio_channels = AAudioStream_getChannelCount(g_audio_stream);
    if (g_audio_channels <= 0 || g_audio_channels > HMJE_AUDIO_MAX_CHANNELS || g_audio_sample_rate <= 0) {
        AAudioStream_close(g_audio_stream);
        g_audio_stream = NULL;
        return HMJE_AUDIO_ENOSYS;
    }
    atomic_store(&g_audio_read, 0);
    atomic_store(&g_audio_write, 0);
    atomic_store(&g_audio_sequence, 0);
    atomic_store(&g_audio_dropped, 0);
    config[0] = 1;
    config[1] = (u64)g_audio_sample_rate;
    config[2] = (u64)g_audio_channels;
    config[3] = HMJE_AUDIO_FORMAT_F32_INTERLEAVED;
    config[4] = (u64)AAudioStream_getFramesPerBurst(g_audio_stream);
    config[5] = config[6] = config[7] = 0;
    return HMJE_AUDIO_HANDLE;
}

i64 hmje_android_audio_capture_control(i64 handle, i64 command) {
    if (handle != HMJE_AUDIO_HANDLE || g_audio_stream == NULL) return -9;
    aaudio_result_t result;
    if (command == HMJE_AUDIO_START) result = AAudioStream_requestStart(g_audio_stream);
    else if (command == HMJE_AUDIO_STOP) result = AAudioStream_requestStop(g_audio_stream);
    else if (command == HMJE_AUDIO_CLOSE) {
        AAudioStream_requestStop(g_audio_stream);
        result = AAudioStream_close(g_audio_stream);
        g_audio_stream = NULL;
    } else return HMJE_AUDIO_EINVAL;
    return result == AAUDIO_OK ? 0 : HMJE_AUDIO_ENOSYS;
}

i64 hmje_android_audio_capture_read(i64 handle, i64 output_address, i64 output_capacity,
                                    i64 metadata_address, i64 metadata_length) {
    if (handle != HMJE_AUDIO_HANDLE || g_audio_stream == NULL) return -9;
    if (output_address == 0 || output_capacity < 0 || metadata_address == 0 ||
        metadata_length < HMJE_AUDIO_METADATA_SIZE) return HMJE_AUDIO_EINVAL;
    u64 read = atomic_load_explicit(&g_audio_read, memory_order_relaxed);
    u64 write = atomic_load_explicit(&g_audio_write, memory_order_acquire);
    if (read == write) return 0;
    hmje_android_audio_slot *slot = &g_audio_ring[read % HMJE_AUDIO_RING_SLOTS];
    u64 bytes = slot->frames * slot->channels * sizeof(float);
    if ((u64)output_capacity < bytes) return HMJE_AUDIO_EINVAL;
    memcpy((void *)(uintptr_t)(u64)output_address, slot->samples, (size_t)bytes);
    u64 *metadata = (u64 *)(uintptr_t)(u64)metadata_address;
    metadata[0] = slot->timestamp_us;
    metadata[1] = slot->sequence;
    metadata[2] = slot->dropped;
    metadata[3] = slot->frames;
    metadata[4] = 0;
    atomic_store_explicit(&g_audio_read, read + 1, memory_order_release);
    return (i64)bytes;
}
