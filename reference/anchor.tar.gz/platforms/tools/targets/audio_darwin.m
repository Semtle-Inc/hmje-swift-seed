/* Darwin AVFoundation microphone port for the HMJE audio-capture ABI.
 * It only owns permission, device lifetime and raw float32 PCM transfer. */
#import <AVFoundation/AVFoundation.h>
#import <TargetConditionals.h>
#include <stdatomic.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

typedef long long i64;
typedef unsigned long long u64;

#define HMJE_AUDIO_ENOSYS (-38LL)
#define HMJE_AUDIO_EACCES (-13LL)
#define HMJE_AUDIO_EINVAL (-22LL)
#define HMJE_AUDIO_EBUSY (-16LL)
#define HMJE_AUDIO_HANDLE 1LL
#define HMJE_AUDIO_CONFIG_SIZE 64
#define HMJE_AUDIO_METADATA_SIZE 40
#define HMJE_AUDIO_FORMAT_F32_INTERLEAVED 1
#define HMJE_AUDIO_START 1
#define HMJE_AUDIO_STOP 2
#define HMJE_AUDIO_CLOSE 3
#define HMJE_AUDIO_PERMISSION_QUERY 0
#define HMJE_AUDIO_PERMISSION_REQUEST 1
#define HMJE_AUDIO_PERMISSION_UNDETERMINED 0
#define HMJE_AUDIO_PERMISSION_DENIED 1
#define HMJE_AUDIO_PERMISSION_GRANTED 2
#define HMJE_AUDIO_PERMISSION_RESTRICTED 3
#define HMJE_AUDIO_RING_SLOTS 32
#define HMJE_AUDIO_MAX_FRAMES 4096
#define HMJE_AUDIO_MAX_CHANNELS 8

typedef struct {
    u64 timestamp_us;
    u64 sequence;
    u64 dropped;
    u64 frames;
    u64 channels;
    float samples[HMJE_AUDIO_MAX_FRAMES * HMJE_AUDIO_MAX_CHANNELS];
} hmje_audio_slot;

static AVAudioEngine *g_audio_engine = nil;
static AVAudioInputNode *g_audio_input = nil;
static AVAudioFormat *g_audio_format = nil;
static hmje_audio_slot g_audio_ring[HMJE_AUDIO_RING_SLOTS];
static _Atomic u64 g_audio_read = 0;
static _Atomic u64 g_audio_write = 0;
static _Atomic u64 g_audio_sequence = 0;
static _Atomic u64 g_audio_dropped = 0;
static BOOL g_audio_open = NO;
static BOOL g_audio_running = NO;

static u64 hmje_audio_now_us(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) return 0;
    return (u64)value.tv_sec * 1000000ULL + (u64)value.tv_nsec / 1000ULL;
}

static i64 hmje_darwin_permission_status(void) {
    AVAudioApplicationRecordPermission status = AVAudioApplication.sharedInstance.recordPermission;
    if (status == AVAudioApplicationRecordPermissionGranted) return HMJE_AUDIO_PERMISSION_GRANTED;
    if (status == AVAudioApplicationRecordPermissionDenied) return HMJE_AUDIO_PERMISSION_DENIED;
    return HMJE_AUDIO_PERMISSION_UNDETERMINED;
}

i64 hmje_posix_audio_capture_permission(i64 action) {
    i64 current = hmje_darwin_permission_status();
    if (action == HMJE_AUDIO_PERMISSION_QUERY || current != HMJE_AUDIO_PERMISSION_UNDETERMINED) {
        return current;
    }
    if (action != HMJE_AUDIO_PERMISSION_REQUEST) return HMJE_AUDIO_EINVAL;
    dispatch_semaphore_t completed = dispatch_semaphore_create(0);
    __block BOOL granted = NO;
    [AVAudioApplication requestRecordPermissionWithCompletionHandler:^(BOOL allowed) {
        granted = allowed;
        dispatch_semaphore_signal(completed);
    }];
    if ([NSThread isMainThread]) {
        /* Permission completion may be delivered through the main run loop. */
        return hmje_darwin_permission_status();
    }
    dispatch_semaphore_wait(completed, DISPATCH_TIME_FOREVER);
    return granted ? HMJE_AUDIO_PERMISSION_GRANTED : HMJE_AUDIO_PERMISSION_DENIED;
}

static void hmje_audio_accept_buffer(AVAudioPCMBuffer *buffer) {
    if (buffer == nil || buffer.floatChannelData == NULL) return;
    u64 frames = MIN((u64)buffer.frameLength, (u64)HMJE_AUDIO_MAX_FRAMES);
    u64 channels = MIN((u64)buffer.format.channelCount, (u64)HMJE_AUDIO_MAX_CHANNELS);
    if (frames == 0 || channels == 0) return;
    u64 read = atomic_load_explicit(&g_audio_read, memory_order_acquire);
    u64 write = atomic_load_explicit(&g_audio_write, memory_order_relaxed);
    if (write - read >= HMJE_AUDIO_RING_SLOTS) {
        atomic_fetch_add_explicit(&g_audio_dropped, frames, memory_order_relaxed);
        return;
    }
    hmje_audio_slot *slot = &g_audio_ring[write % HMJE_AUDIO_RING_SLOTS];
    slot->timestamp_us = hmje_audio_now_us();
    slot->sequence = atomic_fetch_add_explicit(&g_audio_sequence, 1, memory_order_relaxed);
    slot->dropped = atomic_load_explicit(&g_audio_dropped, memory_order_relaxed);
    slot->frames = frames;
    slot->channels = channels;
    for (u64 frame = 0; frame < frames; ++frame) {
        for (u64 channel = 0; channel < channels; ++channel) {
            slot->samples[frame * channels + channel] = buffer.floatChannelData[channel][frame];
        }
    }
    atomic_store_explicit(&g_audio_write, write + 1, memory_order_release);
}

i64 hmje_posix_audio_capture_open(i64 config_address, i64 config_length) {
    if (config_address == 0 || config_length < HMJE_AUDIO_CONFIG_SIZE) return HMJE_AUDIO_EINVAL;
    u64 *config = (u64 *)(uintptr_t)(u64)config_address;
    if (hmje_darwin_permission_status() != HMJE_AUDIO_PERMISSION_GRANTED) return HMJE_AUDIO_EACCES;
    if (g_audio_open) {
        return HMJE_AUDIO_EBUSY;
    }
    g_audio_open = YES;
    atomic_store(&g_audio_read, 0);
    atomic_store(&g_audio_write, 0);
    atomic_store(&g_audio_sequence, 0);
    atomic_store(&g_audio_dropped, 0);

#if TARGET_OS_IPHONE
    AVAudioSession *session = [AVAudioSession sharedInstance];
    NSError *session_error = nil;
    [session setCategory:AVAudioSessionCategoryRecord
             withOptions:AVAudioSessionCategoryOptionAllowBluetoothHFP
                   error:&session_error];
    if (session_error == nil) [session setActive:YES error:&session_error];
    if (session_error != nil) {
        g_audio_open = NO;
        return HMJE_AUDIO_ENOSYS;
    }
#endif
    g_audio_engine = [[AVAudioEngine alloc] init];
    g_audio_input = g_audio_engine.inputNode;
    AVAudioFormat *hardware = [g_audio_input inputFormatForBus:0];
    AVAudioChannelCount requested_channels = (AVAudioChannelCount)config[2];
    AVAudioChannelCount channels = MIN(hardware.channelCount, (AVAudioChannelCount)HMJE_AUDIO_MAX_CHANNELS);
    if (requested_channels > 0) channels = MIN(channels, requested_channels);
    if (hardware.sampleRate <= 0 || channels == 0) {
        g_audio_engine = nil; g_audio_input = nil; g_audio_open = NO;
        return HMJE_AUDIO_ENOSYS;
    }
    g_audio_format = [[AVAudioFormat alloc] initWithCommonFormat:AVAudioPCMFormatFloat32
                                                      sampleRate:hardware.sampleRate
                                                        channels:channels
                                                     interleaved:NO];
    [g_audio_input installTapOnBus:0 bufferSize:1024 format:g_audio_format
                            block:^(AVAudioPCMBuffer *buffer, AVAudioTime *when) {
        (void)when;
        hmje_audio_accept_buffer(buffer);
    }];
    config[0] = 1;
    config[1] = (u64)hardware.sampleRate;
    config[2] = (u64)channels;
    config[3] = HMJE_AUDIO_FORMAT_F32_INTERLEAVED;
    config[4] = 1024;
    config[5] = 0;
    config[6] = config[7] = 0;
    return HMJE_AUDIO_HANDLE;
}

i64 hmje_posix_audio_capture_control(i64 handle, i64 command) {
    if (handle != HMJE_AUDIO_HANDLE || !g_audio_open) return -9;
    if (command == HMJE_AUDIO_START) {
        if (g_audio_running) return 0;
        NSError *error = nil;
        if (![g_audio_engine startAndReturnError:&error]) return HMJE_AUDIO_ENOSYS;
        g_audio_running = YES;
        return 0;
    }
    if (command == HMJE_AUDIO_STOP || command == HMJE_AUDIO_CLOSE) {
        if (g_audio_running) [g_audio_engine stop];
        g_audio_running = NO;
        if (command == HMJE_AUDIO_CLOSE) {
            [g_audio_input removeTapOnBus:0];
            g_audio_input = nil; g_audio_format = nil; g_audio_engine = nil;
            g_audio_open = NO;
#if TARGET_OS_IPHONE
            [[AVAudioSession sharedInstance] setActive:NO error:nil];
#endif
        }
        return 0;
    }
    return HMJE_AUDIO_EINVAL;
}

i64 hmje_posix_audio_capture_read(i64 handle, i64 output_address, i64 output_capacity,
                                  i64 metadata_address, i64 metadata_length) {
    if (handle != HMJE_AUDIO_HANDLE || !g_audio_open) return -9;
    if (output_address == 0 || output_capacity < 0 || metadata_address == 0 ||
        metadata_length < HMJE_AUDIO_METADATA_SIZE) return HMJE_AUDIO_EINVAL;
    u64 read = atomic_load_explicit(&g_audio_read, memory_order_relaxed);
    u64 write = atomic_load_explicit(&g_audio_write, memory_order_acquire);
    if (read == write) return 0;
    hmje_audio_slot *slot = &g_audio_ring[read % HMJE_AUDIO_RING_SLOTS];
    u64 bytes = slot->frames * slot->channels * sizeof(float);
    if ((u64)output_capacity < bytes) {
        return HMJE_AUDIO_EINVAL;
    }
    memcpy((void *)(uintptr_t)(u64)output_address, slot->samples, (size_t)bytes);
    u64 *metadata = (u64 *)(uintptr_t)(u64)metadata_address;
    metadata[0] = slot->timestamp_us;
    metadata[1] = slot->sequence;
    metadata[2] = slot->dropped;
    metadata[3] = slot->frames;
    metadata[4] = 0;
    atomic_store_explicit(&g_audio_read, read + 1, memory_order_release);
    return (i64)bytes;
}
