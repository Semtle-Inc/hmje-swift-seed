#include <stdint.h>

typedef int64_t i64;

#define HMJE_WINDOWS_ENOSYS (-38LL)

i64 hmje_windows_framebuffer_info(i64 out_address, i64 out_length) {
    (void)out_address;
    (void)out_length;
    return HMJE_WINDOWS_ENOSYS;
}

i64 hmje_windows_framebuffer_blit(i64 buffer_address, i64 width, i64 height,
                                   i64 pitch, i64 x, i64 y) {
    (void)buffer_address;
    (void)width;
    (void)height;
    (void)pitch;
    (void)x;
    (void)y;
    return HMJE_WINDOWS_ENOSYS;
}

i64 hmje_windows_framebuffer_present(i64 rects_address, i64 count) {
    (void)rects_address;
    (void)count;
    return HMJE_WINDOWS_ENOSYS;
}

i64 hmje_windows_gpu_command(i64 kind, i64 request_address,
                             i64 request_length) {
    (void)kind;
    (void)request_address;
    (void)request_length;
    return HMJE_WINDOWS_ENOSYS;
}

i64 hmje_windows_input_poll(void) {
    return 0;
}

i64 hmje_windows_input_poll2(i64 out_address, i64 out_length) {
    (void)out_address;
    (void)out_length;
    return 0;
}

i64 hmje_windows_system_theme(void) { return 0; }
