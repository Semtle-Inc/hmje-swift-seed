#include "async_host_runtime.h"

#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

typedef struct HmjeAsyncEvent {
    uint64_t token;
    uint64_t value;
    int32_t status;
    int32_t ready;
    int32_t abandoned;
    void (*cleanup)(uint64_t);
    struct HmjeAsyncEvent *next;
} HmjeAsyncEvent;

typedef struct HmjeAsyncHandleState {
    void *handle;
    int32_t blocked;
    int32_t cancelled;
    uint32_t cancellation_shield_depth;
    int64_t failure;
    struct HmjeAsyncHandleState *next;
} HmjeAsyncHandleState;

typedef struct HmjeAsyncTimer {
    uint64_t deadline_milliseconds;
    uint64_t token;
    void *handle;
    int32_t kind;
    struct HmjeAsyncTimer *next;
} HmjeAsyncTimer;

typedef struct HmjeAsyncLimitWaiter {
    uint64_t token;
    struct HmjeAsyncLimitWaiter *next;
} HmjeAsyncLimitWaiter;

typedef struct HmjeAsyncLimit {
    uint64_t identifier;
    uint64_t capacity;
    uint64_t in_use;
    HmjeAsyncLimitWaiter *wait_head;
    HmjeAsyncLimitWaiter *wait_tail;
    struct HmjeAsyncLimit *next;
} HmjeAsyncLimit;

typedef struct HmjeAsyncPermit {
    uint64_t identifier;
    HmjeAsyncLimit *limit;
    struct HmjeAsyncPermit *next;
} HmjeAsyncPermit;

typedef struct HmjeAsyncChannelWaiter {
    uint64_t channel;
    uint64_t operation;
    uint64_t token;
    struct HmjeAsyncChannelWaiter *next;
} HmjeAsyncChannelWaiter;

static pthread_mutex_t hmje_async_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hmje_async_wake_condition = PTHREAD_COND_INITIALIZER;
static uint64_t hmje_async_next_token = 1;
static uint64_t hmje_async_pending_wakes = 0;
static uint64_t hmje_async_blocking_wait_count = 0;
/* Monotonic wake generation.  Every completion/cancel/failure bumps it; the
 * host poll loop records the value it last observed.  A host sleep (SYS_SLEEP_MS)
 * compares the two so a UI frame loop that ticks tasks once per frame can wake
 * as soon as a native completion lands instead of at the next frame. */
static uint64_t hmje_async_wake_generation = 0;
static uint64_t hmje_async_wake_generation_seen = 0;
/* Display refresh generation.  A platform that has a vsync source (iOS
 * CADisplayLink) bumps it once per refresh; hmje_async_sleep_until_wake_ms
 * reports it as bit 1 so the UI frame loop can start the next frame on the
 * refresh instead of on a free-running timer.  Platforms without a source
 * never bump it and the sleep behaves exactly as before. */
static uint64_t hmje_async_frame_generation = 0;
static uint64_t hmje_async_frame_generation_seen = 0;
static HmjeAsyncEvent *hmje_async_events = NULL;
static HmjeAsyncHandleState *hmje_async_handles = NULL;
static HmjeAsyncLimit *hmje_async_limits = NULL;
static HmjeAsyncPermit *hmje_async_permits = NULL;
static uint64_t hmje_async_next_limit_identifier = 1;
static uint64_t hmje_async_next_permit_identifier = 1;
static pthread_mutex_t hmje_async_channel_waiter_lock = PTHREAD_MUTEX_INITIALIZER;
static HmjeAsyncChannelWaiter *hmje_async_channel_waiters = NULL;

/* GUI hosts may replace these hooks with a native event wait.  The default
 * keeps the pthread condition path used by headless POSIX and tests. */
__attribute__((weak)) int32_t hmje_async_host_wait_ms(uint64_t timeout_ms) {
    (void)timeout_ms;
    return -1;
}

__attribute__((weak)) void hmje_async_host_wake(void) {
}

static void hmje_async_channel_lock(uint64_t channel) {
    uint64_t *lock = (uint64_t *)(uintptr_t)channel;
    while (__atomic_exchange_n(lock, UINT64_C(1), __ATOMIC_ACQUIRE) != 0) {
        sched_yield();
    }
}

static void hmje_async_channel_unlock(uint64_t channel) {
    uint64_t *lock = (uint64_t *)(uintptr_t)channel;
    __atomic_store_n(lock, UINT64_C(0), __ATOMIC_RELEASE);
}

static int hmje_async_channel_ready_locked(uint64_t channel, uint64_t operation) {
    uint8_t *base = (uint8_t *)(uintptr_t)channel;
    uint64_t capacity = *(uint64_t *)(void *)(base + 8);
    uint64_t stride = *(uint64_t *)(void *)(base + 24);
    uint64_t head = *(uint64_t *)(void *)(base + 32);
    uint64_t occupied = *(uint64_t *)(void *)(base + 48);
    uint64_t senders = *(uint64_t *)(void *)(base + 56);
    uint64_t receivers = *(uint64_t *)(void *)(base + 64);
    if (operation == UINT64_C(1)) {
        if (senders == 0) return 1;
        if (occupied == 0 || head >= capacity) return 0;
        uint64_t state = *(uint64_t *)(void *)(base + 152 + head * stride);
        return state == UINT64_C(3);
    }
    if (operation == UINT64_C(2)) {
        return receivers == 0 || occupied < capacity;
    }
    return 1;
}

void hmje_async_channel_wait(uint64_t channel, uint64_t operation, uint64_t token) {
    if (channel == 0 || (operation != 1 && operation != 2)) {
        hmje_async_complete_void(token, EINVAL);
        return;
    }
    HmjeAsyncChannelWaiter *waiter =
        (HmjeAsyncChannelWaiter *)malloc(sizeof(HmjeAsyncChannelWaiter));
    if (waiter == NULL) abort();
    waiter->channel = channel;
    waiter->operation = operation;
    waiter->token = token;

    hmje_async_channel_lock(channel);
    if (hmje_async_channel_ready_locked(channel, operation)) {
        hmje_async_channel_unlock(channel);
        free(waiter);
        hmje_async_complete_void(token, 0);
        return;
    }
    pthread_mutex_lock(&hmje_async_channel_waiter_lock);
    waiter->next = hmje_async_channel_waiters;
    hmje_async_channel_waiters = waiter;
    pthread_mutex_unlock(&hmje_async_channel_waiter_lock);
    hmje_async_channel_unlock(channel);
}

static void hmje_async_channel_wake(uint64_t channel, uint64_t operation, int destroy) {
    HmjeAsyncChannelWaiter *ready = NULL;
    pthread_mutex_lock(&hmje_async_channel_waiter_lock);
    HmjeAsyncChannelWaiter **link = &hmje_async_channel_waiters;
    while (*link != NULL) {
        HmjeAsyncChannelWaiter *waiter = *link;
        if (waiter->channel == channel &&
            (destroy || (waiter->operation & operation) != 0)) {
            *link = waiter->next;
            waiter->next = ready;
            ready = waiter;
            continue;
        }
        link = &waiter->next;
    }
    pthread_mutex_unlock(&hmje_async_channel_waiter_lock);
    while (ready != NULL) {
        HmjeAsyncChannelWaiter *waiter = ready;
        ready = waiter->next;
        hmje_async_complete_void(waiter->token, 0);
        free(waiter);
    }
}

void hmje_async_channel_notify(uint64_t channel, uint64_t operation) {
    if (channel != 0 && operation != 0) {
        hmje_async_channel_wake(channel, operation, 0);
    }
}

void hmje_async_channel_destroy(uint64_t channel) {
    if (channel != 0) {
        hmje_async_channel_wake(channel, UINT64_C(3), 1);
    }
}

/* Timer scheduling has its own lock so the worker never holds the completion
 * queue lock while publishing.  One detached worker serves all timers; an app
 * does not pay one pthread per sleep and an earlier insertion can wake and
 * reorder the scheduler.
 */
static pthread_mutex_t hmje_async_timer_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hmje_async_timer_condition = PTHREAD_COND_INITIALIZER;
static pthread_once_t hmje_async_timer_once = PTHREAD_ONCE_INIT;
static HmjeAsyncTimer *hmje_async_timers = NULL;
static int32_t hmje_async_timer_start_status = 0;
static uint64_t hmje_async_next_deadline_token = 1;

static uint64_t hmje_async_monotonic_milliseconds(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
        abort();
    }
    return ((uint64_t)now.tv_sec * UINT64_C(1000)) +
           ((uint64_t)now.tv_nsec / UINT64_C(1000000));
}

static struct timespec hmje_async_realtime_after(uint64_t milliseconds) {
    struct timespec deadline;
    if (clock_gettime(CLOCK_REALTIME, &deadline) != 0) {
        abort();
    }
    uint64_t seconds = milliseconds / UINT64_C(1000);
    uint64_t nanoseconds =
        (milliseconds % UINT64_C(1000)) * UINT64_C(1000000);
    deadline.tv_sec += (time_t)seconds;
    deadline.tv_nsec += (long)nanoseconds;
    if (deadline.tv_nsec >= 1000000000L) {
        deadline.tv_sec += 1;
        deadline.tv_nsec -= 1000000000L;
    }
    return deadline;
}

static void *hmje_async_timer_worker(void *unused) {
    (void)unused;
    for (;;) {
        pthread_mutex_lock(&hmje_async_timer_lock);
        while (hmje_async_timers == NULL) {
            pthread_cond_wait(
                &hmje_async_timer_condition, &hmje_async_timer_lock);
        }

        uint64_t now = hmje_async_monotonic_milliseconds();
        HmjeAsyncTimer *timer = hmje_async_timers;
        if (timer->deadline_milliseconds > now) {
            struct timespec deadline = hmje_async_realtime_after(
                timer->deadline_milliseconds - now);
            pthread_cond_timedwait(
                &hmje_async_timer_condition,
                &hmje_async_timer_lock,
                &deadline);
            pthread_mutex_unlock(&hmje_async_timer_lock);
            continue;
        }

        hmje_async_timers = timer->next;
        if (timer->kind == 1) {
            /* Remove the timer while holding the scheduler lock, but never
             * resume/cancel a coroutine under that lock.  Cancellation can
             * synchronously unwind a deadline scope, whose cleanup calls
             * hmje_async_deadline_cancel_for_handle and acquires this same
             * lock.  Keeping the lock here therefore deadlocks exactly when
             * a deadline expires.
             *
             * The timer is already detached from the list, so deadline_end
             * cannot free it while failure publication happens unlocked.
             */
            void *handle = timer->handle;
            pthread_mutex_unlock(&hmje_async_timer_lock);
            /* HMJE failure codes are platform-neutral; deadline is always -110. */
            hmje_async_handle_set_failure(handle, -110);
        } else {
            pthread_mutex_unlock(&hmje_async_timer_lock);
            hmje_async_complete_void(timer->token, 0);
        }
        free(timer);
    }
    return NULL;
}

static void hmje_async_timer_start_worker(void) {
    pthread_t worker;
    int error = pthread_create(&worker, NULL, hmje_async_timer_worker, NULL);
    if (error != 0) {
        hmje_async_timer_start_status = error;
        return;
    }
    pthread_detach(worker);
}

void hmje_async_timer_wait(uint64_t delay_milliseconds, uint64_t token) {
    HmjeAsyncTimer *timer = (HmjeAsyncTimer *)malloc(sizeof(HmjeAsyncTimer));
    if (timer == NULL) {
        hmje_async_complete_void(token, ENOMEM);
        return;
    }
    pthread_once(&hmje_async_timer_once, hmje_async_timer_start_worker);
    if (hmje_async_timer_start_status != 0) {
        int32_t status = hmje_async_timer_start_status;
        free(timer);
        hmje_async_complete_void(token, status);
        return;
    }

    uint64_t now = hmje_async_monotonic_milliseconds();
    timer->deadline_milliseconds =
        delay_milliseconds > UINT64_MAX - now
            ? UINT64_MAX
            : now + delay_milliseconds;
    timer->token = token;
    timer->handle = NULL;
    timer->kind = 0;
    timer->next = NULL;

    pthread_mutex_lock(&hmje_async_timer_lock);
    HmjeAsyncTimer **link = &hmje_async_timers;
    while (*link != NULL &&
           (*link)->deadline_milliseconds <= timer->deadline_milliseconds) {
        link = &(*link)->next;
    }
    int wake_worker = link == &hmje_async_timers;
    timer->next = *link;
    *link = timer;
    if (wake_worker) {
        pthread_cond_signal(&hmje_async_timer_condition);
    }
    pthread_mutex_unlock(&hmje_async_timer_lock);
}

uint64_t hmje_async_deadline_begin(uint64_t delay_milliseconds, void *handle) {
    if (handle == NULL) {
        abort();
    }
    HmjeAsyncTimer *timer = (HmjeAsyncTimer *)malloc(sizeof(HmjeAsyncTimer));
    if (timer == NULL) {
        abort();
    }
    pthread_once(&hmje_async_timer_once, hmje_async_timer_start_worker);
    if (hmje_async_timer_start_status != 0) {
        free(timer);
        abort();
    }
    uint64_t now = hmje_async_monotonic_milliseconds();
    timer->deadline_milliseconds = delay_milliseconds > UINT64_MAX - now
        ? UINT64_MAX
        : now + delay_milliseconds;
    timer->handle = handle;
    timer->kind = 1;
    timer->next = NULL;
    pthread_mutex_lock(&hmje_async_timer_lock);
    timer->token = hmje_async_next_deadline_token++;
    if (timer->token == 0) {
        timer->token = hmje_async_next_deadline_token++;
    }
    uint64_t deadline_token = timer->token;
    HmjeAsyncTimer **link = &hmje_async_timers;
    while (*link != NULL && (*link)->deadline_milliseconds <= timer->deadline_milliseconds) {
        link = &(*link)->next;
    }
    int wake_worker = link == &hmje_async_timers;
    timer->next = *link;
    *link = timer;
    if (wake_worker) {
        pthread_cond_signal(&hmje_async_timer_condition);
    }
    pthread_mutex_unlock(&hmje_async_timer_lock);
    return deadline_token;
}

void hmje_async_deadline_end(uint64_t deadline_token) {
    pthread_mutex_lock(&hmje_async_timer_lock);
    HmjeAsyncTimer **link = &hmje_async_timers;
    while (*link != NULL) {
        HmjeAsyncTimer *timer = *link;
        if (timer->kind == 1 && timer->token == deadline_token) {
            *link = timer->next;
            free(timer);
            pthread_cond_signal(&hmje_async_timer_condition);
            break;
        }
        link = &timer->next;
    }
    pthread_mutex_unlock(&hmje_async_timer_lock);
}

void hmje_async_deadline_cancel_for_handle(void *handle) {
    pthread_mutex_lock(&hmje_async_timer_lock);
    HmjeAsyncTimer **link = &hmje_async_timers;
    while (*link != NULL) {
        HmjeAsyncTimer *timer = *link;
        if (timer->kind == 1 && timer->handle == handle) {
            *link = timer->next;
            free(timer);
            continue;
        }
        link = &timer->next;
    }
    pthread_cond_signal(&hmje_async_timer_condition);
    pthread_mutex_unlock(&hmje_async_timer_lock);
}

static HmjeAsyncEvent *hmje_async_find_event_locked(uint64_t token) {
    HmjeAsyncEvent *event = hmje_async_events;
    while (event != NULL && event->token != token) {
        event = event->next;
    }
    return event;
}

static HmjeAsyncHandleState *hmje_async_find_handle_locked(void *handle) {
    HmjeAsyncHandleState *state = hmje_async_handles;
    while (state != NULL && state->handle != handle) {
        state = state->next;
    }
    return state;
}

static HmjeAsyncLimit *hmje_async_find_limit_locked(uint64_t identifier) {
    HmjeAsyncLimit *limit = hmje_async_limits;
    while (limit != NULL && limit->identifier != identifier) {
        limit = limit->next;
    }
    return limit;
}

static uint64_t hmje_async_next_nonzero_identifier(uint64_t *next) {
    uint64_t identifier = (*next)++;
    if (identifier == 0) {
        identifier = (*next)++;
    }
    return identifier;
}

static HmjeAsyncPermit *hmje_async_permit_create_locked(HmjeAsyncLimit *limit) {
    HmjeAsyncPermit *permit = (HmjeAsyncPermit *)malloc(sizeof(HmjeAsyncPermit));
    if (permit == NULL) {
        return NULL;
    }
    permit->identifier = hmje_async_next_nonzero_identifier(
        &hmje_async_next_permit_identifier);
    permit->limit = limit;
    permit->next = hmje_async_permits;
    hmje_async_permits = permit;
    limit->in_use += 1;
    return permit;
}

static void hmje_async_permit_cleanup(uint64_t permit) {
    hmje_async_permit_release(permit);
}

uint64_t hmje_async_limit_create(uint64_t capacity) {
    if (capacity == 0) {
        return 0;
    }
    HmjeAsyncLimit *limit = (HmjeAsyncLimit *)calloc(1, sizeof(HmjeAsyncLimit));
    if (limit == NULL) {
        return 0;
    }
    pthread_mutex_lock(&hmje_async_lock);
    limit->identifier = hmje_async_next_nonzero_identifier(
        &hmje_async_next_limit_identifier);
    limit->capacity = capacity;
    limit->next = hmje_async_limits;
    hmje_async_limits = limit;
    pthread_mutex_unlock(&hmje_async_lock);
    return limit->identifier;
}

void hmje_async_limit_acquire(uint64_t identifier, uint64_t token) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncLimit *limit = hmje_async_find_limit_locked(identifier);
    if (limit == NULL) {
        pthread_mutex_unlock(&hmje_async_lock);
        hmje_async_complete_void(token, EINVAL);
        return;
    }
    if (limit->in_use < limit->capacity) {
        HmjeAsyncPermit *permit = hmje_async_permit_create_locked(limit);
        pthread_mutex_unlock(&hmje_async_lock);
        if (permit == NULL) {
            hmje_async_complete_void(token, ENOMEM);
            return;
        }
        hmje_async_complete_owned_u64(
            token, 0, permit->identifier, hmje_async_permit_cleanup);
        return;
    }
    HmjeAsyncLimitWaiter *waiter =
        (HmjeAsyncLimitWaiter *)malloc(sizeof(HmjeAsyncLimitWaiter));
    if (waiter == NULL) {
        pthread_mutex_unlock(&hmje_async_lock);
        hmje_async_complete_void(token, ENOMEM);
        return;
    }
    waiter->token = token;
    waiter->next = NULL;
    if (limit->wait_tail == NULL) {
        limit->wait_head = waiter;
    } else {
        limit->wait_tail->next = waiter;
    }
    limit->wait_tail = waiter;
    pthread_mutex_unlock(&hmje_async_lock);
}

void hmje_async_permit_release(uint64_t identifier) {
    uint64_t grant_token = 0;
    uint64_t grant_identifier = 0;
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncPermit **permit_link = &hmje_async_permits;
    while (*permit_link != NULL && (*permit_link)->identifier != identifier) {
        permit_link = &(*permit_link)->next;
    }
    HmjeAsyncPermit *permit = *permit_link;
    if (permit == NULL || permit->limit == NULL || permit->limit->in_use == 0) {
        pthread_mutex_unlock(&hmje_async_lock);
        abort();
    }
    HmjeAsyncLimit *limit = permit->limit;
    HmjeAsyncLimitWaiter *waiter = limit->wait_head;
    if (waiter != NULL) {
        limit->wait_head = waiter->next;
        if (limit->wait_head == NULL) {
            limit->wait_tail = NULL;
        }
        permit->identifier = hmje_async_next_nonzero_identifier(
            &hmje_async_next_permit_identifier);
        grant_token = waiter->token;
        grant_identifier = permit->identifier;
        free(waiter);
    } else {
        *permit_link = permit->next;
        limit->in_use -= 1;
        free(permit);
    }
    pthread_mutex_unlock(&hmje_async_lock);
    if (grant_token != 0) {
        hmje_async_complete_owned_u64(
            grant_token,
            0,
            grant_identifier,
            hmje_async_permit_cleanup);
    }
}

int64_t hmje_async_limit_destroy(uint64_t identifier) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncLimit **link = &hmje_async_limits;
    while (*link != NULL && (*link)->identifier != identifier) {
        link = &(*link)->next;
    }
    HmjeAsyncLimit *limit = *link;
    if (limit == NULL) {
        pthread_mutex_unlock(&hmje_async_lock);
        return -EINVAL;
    }
    if (limit->in_use != 0 || limit->wait_head != NULL) {
        pthread_mutex_unlock(&hmje_async_lock);
        return -EBUSY;
    }
    *link = limit->next;
    pthread_mutex_unlock(&hmje_async_lock);
    free(limit);
    return 0;
}

uint64_t hmje_async_event_create(void) {
    HmjeAsyncEvent *event = (HmjeAsyncEvent *)calloc(1, sizeof(HmjeAsyncEvent));
    if (event == NULL) {
        abort();
    }
    pthread_mutex_lock(&hmje_async_lock);
    event->token = hmje_async_next_token++;
    if (event->token == 0) {
        event->token = hmje_async_next_token++;
    }
    event->next = hmje_async_events;
    hmje_async_events = event;
    pthread_mutex_unlock(&hmje_async_lock);
    return event->token;
}

void hmje_async_complete_owned_u64(
    uint64_t token,
    int32_t status,
    uint64_t value,
    void (*cleanup)(uint64_t)) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncEvent **link = &hmje_async_events;
    while (*link != NULL && (*link)->token != token) {
        link = &(*link)->next;
    }
    HmjeAsyncEvent *event = *link;
    if (event == NULL || event->ready) {
        pthread_mutex_unlock(&hmje_async_lock);
        abort();
    }
    if (event->abandoned) {
        *link = event->next;
        pthread_mutex_unlock(&hmje_async_lock);
        if (cleanup != NULL) {
            cleanup(value);
        }
        free(event);
        return;
    }
    event->value = value;
    event->status = status;
    event->cleanup = cleanup;
    event->ready = 1;
    hmje_async_pending_wakes += 1;
    hmje_async_wake_generation += 1;
    pthread_cond_signal(&hmje_async_wake_condition);
    pthread_mutex_unlock(&hmje_async_lock);
    hmje_async_host_wake();
}

void hmje_async_complete_u64(uint64_t token, int32_t status, uint64_t value) {
    hmje_async_complete_owned_u64(token, status, value, NULL);
}

void hmje_async_complete_void(uint64_t token, int32_t status) {
    hmje_async_complete_u64(token, status, 0);
}

int32_t hmje_async_event_is_ready(uint64_t token) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncEvent *event = hmje_async_find_event_locked(token);
    int32_t ready = event != NULL && event->ready;
    pthread_mutex_unlock(&hmje_async_lock);
    return ready;
}

int32_t hmje_async_event_take_u64(uint64_t token, uint64_t *value, int32_t *status) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncEvent **link = &hmje_async_events;
    while (*link != NULL && (*link)->token != token) {
        link = &(*link)->next;
    }
    HmjeAsyncEvent *event = *link;
    if (event == NULL || !event->ready) {
        pthread_mutex_unlock(&hmje_async_lock);
        return 0;
    }
    *link = event->next;
    if (value != NULL) {
        *value = event->value;
    }
    if (status != NULL) {
        *status = event->status;
    }
    if (hmje_async_pending_wakes > 0) {
        hmje_async_pending_wakes -= 1;
    }
    pthread_mutex_unlock(&hmje_async_lock);
    free(event);
    return 1;
}

int32_t hmje_async_event_abandon(uint64_t token) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncEvent **link = &hmje_async_events;
    while (*link != NULL && (*link)->token != token) {
        link = &(*link)->next;
    }
    HmjeAsyncEvent *event = *link;
    if (event == NULL) {
        pthread_mutex_unlock(&hmje_async_lock);
        return 0;
    }
    if (event->ready) {
        *link = event->next;
        if (hmje_async_pending_wakes > 0) {
            hmje_async_pending_wakes -= 1;
        }
        pthread_mutex_unlock(&hmje_async_lock);
        if (event->cleanup != NULL) {
            event->cleanup(event->value);
        }
        free(event);
        return 1;
    }
    event->abandoned = 1;
    pthread_mutex_unlock(&hmje_async_lock);
    return 1;
}

int32_t hmje_async_event_is_abandoned(uint64_t token) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncEvent *event = hmje_async_find_event_locked(token);
    int32_t abandoned = event != NULL && event->abandoned;
    pthread_mutex_unlock(&hmje_async_lock);
    return abandoned;
}

void hmje_async_handle_set_blocked(void *handle, int32_t blocked) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    if (state == NULL) {
        state = (HmjeAsyncHandleState *)malloc(sizeof(HmjeAsyncHandleState));
        if (state == NULL) {
            pthread_mutex_unlock(&hmje_async_lock);
            abort();
        }
        state->handle = handle;
        state->cancelled = 0;
        state->cancellation_shield_depth = 0;
        state->failure = 0;
        state->next = hmje_async_handles;
        hmje_async_handles = state;
    }
    state->blocked = blocked != 0;
    pthread_mutex_unlock(&hmje_async_lock);
}

int32_t hmje_async_handle_is_blocked(void *handle) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    int32_t blocked = state != NULL && state->blocked;
    pthread_mutex_unlock(&hmje_async_lock);
    return blocked;
}

void hmje_async_handle_request_cancel(void *handle) {
    if (handle == NULL) {
        return;
    }
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    if (state == NULL) {
        state = (HmjeAsyncHandleState *)calloc(1, sizeof(HmjeAsyncHandleState));
        if (state == NULL) {
            pthread_mutex_unlock(&hmje_async_lock);
            abort();
        }
        state->handle = handle;
        state->next = hmje_async_handles;
        hmje_async_handles = state;
    }
    if (!state->cancelled) {
        state->cancelled = 1;
        hmje_async_pending_wakes += 1;
    hmje_async_wake_generation += 1;
        pthread_cond_signal(&hmje_async_wake_condition);
    }
    pthread_mutex_unlock(&hmje_async_lock);
    hmje_async_host_wake();
}

void hmje_async_handle_request_cancel_address(uint64_t handle_address) {
    hmje_async_handle_request_cancel((void *)(uintptr_t)handle_address);
}

int32_t hmje_async_handle_is_cancelled(void *handle) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    int32_t cancelled = state != NULL && state->cancelled &&
        state->cancellation_shield_depth == 0;
    pthread_mutex_unlock(&hmje_async_lock);
    return cancelled;
}

void hmje_async_cancellation_shield_enter(void *handle) {
    if (handle == NULL) abort();
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    if (state == NULL) {
        state = (HmjeAsyncHandleState *)calloc(1, sizeof(HmjeAsyncHandleState));
        if (state == NULL) {
            pthread_mutex_unlock(&hmje_async_lock);
            abort();
        }
        state->handle = handle;
        state->next = hmje_async_handles;
        hmje_async_handles = state;
    }
    if (state->cancellation_shield_depth == UINT32_MAX) {
        pthread_mutex_unlock(&hmje_async_lock);
        abort();
    }
    state->cancellation_shield_depth += 1;
    pthread_mutex_unlock(&hmje_async_lock);
}

void hmje_async_cancellation_shield_exit(void *handle) {
    if (handle == NULL) abort();
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    if (state == NULL || state->cancellation_shield_depth == 0) {
        pthread_mutex_unlock(&hmje_async_lock);
        abort();
    }
    state->cancellation_shield_depth -= 1;
    if (state->cancellation_shield_depth == 0 && state->cancelled) {
        hmje_async_pending_wakes += 1;
    hmje_async_wake_generation += 1;
        pthread_cond_signal(&hmje_async_wake_condition);
    }
    pthread_mutex_unlock(&hmje_async_lock);
    hmje_async_host_wake();
}

void hmje_async_handle_set_failure(void *handle, int64_t status) {
    if (handle == NULL || status == 0) {
        return;
    }
    if (status > 0) {
        status = -status;
    }
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    if (state == NULL) {
        state = (HmjeAsyncHandleState *)calloc(1, sizeof(HmjeAsyncHandleState));
        if (state == NULL) {
            pthread_mutex_unlock(&hmje_async_lock);
            abort();
        }
        state->handle = handle;
        state->next = hmje_async_handles;
        hmje_async_handles = state;
    }
    if (state->failure == 0) {
        state->failure = status;
        hmje_async_pending_wakes += 1;
    hmje_async_wake_generation += 1;
        pthread_cond_signal(&hmje_async_wake_condition);
    }
    pthread_mutex_unlock(&hmje_async_lock);
    hmje_async_host_wake();
}

int64_t hmje_async_handle_failure(void *handle) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    int64_t failure = state != NULL ? state->failure : 0;
    pthread_mutex_unlock(&hmje_async_lock);
    return failure;
}

int64_t hmje_async_handle_take_failure(void *handle) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState *state = hmje_async_find_handle_locked(handle);
    int64_t failure = state != NULL ? state->failure : 0;
    if (state != NULL) {
        state->failure = 0;
    }
    pthread_mutex_unlock(&hmje_async_lock);
    return failure;
}

void hmje_async_handle_forget(void *handle) {
    pthread_mutex_lock(&hmje_async_lock);
    HmjeAsyncHandleState **link = &hmje_async_handles;
    while (*link != NULL && (*link)->handle != handle) {
        link = &(*link)->next;
    }
    HmjeAsyncHandleState *state = *link;
    if (state != NULL) {
        *link = state->next;
    }
    pthread_mutex_unlock(&hmje_async_lock);
    free(state);
}

typedef void (*HmjeCoroutineEntry)(void *frame);

typedef struct HmjeCoroutineFrameHeader {
    HmjeCoroutineEntry resume;
    HmjeCoroutineEntry destroy;
} HmjeCoroutineFrameHeader;

int32_t hmje_async_handle_poll_once(void *handle) {
    if (handle == NULL) {
        abort();
    }
    HmjeCoroutineFrameHeader *frame = (HmjeCoroutineFrameHeader *)handle;
    if (frame->resume == NULL) {
        return 1;
    }
    frame->resume(handle);
    return frame->resume == NULL;
}

void hmje_async_handle_destroy(void *handle) {
    if (handle == NULL) {
        return;
    }
    HmjeCoroutineFrameHeader *frame = (HmjeCoroutineFrameHeader *)handle;
    HmjeCoroutineEntry destroy = frame->destroy;
    hmje_async_handle_forget(handle);
    if (destroy != NULL) {
        destroy(handle);
    }
}

typedef void (*HmjeAsyncClosureRelease)(uint64_t context);

typedef struct HmjeAsyncUnstructuredNode {
    void *handle;
    uint64_t closure_context;
    HmjeAsyncClosureRelease closure_release;
    struct HmjeAsyncUnstructuredNode *next;
} HmjeAsyncUnstructuredNode;

static HmjeAsyncUnstructuredNode *hmje_async_unstructured_head = NULL;
static HmjeAsyncUnstructuredNode *hmje_async_unstructured_tail = NULL;
static int32_t hmje_async_unstructured_atexit_registered = 0;

static void hmje_async_unstructured_release_node(HmjeAsyncUnstructuredNode *node) {
    hmje_async_handle_destroy(node->handle);
    if (node->closure_release != NULL && node->closure_context != 0) {
        node->closure_release(node->closure_context);
    }
    free(node);
}

static void hmje_async_unstructured_shutdown(void) {
    HmjeAsyncUnstructuredNode *node = hmje_async_unstructured_head;
    hmje_async_unstructured_head = NULL;
    hmje_async_unstructured_tail = NULL;
    while (node != NULL) {
        HmjeAsyncUnstructuredNode *next = node->next;
        hmje_async_handle_request_cancel(node->handle);
        hmje_async_unstructured_release_node(node);
        node = next;
    }
}

void hmje_async_unstructured_add(
    void *handle, uint64_t closure_context, uint64_t closure_release_address) {
    if (handle == NULL) {
        abort();
    }
    HmjeAsyncUnstructuredNode *node =
        (HmjeAsyncUnstructuredNode *)calloc(1, sizeof(*node));
    if (node == NULL) {
        abort();
    }
    node->handle = handle;
    node->closure_context = closure_context;
    node->closure_release =
        (HmjeAsyncClosureRelease)(uintptr_t)closure_release_address;
    /* `비동기 작업` has Task-like eager-start semantics.  Merely enqueueing
     * the initial-suspend handle means a root coroutine can block on an
     * unrelated long wait before the new task registers its first event; if
     * the root then finishes, the task never starts at all.  Run exactly to
     * the first suspension before publishing it to the executor queue. */
    if (hmje_async_handle_poll_once(handle)) {
        hmje_async_unstructured_release_node(node);
        return;
    }
    if (!hmje_async_unstructured_atexit_registered) {
        if (atexit(hmje_async_unstructured_shutdown) != 0) {
            abort();
        }
        hmje_async_unstructured_atexit_registered = 1;
    }
    if (hmje_async_unstructured_tail == NULL) {
        hmje_async_unstructured_head = node;
    } else {
        hmje_async_unstructured_tail->next = node;
    }
    hmje_async_unstructured_tail = node;
}

int32_t hmje_async_unstructured_poll(void) {
    int32_t all_blocked = 1;
    pthread_mutex_lock(&hmje_async_lock);
    hmje_async_wake_generation_seen = hmje_async_wake_generation;
    pthread_mutex_unlock(&hmje_async_lock);
    HmjeAsyncUnstructuredNode **link = &hmje_async_unstructured_head;
    while (*link != NULL) {
        HmjeAsyncUnstructuredNode *node = *link;
        if (!hmje_async_handle_poll_once(node->handle)) {
            if (!hmje_async_handle_is_blocked(node->handle)) {
                all_blocked = 0;
            }
            link = &node->next;
            continue;
        }
        *link = node->next;
        hmje_async_unstructured_release_node(node);
    }
    hmje_async_unstructured_tail = NULL;
    for (HmjeAsyncUnstructuredNode *node = hmje_async_unstructured_head;
         node != NULL; node = node->next) {
        hmje_async_unstructured_tail = node;
    }
    if (hmje_async_unstructured_head == NULL) {
        return 2;
    }
    return all_blocked ? 1 : 0;
}

void hmje_async_unstructured_tick(void) {
    (void)hmje_async_unstructured_poll();
}

typedef struct HmjeAsyncGroupNode {
    void *handle;
    struct HmjeAsyncGroupNode *next;
} HmjeAsyncGroupNode;

typedef struct HmjeAsyncGroup {
    HmjeAsyncGroupNode *head;
    HmjeAsyncGroupNode *tail;
    int64_t first_failure;
    int32_t any_cancelled;
} HmjeAsyncGroup;

void *hmje_async_group_create(void) {
    HmjeAsyncGroup *group = (HmjeAsyncGroup *)calloc(1, sizeof(*group));
    if (group == NULL) {
        abort();
    }
    return group;
}

void hmje_async_group_add(void *opaque_group, void *handle) {
    HmjeAsyncGroup *group = (HmjeAsyncGroup *)opaque_group;
    if (group == NULL || handle == NULL) {
        abort();
    }
    HmjeAsyncGroupNode *node = (HmjeAsyncGroupNode *)malloc(sizeof(*node));
    if (node == NULL) {
        abort();
    }
    node->handle = handle;
    node->next = NULL;
    if (group->tail == NULL) {
        group->head = node;
    } else {
        group->tail->next = node;
    }
    group->tail = node;
}

int32_t hmje_async_group_poll(void *opaque_group, void *parent_handle) {
    HmjeAsyncGroup *group = (HmjeAsyncGroup *)opaque_group;
    if (group == NULL) {
        abort();
    }
    int32_t parent_cancelled = parent_handle != NULL && hmje_async_handle_is_cancelled(parent_handle);
    int32_t parent_failed = parent_handle != NULL && hmje_async_handle_failure(parent_handle) != 0;
    for (HmjeAsyncGroupNode *node = group->head; node != NULL; node = node->next) {
        if (parent_cancelled || parent_failed || group->first_failure != 0) {
            hmje_async_handle_request_cancel(node->handle);
        }
        if (hmje_async_handle_failure(node->handle) != 0) {
            hmje_async_handle_request_cancel(node->handle);
        }
    }
    int32_t all_blocked = 1;
    HmjeAsyncGroupNode **link = &group->head;
    while (*link != NULL) {
        HmjeAsyncGroupNode *node = *link;
        if (!hmje_async_handle_poll_once(node->handle)) {
            if (!hmje_async_handle_is_blocked(node->handle)) {
                all_blocked = 0;
            }
            link = &node->next;
            continue;
        }
        int64_t failure = hmje_async_handle_failure(node->handle);
        if (group->first_failure == 0 && failure != 0) {
            group->first_failure = failure;
        }
        if (hmje_async_handle_is_cancelled(node->handle)) {
            group->any_cancelled = 1;
        }
        *link = node->next;
        hmje_async_handle_destroy(node->handle);
        free(node);
    }
    group->tail = NULL;
    for (HmjeAsyncGroupNode *node = group->head; node != NULL; node = node->next) {
        group->tail = node;
    }
    if (group->head != NULL && group->first_failure != 0) {
        for (HmjeAsyncGroupNode *node = group->head; node != NULL; node = node->next) {
            hmje_async_handle_request_cancel(node->handle);
        }
    }
    if (group->head == NULL) {
        return 2;
    }
    return all_blocked ? 1 : 0;
}

void hmje_async_group_finish(void *opaque_group, void *parent_handle) {
    HmjeAsyncGroup *group = (HmjeAsyncGroup *)opaque_group;
    if (group == NULL) {
        abort();
    }
    int64_t first_failure = group->first_failure;
    int32_t any_cancelled = group->any_cancelled;
    HmjeAsyncGroupNode *node = group->head;
    while (node != NULL) {
        HmjeAsyncGroupNode *next = node->next;
        int64_t failure = hmje_async_handle_failure(node->handle);
        if (first_failure == 0 && failure != 0) {
            first_failure = failure;
        }
        if (hmje_async_handle_is_cancelled(node->handle)) {
            any_cancelled = 1;
        }
        hmje_async_handle_destroy(node->handle);
        free(node);
        node = next;
    }
    free(group);
    if (parent_handle != NULL) {
        if (first_failure != 0) {
            hmje_async_handle_set_failure(parent_handle, first_failure);
        } else if (any_cancelled) {
            hmje_async_handle_request_cancel(parent_handle);
        }
    }
}

/* Diagnostics only: HMJE_ASYNC_DEBUG_WAKE_QUANTUM_MS=16 makes the root executor
 * resume completions only on a fixed quantum, reproducing a frame-locked UI
 * executor (one task tick per display frame) inside a CLI benchmark. */
static pthread_once_t hmje_async_debug_quantum_once = PTHREAD_ONCE_INIT;
static uint64_t hmje_async_debug_quantum_ms = 0;
static void hmje_async_debug_quantum_initialize(void) {
    const char *value = getenv("HMJE_ASYNC_DEBUG_WAKE_QUANTUM_MS");
    if (value != NULL) {
        hmje_async_debug_quantum_ms = (uint64_t)strtoull(value, NULL, 10);
    }
}

void hmje_async_wait_for_wake(void) {
    pthread_mutex_lock(&hmje_async_lock);
    while (hmje_async_pending_wakes == 0) {
        hmje_async_blocking_wait_count += 1;
        pthread_cond_wait(&hmje_async_wake_condition, &hmje_async_lock);
    }
    hmje_async_pending_wakes -= 1;
    pthread_mutex_unlock(&hmje_async_lock);
    pthread_once(&hmje_async_debug_quantum_once, hmje_async_debug_quantum_initialize);
    if (hmje_async_debug_quantum_ms != 0) {
        uint64_t now = hmje_async_monotonic_milliseconds();
        uint64_t next = (now / hmje_async_debug_quantum_ms + 1) * hmje_async_debug_quantum_ms;
        struct timespec request;
        request.tv_sec = (time_t)((next - now) / UINT64_C(1000));
        request.tv_nsec = (long)(((next - now) % UINT64_C(1000)) * UINT64_C(1000000));
        while (nanosleep(&request, &request) != 0) {
        }
    }
}

void hmje_async_notify_frame(void) {
    pthread_mutex_lock(&hmje_async_lock);
    hmje_async_frame_generation += 1;
    pthread_cond_broadcast(&hmje_async_wake_condition);
    pthread_mutex_unlock(&hmje_async_lock);
    hmje_async_host_wake();
}

static int32_t hmje_async_sleep_flags_locked(void) {
    int32_t flags = 0;
    if (hmje_async_wake_generation != hmje_async_wake_generation_seen) {
        hmje_async_wake_generation_seen = hmje_async_wake_generation;
        flags |= 1;
    }
    if (hmje_async_frame_generation != hmje_async_frame_generation_seen) {
        hmje_async_frame_generation_seen = hmje_async_frame_generation;
        flags |= 2;
    }
    return flags;
}

/* Returns 0 on timeout, bit 0 for an async completion, bit 1 for a display
 * refresh, bit 2 for native input/lifecycle activity, and bit 3 when the host
 * provides an event-aware native wait. */
int32_t hmje_async_sleep_until_wake_ms(uint64_t timeout_ms) {
    pthread_mutex_lock(&hmje_async_lock);
    {
        int32_t pending = hmje_async_sleep_flags_locked();
        if (pending != 0) {
            pthread_mutex_unlock(&hmje_async_lock);
            return pending;
        }
    }
    if (timeout_ms == 0) {
        pthread_mutex_unlock(&hmje_async_lock);
        return 0;
    }
    /* AppKit and similar UI loops must wait on their native event source so a
     * click/key/reopen wakes a truly idle app.  Async completions call the
     * paired wake hook above, closing the check-before-wait race with a queued
     * application event.  Bit 2 is reserved for native input/lifecycle wake. */
    pthread_mutex_unlock(&hmje_async_lock);
    int32_t host_wake = hmje_async_host_wait_ms(timeout_ms);
    if (host_wake >= 0) {
        pthread_mutex_lock(&hmje_async_lock);
        int32_t flags = hmje_async_sleep_flags_locked();
        pthread_mutex_unlock(&hmje_async_lock);
        /* Bit 3 advertises that this process has an event-aware native wait;
         * the shared UI loop must not enter long idle sleeps on hosts whose
         * input queue cannot wake the pthread condition fallback. */
        return flags | host_wake | 8;
    }
    pthread_mutex_lock(&hmje_async_lock);
    struct timespec deadline = hmje_async_realtime_after(timeout_ms);
    while (hmje_async_wake_generation == hmje_async_wake_generation_seen &&
           hmje_async_frame_generation == hmje_async_frame_generation_seen) {
        int status = pthread_cond_timedwait(
            &hmje_async_wake_condition, &hmje_async_lock, &deadline);
        if (status == ETIMEDOUT) {
            break;
        }
    }
    int32_t woke = hmje_async_sleep_flags_locked();
    pthread_mutex_unlock(&hmje_async_lock);
    return woke;
}

uint64_t hmje_async_debug_blocking_wait_count(void) {
    pthread_mutex_lock(&hmje_async_lock);
    uint64_t count = hmje_async_blocking_wait_count;
    pthread_mutex_unlock(&hmje_async_lock);
    return count;
}
